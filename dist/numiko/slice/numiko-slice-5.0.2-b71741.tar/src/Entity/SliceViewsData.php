<?php

namespace Drupal\slice\Entity;

use Drupal\views\EntityViewsData;
use Drupal\views\EntityViewsDataInterface;

/**
 * Provides Views data for Slice entities.
 */
class SliceViewsData extends EntityViewsData implements EntityViewsDataInterface {
  /**
   * {@inheritdoc}
   */
  public function getViewsData() {
    $data = parent::getViewsData();

    $data['slice']['table']['base'] = array(
      'field' => 'id',
      'title' => $this->t('Slice'),
      'help' => $this->t('The Slice ID.'),
    );

    return $data;
  }

}
