<?php

namespace Drupal\slice\Entity;

use Drupal\Core\Config\Entity\ConfigEntityBundleBase;
use Drupal\slice\SliceTypeInterface;
use Drupal\paragraphs\Entity\ParagraphsType;

/**
 * Defines the Slice type entity.
 *
 * @ConfigEntityType(
 *   id = "slice_type",
 *   label = @Translation("Slice type"),
 *   handlers = {
 *     "list_builder" = "Drupal\slice\SliceTypeListBuilder",
 *     "form" = {
 *       "add" = "Drupal\slice\Form\SliceTypeForm",
 *       "edit" = "Drupal\slice\Form\SliceTypeForm",
 *       "delete" = "Drupal\slice\Form\SliceTypeDeleteForm"
 *     },
 *     "route_provider" = {
 *       "html" = "Drupal\slice\SliceTypeHtmlRouteProvider",
 *     },
 *   },
 *   config_prefix = "slice_type",
 *   admin_permission = "administer site configuration",
 *   bundle_of = "slice",
 *   entity_keys = {
 *     "id" = "id",
 *     "label" = "label",
 *     "classes" = "classes",
 *     "adminlabelfield" = "adminlabelfield",
 *     "uuid" = "uuid"
 *   },
 *   config_export = {
 *     "id",
 *     "label",
 *     "icon_uuid",
 *     "description",
 *     "behavior_plugins",
 *     "classes",
 *     "adminlabelfield"
 *   },
 *   links = {
 *     "canonical" = "/admin/structure/slice_type/{slice_type}",
 *     "add-form" = "/admin/structure/slice_type/add",
 *     "edit-form" = "/admin/structure/slice_type/{slice_type}/edit",
 *     "delete-form" = "/admin/structure/slice_type/{slice_type}/delete",
 *     "collection" = "/admin/structure/slice_type"
 *   }
 * )
 */
class SliceType extends ParagraphsType implements SliceTypeInterface {
  const DEFAULT_ADMIN_LABEL_FIELD = 'name';

  protected $classes;

  protected $adminlabelfield;

  public function classes() {
    return $this->get('classes');
  }

  public function setClasses($classes) {
    $this->set('classes', $classes);
    return $this;
  }

  public function adminlabelfield() {
    return $this->get('adminlabelfield');
  }

  public function setAdminlabelfield($adminlabelfield) {
    $this->set('adminlabelfield', $adminlabelfield);
    return $this;
  }

}
