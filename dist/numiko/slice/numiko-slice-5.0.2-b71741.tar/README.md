# Slices #

Slices are not much more than a drop-in replacement for the entity part of paragraphs, and still require paragraphs for the field aspect.

## What benefits do slices give me? ##

* Translation
* Workbench support
* Slice type classes
* Admin label fields in the closed state
* Slice View modes

### Slice Type Classes ###

For each slice type you can assign a set of space separated classes when setting up or editing the slice type.

### What are Admin Label Fields? ###

For each slice type you can select a field to be displayed instead of just the title / type for slices when in a closed state on the edit form.

The selected field will display as defined in the `default` view mode, unless you have defined an `Admin Label` view mode.

### What are Slice View Modes? ###

Slice view modes enable the end-user to switch between all available view modes setup on a slice, when adding or editing a slice.

#### How can I use Slice View Modes? ####

Slice View Modes are available from version `8.3.0` when upgrading you will need to run the usual `drush updatedb`.