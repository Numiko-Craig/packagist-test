<?php

namespace Drupal\slice\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting Slice entities.
 *
 * @ingroup slice
 */
class SliceDeleteForm extends ContentEntityDeleteForm {

}
