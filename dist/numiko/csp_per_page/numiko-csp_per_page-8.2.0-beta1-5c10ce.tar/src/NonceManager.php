<?php

namespace Drupal\csp_per_page;

class NonceManager {

  protected $generatedNonces = [];

  public function generateNonce($label) {
    $nonce = base64_encode(uniqid());
    $this->generatedNonces[$label] = $nonce;
    return $nonce;
  }

  public function getGeneratedNonces() {
    return $this->generatedNonces;
  }

}
