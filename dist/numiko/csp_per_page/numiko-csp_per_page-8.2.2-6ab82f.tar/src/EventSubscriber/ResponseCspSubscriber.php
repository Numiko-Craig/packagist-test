<?php

namespace Drupal\csp_per_page\EventSubscriber;

use Drupal\csp_per_page\CurrentPage;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpKernel\Event\FilterResponseEvent;
use Symfony\Component\HttpKernel\KernelEvents;

/**
 * Intercept response to modify Content Security Policy header.
 */
class ResponseCspSubscriber implements EventSubscriberInterface {

  /**
   * @var \Drupal\csp_per_page\CurrentPage
   */
  protected $cspForCurrentPage;

  /**
   * ResponseCspSubscriber constructor.
   *
   * @param \Drupal\csp_per_page\CurrentPage $cspForCurrentPage
   */
  public function __construct(CurrentPage $cspForCurrentPage) {
    $this->cspForCurrentPage = $cspForCurrentPage;
  }

  /**
   * {@inheritdoc}
   */
  public static function getSubscribedEvents() {
    $events[KernelEvents::RESPONSE] = ['onKernelResponse', -100];
    return $events;
  }

  /**
   * Use strict CSP on chosen pages.
   *
   * @param \Symfony\Component\HttpKernel\Event\FilterResponseEvent $event
   *   The Response event.
   */
  public function onKernelResponse(FilterResponseEvent $event) {
    if (!$event->isMasterRequest()) {
      return;
    }

    $policy = $this->cspForCurrentPage->findCspForPage();

    if ($policy) {
      $response = $event->getResponse();
      $response->headers->set(
        'Content-Security-Policy',
        $policy
      );
      // Prevent leakage of any reported data.
      $response->headers->remove('Content-Security-Policy-Report-Only');
    }
  }



}
