# CSP Per Page

Sets a strict Content Security Policy on certain pages. This allows tracking and other services on most pages on a site, but a strict CSP on pages such as login and payment pages.

Use the config to set paths and content types that need the strict policy (no interface for this yet).

## Nonces

Use the NonceManager to generate nonces. During preprocessing, for example, use NoneManager::generateNonce() to obtain to nonceand insert it into your theme. It will then be output as part of the CSP.

## Tests

There are currently no unit tests. Highly recommend integration tests for individual sites that test the effect this module is having together with other modules.
