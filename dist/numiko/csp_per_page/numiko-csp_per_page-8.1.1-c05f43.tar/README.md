# CSP Per Page

Sets a strict Content Security Policy on certain pages. This allows tracking and other services on most pages on a site, but a strict CSP on pages such as login and payment pages.

Use the config to set paths and content types that need the strict policy (no interface for this yet).

## Tests

There are currently no unit tests. Highly recommend integration tests for individual sites that test the effect this module is having together with other modules.
