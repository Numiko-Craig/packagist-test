# Entity Reference Revisions Context #

Add data attributes to paragraphs to represent their position within a set of paragraphs on the front-end.