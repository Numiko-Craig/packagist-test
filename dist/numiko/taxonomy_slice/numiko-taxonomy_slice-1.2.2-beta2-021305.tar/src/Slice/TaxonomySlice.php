<?php

namespace Drupal\taxonomy_slice\Slice;

use Drupal\Core\Entity\EntityFieldManager;
use Drupal\Core\Field\FieldDefinitionInterface;
use Drupal\paragraphs\ParagraphInterface;
use Drupal\Core\Config\ConfigFactory;

/**
 * Handle a taxonomy slice.
 */
class TaxonomySlice {

  /**
   * The entity field manager.
   *
   * @var \Drupal\Core\Entity\EntityFieldManager
   */
  protected $entityFieldManager;

  /**
   * @var \Drupal\Core\Config\ConfigFactory
   */
  private $config;

  /**
   * TaxonomySlice constructor.
   *
   * @param \Drupal\Core\Entity\EntityFieldManager $entityFieldManager
   * @param \Drupal\Core\Config\ConfigFactory $config
   */
  public function __construct(EntityFieldManager $entityFieldManager, ConfigFactory $config) {
    $this->entityFieldManager = $entityFieldManager;
    $this->config = $config;
  }

  /**
   * Map the arguments from the slice to the view contained within.
   *
   * @param Drupal\paragraphs\ParagraphInterface $slice
   *   The slice containing the view.
   */
  public function mapArgumentsToView(ParagraphInterface $slice) {
    $bundleFields = $this->getBundleFields($slice->bundle());
    if(!$bundleFields) {
      return NULL;
    }
    $view = $this->getView($slice, $bundleFields);
    if ($view) {
      $arguments = $this->getTaxonomyArguments($slice, $bundleFields);
      if ($arguments) {
        $view->getExecutable()->setArguments($arguments);
      }
      $numberOfItems = $this->getNumberOfItems($slice, $bundleFields);
      if ($numberOfItems) {
        if ($this->config->get('taxonomy_slice.settings')->get('set_columns')) {
          $styleSettings = $view->getExecutable()
            ->getDisplay()
            ->getOption('style');
          $styleSettings['options']['columns'] = $numberOfItems;
          $view->getExecutable()
            ->getDisplay()
            ->overrideOption('style', $styleSettings);
        }
        $view->getExecutable()->setItemsPerPage($numberOfItems);
      }
    }
  }

  /**
   * Get all field definitions for a given bundle.
   *
   * Get all field definitions excluding base field definitions.
   *
   * @param string $bundle
   *   The bundle to lookup field definitions for.
   *
   * @return array
   *   Field definitions excluding base field definitions indexed by type.
   */
  protected function getBundleFields(string $bundle) {
    $allBundleFields = $this->entityFieldManager->getFieldDefinitions('paragraph', $bundle);
    foreach (array_filter($allBundleFields, [$this, 'isNotBaseField']) as $field) {
      $fieldStorage = $field->getFieldStorageDefinition();
      $bundleFields[$fieldStorage->getType()][$fieldStorage->getName()] = $fieldStorage;
    }
    if(isset($bundleFields)) {
      return $bundleFields;
    }
    else{
      return NULL;
    }
  }

  /**
   * Is the field not a base field.
   *
   * @param Drupal\Core\Field\FieldDefinitionInterface $field
   *   The field definition to query.
   *
   * @return bool
   *   Is the field a base field.
   */
  protected function isNotBaseField(FieldDefinitionInterface $field) {
    return !$field->getFieldStorageDefinition()->isBaseField();
  }

  /**
   * Get the view being used in this taxonomy slice.
   *
   * @param Drupal\paragraphs\ParagraphInterface $slice
   *   The taxonomy slice.
   * @param array $bundleFields
   *   The list of fields from the bundle.
   *
   * @return Drupal\views\Entity\View
   *   The view being used in this taxonomy slice.
   */
  protected function getView(ParagraphInterface $slice, array $bundleFields) {
    if (!isset($bundleFields['view_display_reference_item'])) {
      return NULL;
    }
    foreach ($bundleFields['view_display_reference_item'] as $fieldName => $fieldStorage) {
      if (!$slice->get($fieldName)->isEmpty()) {
        return $slice->get($fieldName)->first()->getValue()['entity'];
      }
    }
  }

  /**
   * Get the taxonomy values from all fields on the slice.
   *
   * @param Drupal\paragraphs\ParagraphInterface $slice
   *   The slice to etract the taxonomy from.
   * @param array $bundleFields
   *   The list of fields from the bundle.
   *
   * @return array
   *   An array of taxonomy arguments.
   */
  protected function getTaxonomyArguments(ParagraphInterface $slice, array $bundleFields) {
    $args = [];
    if (!isset($bundleFields['entity_reference'])) {
      return [];
    }
    foreach ($bundleFields['entity_reference'] as $fieldName => $fieldStorage) {
      if ($fieldStorage->getSetting('target_type') === 'taxonomy_term') {
        if (!$slice->get($fieldName)->isEmpty()) {
          $terms = [];
          foreach ($slice->get($fieldName) as $field) {
            $terms[] = $field->getString();
          }
          $args[] = implode('+', $terms);
        }
      }
    }
    return $args;
  }

  /**
   * Get the number of items from a list integer field.
   *
   * @param Drupal\paragraphs\ParagraphInterface $slice
   *   The slice containing the integer field with the number of items selected.
   * @param array $bundleFields
   *   The list of fields from the bundle.
   *
   * @return int
   *   The number of items to display.
   */
  protected function getNumberOfItems(ParagraphInterface $slice, array $bundleFields) {
    if (!isset($bundleFields['list_integer'])) {
      return NULL;
    }
    foreach ($bundleFields['list_integer'] as $fieldName => $fieldStorage) {
      if (!$slice->get($fieldName)->isEmpty()) {
        return $slice->get($fieldName)->first()->getString();
      }
    }
  }

}
