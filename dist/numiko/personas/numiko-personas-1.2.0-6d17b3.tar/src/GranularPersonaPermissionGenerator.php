<?php

namespace Drupal\personas;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * The PermissionGenerator class.
 */
class GranularPersonaPermissionGenerator {

  use StringTranslationTrait;

  /**
   * The entity type manager service.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * Construct a new permission generator.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager service.
   */
  public function __construct(EntityTypeManagerInterface $entity_type_manager) {
    $this->entityTypeManager = $entity_type_manager;
  }

  /**
   * Returns an array of permissions to assign specific personas.
   *
   * @return array
   *   An array of permissions in the correct format for permission_callbacks.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  public function assignmentPermissions() {
    $permissions = [];
    foreach ($this->entityTypeManager->getStorage('persona')->loadMultiple() as $pid => $persona) {
      $permissions[sprintf('assign %s persona', $pid)] = [
        'title' => $this->t('Assign %persona persona', ['%persona' => $persona->label()]),
      ];
    }
    return $permissions;
  }

}
