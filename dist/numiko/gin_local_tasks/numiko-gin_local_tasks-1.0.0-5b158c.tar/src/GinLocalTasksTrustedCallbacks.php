<?php

namespace Drupal\gin_local_tasks;

use Drupal;
use Drupal\Core\Cache\CacheableMetadata;
use Drupal\Core\Security\TrustedCallbackInterface;
use Drupal\Core\Template\Attribute;
use Drupal\Core\Url;

/**
 * Trusted callbacks.
 */
class GinLocalTasksTrustedCallbacks implements TrustedCallbackInterface {

  /**
   * {@inheritdoc}
   */
  public static function trustedCallbacks() {
    return ['localTasks'];
  }

  /**
   * Add local tasks to administration menu toolbar.
   *
   * Taken from
   * https://www.drupal.org/files/issues/2020-05-28/3121440-gin-toolbar-local-tasks-12.patch
   */
  public static function localTasks($build) {

    $local_tasks = Drupal::service('plugin.manager.menu.local_task')
      ->getLocalTasks(Drupal::service('current_route_match')
        ->getRouteName(), 0);
    if (!empty($local_tasks['tabs'])) {
      $local_task_default_route = '<none>';
      $local_task_default_route_params = [];
      $items = [];
      foreach ($local_tasks['tabs'] as $key => $local_task) {
        if ($local_task['#access']->isAllowed()) {
          $items[] = $local_task['#link'];
          // Let's search for edit link if it exists.
          if (strpos($key, 'edit_form') !== FALSE) {
            $local_task_default_route = $local_task['#link']['url']->getRouteName();
            $local_task_default_route_params = $local_task['#link']['url']->getRouteParameters();
          }
        }
      }
      $new_items = [];
      if (!empty($build['administration_menu']['#items']['admin_toolbar_tools.help'])) {
        // If there is admin_toolbar_tools module installed, make its menu on
        // top.
        $new_items = ['admin_toolbar_tools.help' => $build['administration_menu']['#items']['admin_toolbar_tools.help']];
        unset($build['administration_menu']['#items']['admin_toolbar_tools.help']);
      }
      $build['administration_menu']['#items'] = $new_items + [
        'local_tasks' => [
          'is_expanded' => TRUE,
          'title' => t('Local Tasks'),
          'url' => Url::fromRoute($local_task_default_route, $local_task_default_route_params, [
            'attributes' => [
              'class' => [
                'toolbar-icon',
                'toolbar-icon-local-tasks',
              ],
            ],
          ],
          ),
          'attributes' => new Attribute(
            [
              'class' => [
                'menu-item',
                'menu-item--expanded',
              ],
            ]),
          'below' => $items,
        ],
      ] + $build['administration_menu']['#items'];
      // Add local tasks cacheable metadata to result build.
      $metadata = CacheableMetadata::createFromRenderArray($build['administration_menu']);
      $local_tasks['cacheability']->merge($metadata);
      $local_tasks['cacheability']->applyTo($build['administration_menu']);
    }
    return $build;
  }

}
