<?php

namespace Drupal\views_string_length_sort\Plugin\views\sort;

use Drupal\views\Plugin\views\sort\SortPluginBase;

/**
 * Basic sort handler for string length.
 *
 * @ViewsSort("string_length")
 */
class StringLength extends SortPluginBase {

  /**
   * Called to add the sort to a query.
   */
  public function query() {
    $this->ensureMyTable();

    $strlen_alias = "LENGTH($this->tableAlias.$this->realField)";

    // Add order by string length.
    $this->query->addOrderBy(NULL,
    "$strlen_alias",
      $this->options['order'],
      "string_length"
    );
  }

}
