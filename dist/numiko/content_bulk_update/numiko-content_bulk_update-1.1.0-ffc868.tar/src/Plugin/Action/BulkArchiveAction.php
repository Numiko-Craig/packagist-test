<?php

namespace Drupal\content_bulk_update\Plugin\Action;

use Drupal\Core\Action\ActionBase;
use Drupal\Core\Entity\RevisionLogInterface;
use Drupal\Core\Session\AccountInterface;

/**
 * An action to archive the content.
 *
 * @Action(
 *   id = "bulk_archive_action",
 *   label = @Translation("Archive content"),
 *   type = "node",
 *   confirm = TRUE,
 * )
 */
class BulkArchiveAction extends ActionBase {

  /**
   * {@inheritdoc}
   */
  public function execute($entity = NULL) {
    $entity->set('moderation_state', 'archived');
    if ($entity instanceof RevisionLogInterface) {
      $entity->setRevisionCreationTime(\Drupal::time()->getRequestTime());
      $entity->setRevisionLogMessage('Bulk operation archive revision');
      $entity->setRevisionUserId(\Drupal::currentUser()->id());
    }
    $entity->save();
  }

  /**
   * {@inheritdoc}
   */
  public function access($object, AccountInterface $account = NULL, $return_as_object = FALSE) {
    if ($object->getEntityType() === 'node') {
      $access = $object->access('update', $account, TRUE)
        ->andIf($object->status->access('edit', $account, TRUE));
      return $return_as_object ? $access : $access->isAllowed();
    }

    return TRUE;
  }

}
