<?php
namespace Drupal\instance_migrate\Plugin\migrate\source\d8;

use Drupal\migrate\Row;
use Drupal\migrate_drupal_d8\Plugin\migrate\source\d8\ContentEntity;

/**
 * Drupal 8 menu link source from database.
 *
 * @MigrateSource(
 *   id = "d8_menu_link",
 *   source_provider = "instance_migrate"
 * )
 */

class MenuLink extends ContentEntity {

  /**
   * Static cache for bundle fields.
   *
   * @var array
   */
  protected $bundleFields = [];

  /**
   * {@inheritdoc}
   */
  public function query() {
    $query = $this->select('menu_link_content_data', 'mlc')
      ->fields('mlc', [
        'id',
        'bundle',
        'langcode',
        'title',
        'description',
        'menu_name',
        'link__uri',
        'link__title',
        'link__options',
        'external',
        'rediscover',
        'weight',
        'expanded',
        'enabled',
        'parent',
        'changed',
        'default_langcode',
      ]);
    $query->addField('m', 'uuid');
    $query->innerJoin('menu_link_content', 'm', 'm.id = mlc.id');

    if (isset($this->configuration['bundle'])) {
      $query->condition('mlc.bundle', $this->configuration['bundle']);
    }

    return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    $fields = [
      'id' => 'placeholder',
      'bundle' => 'placeholder',
      'uuid' => 'placeholder',
      'langcode' => 'placeholder',
      'title' => 'placeholder',
      'description' => 'placeholder',
      'menu_name' => 'placeholder',
      'link__uri' => 'placeholder',
      'link__title' => 'placeholder',
      'link__options' => 'placeholder',
      'external' => 'placeholder',
      'rediscover' => 'placeholder',
      'weight' => 'placeholder',
      'expanded' => 'placeholder',
      'enabled' => 'placeholder',
      'parent' => 'placeholder',
      'changed' => 'placeholder',
      'default_langcode' => 'placeholder',
    ];
    return $fields;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
    // Get Field API field values.
    if (!$this->bundleFields) {
      $this->bundleFields = $this->getFields('menu_link_content', $row->getSourceProperty('bundle'));
    }

    foreach (array_keys($this->bundleFields) as $field) {
      $nid = $row->getSourceProperty('id');
      $row->setSourceProperty($field, $this->getFieldValues('menu_link_content', $field, $nid));
    }

    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    return [
      'id' => [
        'type' => 'integer',
        'alias' => 'm',
      ]
    ];
  }
}
