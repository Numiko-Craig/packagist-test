<?php

namespace Drupal\instance_migrate\Plugin\migrate\process;

use Drupal\Component\Utility\NestedArray;
use Drupal\migrate\Plugin\migrate\process\MigrationLookup;
use Drupal\migrate\ProcessPluginBase;
use Drupal\migrate\MigrateException;
use Drupal\migrate\MigrateExecutableInterface;
use Drupal\migrate\Row;

/**
 * A processor that will look up IDs mapping from the node IDs referenced
 * in a link field.
 *
 * This will only work on a second pass when all other content is created.
 * There may be a better way to do this with stubs.
 *
 * @MigrateProcessPlugin(
 *   id = "link_field",
 *   handle_multiples = TRUE
 * )
 */
class LinkField extends MigrationLookup {

  const LINK_ENTITY_REF_PREFIX = 'entity:node';

  /**
   * {@inheritdoc}
   */
  public function transform($value, MigrateExecutableInterface $migrate_executable, Row $row, $destination_property) {

    if ($migrate_executable->isUpdate) {

      $returnValue = [];

      if (is_array($value)) {

        foreach ($value as $linkDetails) {
          if (strpos($linkDetails['uri'], self::LINK_ENTITY_REF_PREFIX) === 0) {
            $destination_nid = $this->findReferencedEntity($linkDetails['uri']);
            if ($destination_nid) {
              $linkDetails['uri'] = self::LINK_ENTITY_REF_PREFIX . '/' . $destination_nid;
            } else {
              $linkDetails['uri'] = null;
            }
          }
          $returnValue[] = $linkDetails;
        }

      }

      return $returnValue;

    }

    return [];

  }

  /**
   * Extract source node ID from entity link reference and find destination ID
   *
   * @return int
   */
  protected function findReferencedEntity($linkUri) {
    $nid = str_replace(self::LINK_ENTITY_REF_PREFIX . '/', '', $linkUri);
    $migration_ids = [
      'migrate_node_page',
      'migrate_node_event',
      'migrate_node_date_range_event',
      'migrate_node_landing_page',
      'migrate_node_press_release',
      'migrate_node_story',
    ]; // @todo make configurable
    $migrations = $this->migrationPluginManager->createInstances($migration_ids);
    $destination_id = null;
    foreach ($migrations as $migration_id => $migration) {
      // Break out of the loop as soon as a destination ID is found.
      if ($destination_id = $migration->getIdMap()->lookupDestinationId([$nid])) {
        $destination_id = current($destination_id);
        break;
      }
    }
    return $destination_id;
  }

}
