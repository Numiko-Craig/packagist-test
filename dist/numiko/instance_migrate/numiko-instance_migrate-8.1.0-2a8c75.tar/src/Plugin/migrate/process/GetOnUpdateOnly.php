<?php

namespace Drupal\instance_migrate\Plugin\migrate\process;

use Drupal\Component\Utility\NestedArray;
use Drupal\migrate\Plugin\migrate\process\Get;
use Drupal\migrate\Plugin\migrate\process\MigrationLookup;
use Drupal\migrate\ProcessPluginBase;
use Drupal\migrate\MigrateException;
use Drupal\migrate\MigrateExecutableInterface;
use Drupal\migrate\Row;

/**
 * "Get" process plugin, but will only run when
 *
 * @MigrateProcessPlugin(
 *   id = "get_update_only",
 *   handle_multiples = TRUE
 * )
 */
class GetOnUpdateOnly extends Get {

  /**
   * {@inheritdoc}
   */
  public function transform($value, MigrateExecutableInterface $migrate_executable, Row $row, $destination_property) {

    if ($migrate_executable->isUpdate) {

      return parent::transform($value, $migrate_executable, $row, $destination_property);

    }

  }

}
