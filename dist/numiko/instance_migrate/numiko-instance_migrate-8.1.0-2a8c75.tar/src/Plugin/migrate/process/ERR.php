<?php

namespace Drupal\instance_migrate\Plugin\migrate\process;

use Drupal\Component\Utility\NestedArray;
use Drupal\migrate\ProcessPluginBase;
use Drupal\migrate\MigrateException;
use Drupal\migrate\MigrateExecutableInterface;
use Drupal\migrate\Row;

/**
 * @MigrateProcessPlugin(
 *   id = "err",
 *   handle_multiples = TRUE
 * )
 */
class ERR extends ProcessPluginBase {

  /**
   * {@inheritdoc}
   */
  public function transform($value, MigrateExecutableInterface $migrate_executable, Row $row, $destination_property) {

    $new_value = [];

    if (!is_array($value)) {
      drush_print_r('ERR value not array');
      drush_print_r($value);
      drush_print_r($destination_property);
    }

    foreach ($value as $key => $item) {

      $new_value[] = [
        'id' => $item['target_id'],
        'revision_id' => $item['target_revision_id']
      ];

    }

    return $new_value;
  }

}
