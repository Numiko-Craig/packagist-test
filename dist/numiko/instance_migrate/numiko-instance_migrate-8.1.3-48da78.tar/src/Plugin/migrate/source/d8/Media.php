<?php
namespace Drupal\instance_migrate\Plugin\migrate\source\d8;
use Drupal\migrate\Row;
use Drupal\migrate_drupal_d8\Plugin\migrate\source\d8\ContentEntity;

/**
 * Drupal 8 media entity source from database.
 *
 * @MigrateSource(
 *   id = "d8_media_entity",
 *   source_provider = "migrate_drupal_d8"
 * )
 */

class Media extends ContentEntity {

  /**
   * Static cache for bundle fields.
   *
   * @var array
   */
  protected $bundleFields = [];

  /**
   * {@inheritdoc}
   */
  public function query() {
    $query = $this->select('media_field_data', 'mfd')
      ->fields('mfd', [
        'mid',
        'vid',
        'bundle',
        'langcode',
        'name',
        'thumbnail__target_id',
        'thumbnail__alt',
        'thumbnail__title',
        'thumbnail__width',
        'thumbnail__height',
        'uid',
        'status',
        'created',
        'changed',
        'default_langcode',
        'moderation_state',
      ]);
    $query->addField('m', 'uuid');
    $query->innerJoin('media', 'm', 'm.vid = mfd.vid');

    if (isset($this->configuration['bundle'])) {
      $query->condition('mfd.bundle', $this->configuration['bundle']);
    }

    return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    $fields = [
      'mid' => 'Media ID',
      'langcode' => 'Language',
      'name' => '',
      'thumbnail__target_id' => '',
      'thumbnail__alt' => '',
      'thumbnail__title' => '',
      'thumbnail__width' => '',
      'thumbnail__height' => '',
      'uid' => '',
      'status' => '',
      'created' => '',
      'changed' => '',
      'default_langcode' => '',
      'moderation_state' => '',
    ];
    return $fields;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
    // Get Field API field values.
    if (!$this->bundleFields) {
      $this->bundleFields = $this->getFields('media', $row->getSourceProperty('bundle'));
    }

    foreach (array_keys($this->bundleFields) as $field) {
      $nid = $row->getSourceProperty('mid');
      $vid = $row->getSourceProperty('vid');
      $row->setSourceProperty($field, $this->getFieldValues('media', $field, $nid, $vid));
    }

    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    return [
      'mid' => [
        'type' => 'integer',
        'alias' => 'm',
      ]
    ];
  }
}
