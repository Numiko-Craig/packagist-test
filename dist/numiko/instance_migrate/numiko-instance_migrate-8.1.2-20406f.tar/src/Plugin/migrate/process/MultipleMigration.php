<?php

namespace Drupal\instance_migrate\Plugin\migrate\process;

use Drupal\migrate\MigrateExecutableInterface;
use Drupal\migrate\Plugin\migrate\process\Migration;
use Drupal\migrate\Row;

/**
 * @MigrateProcessPlugin(
 *   id = "multiple_migration"
 * )
 */

class MultipleMigration extends Migration
{

  /**
   * {@inheritdoc}
   */
  public function transform($values, MigrateExecutableInterface $migrate_executable, Row $row, $destination_property) {

    $ret = [];

    if ($values) {

      foreach ($values as $value) {
        $transformed_value = parent::transform($value, $migrate_executable, $row, $destination_property);
        if ($transformed_value) {
          $ret[] = $transformed_value;
        }

      }

    }

    return $ret;

  }

}
