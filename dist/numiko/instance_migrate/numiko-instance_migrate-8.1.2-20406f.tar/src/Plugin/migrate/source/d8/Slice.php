<?php

namespace Drupal\instance_migrate\Plugin\migrate\source\d8;

use Drupal\migrate\Row;
use Drupal\migrate_drupal_d8\Plugin\migrate\source\d8\ContentEntity;

/**
 * Drupal 8 Slice source from database.
 *
 * @MigrateSource(
 *   id = "d8_slice",
 *   source_provider = "migrate_drupal_d8"
 * )
 */
class Slice extends ContentEntity {

  /**
   * Static cache for bundle fields.
   *
   * @var array
   */
  protected $bundleFields = [];

  /**
   * {@inheritdoc}
   */
  public function query() {
    $query = $this->select('slice_field_data', 'sfd')
      ->fields('sfd', [
        'id',
        'revision_id',
        'type',
        'user_id',
        'name',
        'status',
        'view_mode',
        'langcode',
        'created',
        'changed',
        'parent_id',
        'parent_type',
        'parent_field_name',
      ]);
    $query->addField('s', 'uuid');
    $query->innerJoin('slice', 's', 's.revision_id = sfd.revision_id');

    if (isset($this->configuration['bundle'])) {
      $query->condition('sfd.type', $this->configuration['bundle']);
    }

    return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    $fields = [
      'id' => 'Slice ID',
      'type' => 'Type',
      'uuid' => 'UUID',
      'user_id' => 'Author ID',
      'name' => 'Slice name',
      'status' => 'Publish status',
      'view_mode' => 'View mode',
      'langcode' => 'Language',
      'created' => 'Created timestamp',
      'changed' => 'Modified timestamp',
      'parent_id' => 'Parent ID',
      'parent_type' => 'Parent type',
      'parent_field_name' => 'Parent field name',
    ];
    return $fields;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
    // Get Field API field values.
    if (!$this->bundleFields) {
      $this->bundleFields = $this->getFields('slice', $row->getSourceProperty('bundle'));
    }

    foreach (array_keys($this->bundleFields) as $field) {
      $id = $row->getSourceProperty('id');
      $vid = $row->getSourceProperty('revision_id');
      $row->setSourceProperty($field, $this->getFieldValues('slice', $field, $id, $vid));
    }

    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    return [
      'id' => [
        'type' => 'integer',
        'alias' => 's'
      ],
      'revision_id' => [
        'type' => 'integer',
        'alias' => 's'
      ]
    ];
  }
}