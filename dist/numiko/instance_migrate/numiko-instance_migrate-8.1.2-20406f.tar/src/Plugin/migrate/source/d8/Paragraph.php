<?php

namespace Drupal\instance_migrate\Plugin\migrate\source\d8;

use Drupal\migrate\Row;
use Drupal\migrate_drupal_d8\Plugin\migrate\source\d8\ContentEntity;

/**
 * Drupal 8 Paragraphs source from database.
 *
 * @MigrateSource(
 *   id = "d8_paragraph",
 *   source_provider = "migrate_drupal_d8"
 * )
 */
class Paragraph extends ContentEntity {

  /**
   * Static cache for bundle fields.
   *
   * @var array
   */
  protected $bundleFields = [];

  /**
   * {@inheritdoc}
   */
  public function query() {
    $query = $this->select('paragraphs_item_field_data', 'pfd')
      ->fields('pfd', [
        'id',
        'revision_id',
        'type',
        'langcode',
        'uid',
        'status',
        'created',
        'parent_id',
        'parent_type',
        'parent_field_name',
        'behavior_settings',
    ]);
    $query->addField('p', 'uuid');
    $query->innerJoin('paragraphs_item', 'p', 'p.revision_id = pfd.revision_id');

    if (isset($this->configuration['bundle'])) {
      $query->condition('pfd.type', $this->configuration['bundle']);
    }

    return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    $fields = [
      'id' => 'placeholder',
      'type' => 'placeholder',
      'langcode' => 'placeholder',
      'uid' => 'placeholder',
      'status' => 'placeholder',
      'created' => 'placeholder',
      'parent_id' => 'placeholder',
      'parent_type' => 'placeholder',
      'parent_field_name' => 'placeholder',
      'behavior_settings' => 'placeholder',
    ];
    return $fields;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
    // Get Field API field values.
    if (!$this->bundleFields) {
      $this->bundleFields = $this->getFields('paragraph', $row->getSourceProperty('bundle'));
    }

    foreach (array_keys($this->bundleFields) as $field) {
      $id = $row->getSourceProperty('id');
      $vid = $row->getSourceProperty('revision_id');
      $row->setSourceProperty($field, $this->getFieldValues('paragraph', $field, $id, $vid));
    }

    return parent::prepareRow($row);
  }

  /**
   * {@inheritdoc}
   */
  public function getIds() {
    return [
      'id' => [
        'type' => 'integer',
        'alias' => 'p'
      ],
      'revision_id' => [
        'type' => 'integer',
        'alias' => 'p'
      ]
    ];
  }
}