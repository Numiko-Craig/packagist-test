<?php

namespace Drupal\instance_migrate\Plugin\migrate\source\d8;

use Drupal\migrate\Row;
use Drupal\migrate_drupal_d8\Plugin\migrate\source\d8\Node as BaseNode;

/**
 * Drupal 8 node source from database, adding alias query so alias can be
 * migrated easily from the node migration.
 *
 * @todo provide patch to migrate_drupal_d8 module so that this isn't needed.
 * Mostly overriding BaseNode anyway.
 *
 * @MigrateSource(
 *   id = "d8_node_with_alias",
 *   source_provider = "instance_migrate"
 * )
 */
class Node extends BaseNode {

  /**
   * {@inheritdoc}
   */
  public function query() {
    $query = $this->select('node_field_data', 'nfd')
      ->fields('nfd', [
        'nid',
        'vid',
        'type',
        'title',
        'langcode',
        'uid',
        'status',
        'created',
        'changed',
        'promote',
        'sticky',
        'moderation_state'
      ]);
    $query->addField('n', 'uuid');
    $query->innerJoin('node', 'n', 'nfd.vid = n.vid');

    if (isset($this->configuration['bundle'])) {
      $query->condition('nfd.type', $this->configuration['bundle']);
    }

    return $query;

  }

  /**
   * {@inheritdoc}
   */
  public function fields() {
    $fields = [
      'nid' => $this->t('Node ID'),
      'type' => $this->t('Type'),
      'langcode' => $this->t('Language (fr, en, ...)'),
      'title' => $this->t('Title'),
      'uid' => $this->t('Node authored by (uid)'),
      'status' => $this->t('Published'),
      'created' => $this->t('Created timestamp'),
      'changed' => $this->t('Modified timestamp'),
      'promote' => $this->t('Promoted to front page'),
      'sticky' => $this->t('Sticky at top of lists'),
      'moderation_state' => $this->t('Moderation state'),
    ];
    return $fields;
  }


  /**
   * {@inheritdoc}
   */
  public function prepareRow(Row $row) {
    // Get Field API field values.
    if (!$this->bundleFields) {
      $this->bundleFields = $this->getFields('node', $row->getSourceProperty('bundle'));
    }

    $nid = $row->getSourceProperty('nid');
    $vid = $row->getSourceProperty('vid');

    foreach (array_keys($this->bundleFields) as $field) {
      $row->setSourceProperty($field, $this->getFieldValues('node', $field, $nid, $vid));
    }

    $pathSource = '/node/' . $nid;

    // Load alias
    $query = $this->select('domain_path', 'dp')
      ->fields('dp', ['alias']);
    $query->condition('dp.source', $pathSource);
    $alias = $query->execute()->fetchField();
    if (!empty($alias)) {
      $row->setSourceProperty('alias', $alias);
    }

    // Load pathauto status
    // @see Drupal\pathauto\PathautoState
    $query = $this->select('key_value', 'k')
      ->fields('k', ['value']);
    $query->condition('k.collection', 'pathauto_state.node')
      ->condition('k.name', $nid);
    $pathautoState = $query->execute()->fetchField();
    if (empty($pathautoState)) {
      $pathautoState = 1;
    } else {
      $pathautoState = unserialize($pathautoState);
    }
    $row->setSourceProperty('pathauto_state', $pathautoState);

    return parent::prepareRow($row);
  }

}
