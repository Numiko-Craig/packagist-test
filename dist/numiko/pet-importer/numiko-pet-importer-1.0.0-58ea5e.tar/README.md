# Pet Importer

This package is used to format the pet XML from Blue Cross into a format that's 
easier to migrate into Drupal.

## Usage

Parsing the Pet XML is handled by `PetParser`. Create a service for the PetParser 
and connect all relevent transformers and validators and and pass the XML string:

 
`$xml = file_get_contents('/path/to/pet/data.xml');`
`$parsedPetData = $petParser->parse($xml);`

The parsed pet data can then be turned into JSON and passed to Drupal to migrate.

## Testing

If any change is made to the code, please add a test for it and run:

`vendor/bin/phpunit`
