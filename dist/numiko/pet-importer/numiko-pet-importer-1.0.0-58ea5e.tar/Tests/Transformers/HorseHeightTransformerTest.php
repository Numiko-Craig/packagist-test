<?php

declare(strict_types=1);

namespace Numiko\PetImporter\Tests\Transformers;

use PHPUnit\Framework\TestCase;
use Numiko\PetImporter\Transformers\HorseHeightTransformer;

class HorseHeightTransformerTest extends TestCase
{
    public function setUp(): void
    {
        $this->transformer = new HorseHeightTransformer();
    }


    /**
     *
     * @testWith ["Up to 12hh", 0]
     *           ["Up to 12hh", 0.1]
     *           ["Up to 12hh", 6]
     *           ["Up to 12hh", 11.9]
     *           ["Up to 12hh", 12]
     *           ["15hh and over", 12.1]
     *           ["15hh and over", 13]
     *           ["15hh and over", 25]
     *           ["", null]
     */
    public function testExpected($expected, $answer)
    {
        $this->assertEquals($expected, $this->transformer->transform($answer));
    }
}
