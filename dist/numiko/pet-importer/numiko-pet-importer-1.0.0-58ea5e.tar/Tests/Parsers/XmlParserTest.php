<?php

declare(strict_types=1);

namespace Numiko\PetImporter\Tests\Parsers;

use PHPUnit\Framework\TestCase;
use Numiko\PetImporter\Parsers\XmlParser;

/**
 *
 */
class XmlParserTest extends TestCase
{
    public const XML = <<<EOT
<?xml version="1.0"?>
<test>
  <test_case>
    <bool_with_single_letter>Y</bool_with_single_letter>
    <bool_with_word>Yes</bool_with_word>
    <bool_with_int>1</bool_with_int>
    <visit_number>1</visit_number>
    <string>Dog</string>
    <string_with_html_entities>Dog &amp; Cat</string_with_html_entities>
    <float>11.50</float>
    <int>1</int>
    <empty_element />
  </test_case>
  <test_case>
    <bool_with_single_letter>N</bool_with_single_letter>
    <bool_with_word>No</bool_with_word>
    <bool_with_int>0</bool_with_int>
    <visit_number>1</visit_number>
    <string>Cat</string>
    <string_with_html_entities>Horse &amp; Degu</string_with_html_entities>
    <float>11.60</float>
    <int>2</int>
    <empty_element />
  </test_case>
</test>
EOT;

    /**
     *
     */
    protected function setUp(): void
    {
        $this->xmlParser = new XmlParser();
        $this->xmlParser->loadXmlString(self::XML);
    }

    /**
     *
     * @testWith ["test_case/string", "Dog"]
     *           ["test_case/string_with_html_entities", "Dog & Cat"]
     *           ["test_case/empty_element", null]
     *           ["invalid", null]
     */
    public function testFindStringByXPath($selector, $expected)
    {
        $this->assertSame($expected, $this->xmlParser->findStringByXPath($selector));
    }

    /**
     *
     * @testWith ["test_case/string", ["Dog", "Cat"]]
     *           ["test_case/string_with_html_entities", ["Dog & Cat", "Horse & Degu"]]
     *           ["test_case/empty_element", [null, null]]
     *           ["invalid", []]
     */
    public function testFindStringsByXPath($selector, $expected)
    {
        $this->assertSame($expected, $this->xmlParser->findStringsByXPath($selector));
    }

    /**
     *
     * @testWith ["test_case/int", 1]
     *           ["test_case/empty_element", null]
     *           ["invalid", null]
     */
    public function testFindIntegerByXPath($selector, $expected)
    {
        $this->assertSame($expected, $this->xmlParser->findIntegerByXPath($selector));
    }

    /**
     *
     * @testWith ["test_case/int", [1, 2]]
     *           ["test_case/empty_element", [null, null]]
     *           ["invalid", []]
     */
    public function testFindIntegersByXPath($selector, $expected)
    {
        $this->assertSame($expected, $this->xmlParser->findIntegersByXPath($selector));
    }

    /**
     *
     * @testWith ["test_case/float", 11.50]
     *           ["test_case/int", 1.00]
     *           ["test_case/empty_element", null]
     *           ["invalid", null]
     */
    public function testFindFloatByXPath($selector, $expected)
    {
        $this->assertSame($expected, $this->xmlParser->findFloatByXPath($selector));
    }

    /**
     *
     * @testWith ["test_case/float", [11.50, 11.60]]
     *           ["test_case/int", [1.00, 2.00]]
     *           ["test_case/empty_element", [null, null]]
     *           ["invalid", []]
     */
    public function testFindFloatsByXPath($selector, $expected)
    {
        $this->assertSame($expected, $this->xmlParser->findFloatsByXPath($selector));
    }

    /**
     *
     * @testWith ["test_case/bool_with_single_letter", true, {"Y": true}]
     *           ["test_case/bool_with_word", true, {"Yes":  true, "No": false}]
     *           ["test_case/bool_with_int", true, {"1":  true, "0": false}]
     *           ["test_case/empty_element", null, []]
     *           ["invalid", null, []]
     */
    public function testFindBooleanByXPath($selector, $expected, $mappings)
    {
        if ($mappings) {
            $this->assertSame($expected, $this->xmlParser->findBooleanByXPath($selector, $mappings));
        } else {
            $this->assertSame($expected, $this->xmlParser->findBooleanByXPath($selector));
        }
    }

    /**
     *
     * @testWith ["test_case/bool_with_single_letter", [true, false], {"Y": true, "N": false}]
     *           ["test_case/bool_with_word", [true, false], {"Yes": true, "No": false}]
     *           ["test_case/bool_with_int", [true, false], {"1":  true, "0": false}]
     *           ["test_case/empty_element", [null, null], []]
     *           ["invalid", [], []]
     */
    public function testFindBooleansByXPath($selector, $expected, $mappings)
    {
        if ($mappings) {
            $this->assertSame($expected, $this->xmlParser->findBooleansByXPath($selector, $mappings));
        } else {
            $this->assertSame($expected, $this->xmlParser->findBooleansByXPath($selector));
        }
    }
}
