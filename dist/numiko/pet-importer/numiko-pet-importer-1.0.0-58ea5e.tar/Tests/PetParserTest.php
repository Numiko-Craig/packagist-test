<?php

declare(strict_types=1);

namespace Numiko\PetImporter\Tests;

use PHPUnit\Framework\TestCase;
use Numiko\PetImporter\PetParser;
use Numiko\PetImporter\Transformers\CanLiveWithChildrenTransformer;
use Numiko\PetImporter\Transformers\CanLiveWithOtherPetsTransformer;
use Numiko\PetImporter\Transformers\HorseSuitabilityTransformer;
use Numiko\PetImporter\Transformers\HorseHeightTransformer;
use Numiko\PetImporter\Transformers\StringToHtmlTransformer;
use Numiko\PetImporter\Transformers\AgeBracketTransformer;
use Numiko\PetImporter\Transformers\ImageIdToPathTransformer;
use Numiko\PetImporter\Validators\AllImagesExistValidator;
use Numiko\PetImporter\Parsers\XmlParser;
use Psr\Log\NullLogger;

/**
 *
 */
class PetParserTest extends TestCase
{
    public const XML = <<<XML
<?xml version="1.0"?>
<export_file export_date="16102019" animal_records="501">
  <animal>
    <animalref>119627</animalref>
    <sponsor>Y</sponsor>
    <visit_number>1</visit_number>
    <species>Dog</species>
    <name>Sophie</name>
    <age_year>9</age_year>
    <age_month>5</age_month>
    <sex>Female</sex>
    <breed>German Shepherd Dog</breed>
    <crossbreed>Rottweiler</crossbreed>
    <size>8.7</size>
    <location>SAAC - Southampton</location>
    <web_text>Nice to meet you, I’m Sophie a 9 year old German Shepherd cross looking for a new home.

Sophie.</web_text>
    <reserved>N</reserved>
    <videourl>http://youtube.com/12334</videourl>
    <colours>
      <colour>Black</colour>
      <colour>Tan</colour>
    </colours>
    <images>
      <image_id>96928</image_id>
      <image_id>96929</image_id>
      <image_id>96930</image_id>
    </images>
    <questions>
      <question>
        <question_text>Can this pet live with children?</question_text>
        <answer>School age</answer>
      </question>
      <question>
        <question_text>Can this pet live with other pets?</question_text>
        <answer>Cats and Dogs</answer>
      </question>
      <question>
        <question_text>Can this horse be ridden or is it suitable as a companion?</question_text>
        <answer>Companion</answer>
      </question>
    </questions>
  </animal>
</export_file>
XML;

    public function setUp(): void
    {

        file_put_contents('/tmp/96928.jpg', '');
        file_put_contents('/tmp/96929.jpg', '');
        file_put_contents('/tmp/96930.jpg', '');

        $this->petParser = new PetParser(
            new CanLiveWithChildrenTransformer(),
            new CanLiveWithOtherPetsTransformer(),
            new HorseSuitabilityTransformer(),
            new HorseHeightTransformer(),
            new StringToHtmlTransformer(),
            new AgeBracketTransformer(),
            new ImageIdToPathTransformer('/tmp/'),
            new AllImagesExistValidator(),
            new XmlParser(simplexml_load_string(self::XML)),
            new NullLogger(),
        );
        $data = $this->petParser->parse(self::XML);
        $this->petData = $data['data'][0];
    }

    public function tearDown(): void
    {
        // Suppress errors if file doesn't exist to allow unit tests to
        // remove images
        @unlink('/tmp/96928.jpg');
        @unlink('/tmp/96929.jpg');
        @unlink('/tmp/96930.jpg');
    }

    public function testAnimalRef()
    {
        $this->assertEquals(119627, $this->petData['animalref']);
    }

    public function testSponsor()
    {
        $this->assertTrue($this->petData['sponsored']);
    }

    public function testVisitNumber()
    {
        $this->assertEquals(1, $this->petData['visit_number']);
    }

    public function testSpecies()
    {
        $this->assertEquals('Dog', $this->petData['species']);
    }

    public function testName()
    {
        $this->assertEquals('Sophie', $this->petData['name']);
    }

    public function testAge()
    {
        $this->assertEquals(9, $this->petData['age']['years']);
        $this->assertEquals(5, $this->petData['age']['months']);
        $this->assertEquals('8 - 10', $this->petData['age']['bracket']);
    }

    public function testSex()
    {
        $this->assertEquals('Female', $this->petData['sex']);
    }

    public function testBreed()
    {
        $this->assertEquals('German Shepherd Dog', $this->petData['breed']);
    }

    public function testCrossbreed()
    {
        $this->assertEquals('Rottweiler', $this->petData['crossbreed']);
    }

    public function testHorseHeight()
    {
        $this->assertEquals(8.7, $this->petData['horse_height']);
    }

    public function testLocation()
    {
        $this->assertEquals('SAAC - Southampton', $this->petData['location']);
    }

    public function testDescription()
    {
        $this->assertEquals(
            '<p>Nice to meet you, I’m Sophie a 9 year old German Shepherd cross looking for a new home.</p><p>Sophie.</p>',
            $this->petData['description']
        );
    }

    public function testReserved()
    {
        $this->assertFalse($this->petData['reserved']);
    }

    public function testVideoUrl()
    {
        $this->assertEquals('http://youtube.com/12334', $this->petData['video_url']);
    }

    public function testColours()
    {
        $this->assertEquals(['Black', 'Tan'], $this->petData['colours']);
    }

    public function testImages()
    {
        $this->assertEquals('/tmp/96928.jpg', $this->petData['images']['featured_image_url']);
        $this->assertEquals(['/tmp/96929.jpg', '/tmp/96930.jpg'], $this->petData['images']['gallery_urls']);
    }

    public function testCanLiveWith()
    {
        $this->assertEquals(['Cats', 'Dogs', 'School age children'], $this->petData['can_live_with']);
    }

    public function testHorseSuitability()
    {
        $this->assertEquals(['Companion'], $this->petData['horse_suitability']);
    }

    public function testPetSkippedIfImagesDontExist()
    {
        unlink('/tmp/96928.jpg');
        $data = $this->petParser->parse(self::XML);
        $this->assertEquals([], $data['data']);
    }

    //public function testEmptyFile()
    //{
        //$data = $this->petParser->parse('');
        //$this->assertEquals([], $data['data']);
    //}
}
