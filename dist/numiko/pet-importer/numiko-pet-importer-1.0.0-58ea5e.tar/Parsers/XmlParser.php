<?php

declare(strict_types=1);

namespace Numiko\PetImporter\Parsers;

/**
 * Class: XmlParser
 *
 * A wrapper around an SimpleXmlElement to provide convenice methods to handle
 * the fetching and casting of XML data.
 *
 * @author Dan Bentley
 */
class XmlParser
{
    protected $simpleXmlElement;

    /**
     * setSimpleXmlElement
     *
     * @param \SimpleXmlElement $simpleXmlElement
     */
    public function setSimpleXmlELement(\SimpleXmlElement $simpleXmlElement=null): void
    {
        $this->simpleXmlElement = $simpleXmlElement;
    }

    /**
     * __construct
     *
     * @param \SimpleXmlElement $simpleXmlElement
     */
    public function __construct(\SimpleXmlElement $simpleXmlElement=null)
    {
        $this->setSimpleXmlElement($simpleXmlElement);
    }

    /**
     * loadXmlString
     *
     * Create a SimpleXmlElement from a string for parsing
     *
     * @param string $xml
     */
    public function loadXmlString(string $xml): void
    {
        $this->setSimpleXmlElement(simplexml_load_string($xml));
    }

    /**
     * findFloatByXPath
     *
     * Find the first element matching xpath and cast to float.
     *
     * @param mixed $XPath
     *
     * @return float|null
     */
    public function findFloatByXPath(string $XPath): ?float
    {
        $results = $this->simpleXmlElement->xpath($XPath);
        if (count($results) > 0 && (bool) $results[0]) {
            return (float) $results[0];
        }

        return null;
    }

    /**
     * findFloatsByXPath
     *
     * Find the all elements matching xpath and cast to float.
     *
     * @param string $XPath
     *
     * @return float[]|[] returns empty array if nothing found
     */
    public function findFloatsByXPath(string $XPath): array
    {
        $results = $this->simpleXmlElement->xpath($XPath);
        return array_map(function ($result) {
            return ((bool) $result) ? (float) $result : null;
        }, $results);
    }

    /**
     * findIntegerByXPath
     *
     * Find the first element matching xpath and cast to integer.
     *
     * @param mixed $XPath
     *
     * @return int|null
     */
    public function findIntegerByXPath(string $XPath): ?int
    {
        $results = $this->simpleXmlElement->xpath($XPath);
        if (count($results) > 0 && (bool) $results[0]) {
            return (int) $results[0];
        }

        return null;
    }

    /**
     * findIntegerByXPath
     *
     * Find the all elements matching xpath and cast to int.
     *
     * @param string $XPath
     *
     * @return int[]|[] returns empty array if nothing found
     */
    public function findIntegersByXPath(string $XPath): array
    {
        $results = $this->simpleXmlElement->xpath($XPath);
        return array_map(function ($result) {
            return ((bool) $result) ? (int) $result : null;
        }, $results);
    }

    /**
     * findBooleanByXPath
     *
     * Find the first element matching xpath and cast to boolean.
     *
     * @param mixed $XPath
     *
     * @return boolean|null
     */
    public function findBooleanByXPath(string $XPath, $mappings = ['Yes' => true, 'No' => false]): ?bool
    {
        $results = $this->simpleXmlElement->xpath($XPath);
        if (count($results) > 0 && (bool) $results[0]) {
            $value = (string) $results[0];
            return (array_key_exists($value, $mappings)) ? $mappings[$value] : null;
        }

        return null;
    }

    /**
     * findBooleansByXPath
     *
     * Find the all elements matching xpath and cast to boolean.
     *
     * @param string $XPath
     *
     * @return bool[]|[] returns empty array if nothing found
     */
    public function findBooleansByXPath(string $XPath, $mappings = ['Yes' => true, 'No' => false]): array
    {
        $results = $this->simpleXmlElement->xpath($XPath);
        return array_map(function ($result) use ($mappings) {
            $value = (string) $result;
            return ((bool) $result && array_key_exists($value, $mappings)) ? $mappings[$value] : null;
        }, $results);
    }

    /**
     * findStringByXPath
     *
     * Find the first element matching xpath and cast to string.
     *
     * @param mixed $XPath
     *
     * @return string|null
     */
    public function findStringByXPath(string $XPath): ?string
    {
        $results = $this->simpleXmlElement->xpath($XPath);
        if (count($results) > 0 && (bool) $results[0]) {
            return (string) $results[0];
        }

        return null;
    }

    /**
     * findStringByXPath
     *
     * Find the all elements matching xpath and cast to string.
     *
     * @param string $XPath
     *
     * @return string[]|[] returns empty array if nothing found
     */
    public function findStringsByXPath(string $XPath): array
    {
        $results = $this->simpleXmlElement->xpath($XPath);
        return array_map(function ($result) {
            return ((bool) $result) ? (string) $result : null;
        }, $results);
    }

    /**
     * parserByXPath
     *
     * Return a XmlParser instance for all elements matching xpath.
     *
     * This method is used to iterate over child elements that need additional
     * querying
     *
     * @param string $XPath
     * @return XPath[]|[] returns empty array if nothing found
     */
    public function parserByXPath(string $XPath): array
    {
        $results = $this->simpleXmlElement->xpath($XPath);
        return array_map(function ($result) {
            return new self($result);
        }, $results);
    }
}
