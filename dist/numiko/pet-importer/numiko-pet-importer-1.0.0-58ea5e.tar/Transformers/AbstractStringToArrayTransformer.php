<?php

declare(strict_types=1);

namespace Numiko\PetImporter\Transformers;

/**
 * Class: AbstractStringToArrayTransformer
 *
 * Map a string value to a range of values.
 *
 * e.g
 *
 * "Cat & dog" => ["Cat", "Dog",]
 *
 * @see TransformerInterface
 * @abstract
 *
 * @author Dan Bentley
 */
abstract class AbstractStringToArrayTransformer implements TransformerInterface
{
    /**
     * __construct
     *
     * @throws RuntimeException is VALUES isn't defined in concrete class
     */
    public function __construct()
    {
        if (!defined('static::VALUES')) {
            throw new \RuntimeException(
                'All AbstractStringToArrayTransformer subclasses need to define a VALUES constant'
            );
        }
    }

    /**
     * transform
     *
     * @param mixed $value
     * @return array empty array is returned if no match is found
     */
    public function transform($value=null): array
    {
        if (!$value) {
            return [];
        }

        $key = strtolower($value);
        return (array_key_exists($key, static::VALUES)) ? static::VALUES[$key] : [];
    }
}
