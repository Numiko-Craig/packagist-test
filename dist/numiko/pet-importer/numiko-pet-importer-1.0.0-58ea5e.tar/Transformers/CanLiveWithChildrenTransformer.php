<?php

declare(strict_types=1);

namespace Numiko\PetImporter\Transformers;

/**
 * Class: CanLiveWithChildrenTransformer
 *
 * Map a string value to a range of values.
 *
 * e.g
 *
 * "Cat & dog" => ["Cat", "Dog",]
 *
 * Even though the values map to an array with an single value, this transformer
 * gives us flexbility in the future.
 *
 * @see AbstractStringToArrayTransformer
 *
 * @author Dan Bentley
 */
class CanLiveWithChildrenTransformer extends AbstractStringToArrayTransformer
{
    public const VALUES = [
        'school age' => ['School age children'],
        'any age' => ['All age children'],
    ];
}
