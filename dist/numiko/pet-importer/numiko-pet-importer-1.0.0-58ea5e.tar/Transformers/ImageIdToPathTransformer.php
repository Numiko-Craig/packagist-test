<?php

declare(strict_types=1);

namespace Numiko\PetImporter\Transformers;

/**
 * Class: ImageIdToPathTransformer
 *
 * Transforms the image name into a fully qualified path to the image resource
 *
 * @author Dan Bentley
 */
class ImageIdToPathTransformer implements TransformerInterface
{
    private const EXTENSION = 'jpg';

    /**
     * imagePath
     *
     * @var string
     */
    protected $imagePath;

    /**
     * __construct
     *
     * @param string $imagePath
     */
    public function __construct(string $imagePath='')
    {
        $this->setImagePath($imagePath);
    }

    /**
     * setImagePath
     *
     * @param string $imagePath
     */
    public function setImagePath(string $imagePath)
    {
        $this->imagePath = $imagePath;
    }

    /**
     * transform
     *
     * @param int $id
     * @return string
     */
    public function transform(int $id=0): string
    {
        return $this->imagePath . $id . '.' . self::EXTENSION;
    }
}
