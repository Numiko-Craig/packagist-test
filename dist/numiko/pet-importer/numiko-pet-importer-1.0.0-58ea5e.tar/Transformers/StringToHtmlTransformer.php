<?php

declare(strict_types=1);

namespace Numiko\PetImporter\Transformers;

/**
 * Class: StringToHtmlTransformer
 *
 * Transforms linebreaks into <p> elements
 *
 * @author Dan Bentley
 */
class StringToHtmlTransformer implements TransformerInterface
{
    /**
     * transform
     *
     * @param ?string $stringToTransform
     * @return string
     */
    public function transform(?string $stringToTransform=''): string
    {
        if (!$stringToTransform) {
            return '';
        }

        $parts = array_filter(explode(PHP_EOL, $stringToTransform));

        $parts = array_map(function ($value) {
            return '<p>' . $value . '</p>';
        }, $parts);

        return implode($parts, '');
    }
}
