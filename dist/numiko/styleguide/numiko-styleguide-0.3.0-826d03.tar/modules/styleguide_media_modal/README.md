# Styleguide Media Modal

Adds additional data for use in modal output for video / image media entities.

## Install

* Install the module as usual
* Go to "Manage display" for the media type to enable the modal
* Drag in the "Media Modal" field to the appropriate display settings

## Usage

After installation the following fields will be available from the media template:

### General

* `{{ modal_data.id }}`
* `{{ modal_data.type }}`
* `{{ modal_data.title }}`

### Video

* `{{ modal_data.video_file }}`

### Image

* `{{ modal_data.image_src }}`
* `{{ modal_data.image_width }}`
* `{{ modal_data.image_height }}`
* `{{ modal_data.image_alt }}`
* `{{ modal_data.image_aspect_ratio }}`
* `{{ modal_data.caption }}`