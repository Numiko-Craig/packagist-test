<?php

namespace Drupal\styleguide_media_modal\Factory;

use Drupal\Core\Entity\EntityInterface;

/**
 * Get an appropriate media modal service.
 */
class MediaModalFactory {

  /**
   * Get the media modal service required from the entity.
   */
  public function getMediaModal(EntityInterface $entity) {
    switch ($entity->bundle()) {
      case 'core_video':
        return \Drupal::service('styleguide_media_modal.video');

      case 'image':
        return \Drupal::service('styleguide_media_modal.image');

      default:
        throw new \Exception("Media bundle not supported by media modal");
    }
  }

}
