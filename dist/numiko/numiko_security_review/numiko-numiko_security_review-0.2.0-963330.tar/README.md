# Numiko Security Review

Additional checks for the [Security Review module](https://drupal.org/project/security_review).

## Reasons why this is a separate module

* Password policy check is very specific
* Security Review is not well-maintained and this code would have to exist as a patch until
changes are accepted
* Some of these checks depend on other non-core modules - I'm not sure what the policy on that is for Security Review
* Would need to fix tests in Security Review (do this anyway?)
