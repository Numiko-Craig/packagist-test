<?php

namespace Drupal\numiko_security_review\Checks;

use Drupal\Component\Discovery\YamlDiscovery;
use Drupal\security_review\Check;
use Drupal\security_review\CheckResult;

/**
 * Check for routes in custom modules that are unprotected.
 *
 * These may not be a problem but the reviewer can then check them individually.
 */
class RoutesAccess extends Check {

  /**
   * {@inheritdoc}
   */
  public function getNamespace() {
    return 'Security Review';
  }

  /**
   * {@inheritdoc}
   */
  public function getTitle() {
    return 'Routes access check';
  }

  /**
   * {@inheritdoc}
   */
  public function getMachineTitle() {
    return 'routes_access';
  }

  /**
   * {@inheritdoc}
   */
  public function run() {
    $moduleDirectories = $this->container->get('module_handler')
      ->getModuleDirectories();
    $customModuleDirectories = array_filter($moduleDirectories, function ($path) {
      if (strpos($path, 'modules/custom') !== FALSE) {
        return TRUE;
      }
    });

    $discovery = new YamlDiscovery(
      'routing',
      $customModuleDirectories
    );
    $result = CheckResult::INFO;
    $findings = [];

    foreach ($discovery->findAll() as $routes) {
      unset($routes['route_callbacks']); // @todo
      foreach ($routes as $name => $routeInfo) {
        $findings += $this->checkRoutePermissions($name, $routeInfo);
        $findings += $this->checkRouteAccess($name, $routeInfo);
        $findings += $this->checkRouteRoles($name, $routeInfo);
        $findings += $this->checkOtherRequirements($name, $routeInfo);
        $findings += $this->checkUserIsLoggedInRequirement($name, $routeInfo);
      }
    }

    if (empty($findings)) {
      $result = CheckResult::SUCCESS;
    }

    return $this->createResult($result, $findings);
  }

  /**
   * Check if route permissions are permissive.
   *
   * @param string $name
   *   The route name.
   * @param array $routeInfo
   *   Array of route data.
   *
   * @return array
   *   Findings to add to results.
   */
  protected function checkRoutePermissions($name, $routeInfo) {
    $findings = [];
    if (isset($routeInfo['requirements'])) {
      if (isset($routeInfo['requirements']['_permission'])) {
        $access = $routeInfo['requirements']['_permission'];
        $permissivePerms = [
          'access content',
        ];
        foreach ($permissivePerms as $perm) {
          if (strpos(strtolower($access), $perm) !== FALSE) {
            $findings[$name] = 'Route _permission is open';
          }
        }
      }
    }
    return $findings;
  }

  /**
   * Check if route access settings permissive.
   *
   * @param string $name
   *   The route name.
   * @param array $routeInfo
   *   Array of route data.
   *
   * @return array
   *   Findings to add to results.
   */
  protected function checkRouteAccess($name, $routeInfo) {
    $findings = [];
    if (isset($routeInfo['requirements'])) {
      if (isset($routeInfo['requirements']['_access'])) {
        $access = $routeInfo['requirements']['_access'];
        if (strtoupper($access) === 'TRUE' || $access === TRUE) {
          $findings[$name] = 'Route _access is TRUE';
        }
      }
    }
    return $findings;
  }

  /**
   * Check if route roles is anonymous.
   *
   * @param string $name
   *   The route name.
   * @param array $routeInfo
   *   Array of route data.
   *
   * @return array
   *   Findings to add to results.
   */
  protected function checkRouteRoles($name, $routeInfo) {
    $findings = [];
    if (isset($routeInfo['requirements'])) {
      if (isset($routeInfo['requirements']['_role'])) {
        $role = $routeInfo['requirements']['_role'];
        if (stripos($role, 'anonymous') !== FALSE) {
          $findings[$name] = 'Route _role is "anonymous"';
        }
      }
    }
    return $findings;
  }

  /**
   * Check if route _user_is_logged_in = FALSE.
   *
   * @param string $name
   *   The route name.
   * @param array $routeInfo
   *   Array of route data.
   *
   * @return array
   *   Findings to add to results.
   */
  protected function checkUserIsLoggedInRequirement($name, $routeInfo) {
    $findings = [];
    if (isset($routeInfo['requirements'])) {
      if (isset($routeInfo['requirements']['_user_is_logged_in'])) {
        if ($routeInfo['requirements']['_user_is_logged_in'] === FALSE ||
          $routeInfo['requirements']['_user_is_logged_in'] === 'FALSE') {
          $findings[$name] = 'Route uses isuserloggedin = false';
        }
      }
    }
    return $findings;
  }

  /**
   * Check for obscure permissions settings that should be investigated.
   *
   * @param string $name
   *   The route name.
   * @param array $routeInfo
   *   Array of route data.
   *
   * @return array
   *   Findings to add to results.
   */
  protected function checkOtherRequirements($name, $routeInfo) {
    $findings = [];
    if (isset($routeInfo['requirements'])) {
      $checkFor = [
        '_entity_access',
        '_entity_bundles',
        '_entity_create_access',
        '_custom_access',
        '_access_user_register',
      ];
      foreach ($checkFor as $requirementKey) {
        if (isset($routeInfo['requirements'][$requirementKey])) {
          $findings[$name] = 'Route uses ' . $requirementKey . ' - check this manually';
        }
      }
    }
    return $findings;
  }



  /**
   * {@inheritdoc}
   */
  public function help() {
    $paragraphs = [];
    $paragraphs[] = $this->t("");

    return [
      '#theme' => 'check_help',
      '#title' => $this->t(''),
      '#paragraphs' => $paragraphs,
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function evaluate(CheckResult $result) {
    $findings = $result->findings();
    if (empty($findings)) {
      return [];
    }

    $paragraphs = [];
    $paragraphs[] = $this->t('The following routes are open.');

    $items = [];
    foreach ($findings as $routeId => $message) {
      $items[] = $routeId . ': ' . $message;
    }

    return [
      '#theme' => 'check_evaluation',
      '#paragraphs' => $paragraphs,
      '#items' => $items,
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function evaluatePlain(CheckResult $result) {
    $findings = $result->findings();
    if (empty($findings)) {
      return '';
    }

    $output = $this->t('Routes without access check:') . ":\n";
    foreach ($findings as $routeId => $message) {
      $output .= "\t" . $routeId . ': ' . $message . "\n";
    }

    return $output;
  }

  /**
   * {@inheritdoc}
   */
  public function getMessage($result_const) {
    switch ($result_const) {
      case CheckResult::SUCCESS:
        return $this->t('No unprotected routes.');

      case CheckResult::FAIL:
      case CheckResult::INFO:
        return $this->t('There are routes that do not provide any access checks.');

      default:
        return $this->t('Unexpected result.');
    }
  }

}
