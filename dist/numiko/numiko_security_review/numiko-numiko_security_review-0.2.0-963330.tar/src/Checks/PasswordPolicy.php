<?php

namespace Drupal\numiko_security_review\Checks;

use Drupal\security_review\Check;
use Drupal\security_review\CheckResult;
use Drupal\user\Entity\User;

/**
 * Checks whether untrusted roles have restricted permissions.
 */
class PasswordPolicy extends Check {

  const RECOMMENDED_MIN_PASSWORD_LENGTH = 10;

  /**
   * {@inheritdoc}
   */
  public function getNamespace() {
    return 'Security Review';
  }

  /**
   * {@inheritdoc}
   */
  public function getTitle() {
    return 'Password policy';
  }

  /**
   * {@inheritdoc}
   */
  public function getMachineTitle() {
    return 'password_policy';
  }

  /**
   * {@inheritdoc}
   */
  public function run() {
    // Check that the module is enabled.
    if (!$this->moduleHandler()->moduleExists('password_policy')) {
      return $this->createResult(CheckResult::FAIL, ['Module not enabled']);
    }

    // Check that at least one policy exists.
    // Password validation will pass if no policy exists.
    $policies = $this->container->get('entity_type.manager')
      ->getStorage('password_policy')
      ->loadMultiple();
    if (!$policies) {
      return $this->createResult(CheckResult::FAIL, ['No policy']);
    }

    // Check password policy for each role.
    $allRoles = user_roles(TRUE);
    $findings = [];

    foreach ($allRoles as $role) {
      $user = new User([], 'user');
      $user->addRole($role->id());

      $valid = \Drupal::service('password_policy.validator')
        ->validatePassword(
          'Nh.&uSHw9', // Varied characters but too short.
          $user,
          [$role->id()]
        );
      if ($valid) {
        $findings[] = 'Password below '
          . self::RECOMMENDED_MIN_PASSWORD_LENGTH . ' allowed for '
          . $role->label();
      }
    }

    if ($findings) {
      return $this->createResult(CheckResult::FAIL, $findings);
    }
    else {
      return $this->createResult(CheckResult::SUCCESS);
    }
  }

  /**
   * {@inheritdoc}
   */
  public function help() {
    $paragraphs = [];
    $paragraphs[] = $this->t("The password policy module should be enabled and each role should have a policy that mandates minimum 10 character password length.");
    return [
      '#theme' => 'check_help',
      '#title' => $this->t('Password Policy'),
      '#paragraphs' => $paragraphs,
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function evaluate(CheckResult $result) {
    $output = [];

    foreach ($result->findings() as $message) {
      $paragraphs = [];
      $paragraphs[] = $this->t(
        "blah",
      );

      $output[] = [
        '#theme' => 'check_evaluation',
        '#paragraphs' => $paragraphs,
        '#items' => $message,
      ];
    }

    return $output;
  }

  /**
   * {@inheritdoc}
   */
  public function evaluatePlain(CheckResult $result) {
    $output = '';

    foreach ($result->findings() as $message) {
      $output .= $message . "\n";
    }

    return $output;
  }

  /**
   * {@inheritdoc}
   */
  public function getMessage($result_const) {
    switch ($result_const) {
      case CheckResult::SUCCESS:
        return $this->t('Password policy configured correctly for all roles.');

      case CheckResult::FAIL:
        return $this->t('Password policy not configured correctly.');

      default:
        return $this->t("Unexpected result.");
    }
  }

}
