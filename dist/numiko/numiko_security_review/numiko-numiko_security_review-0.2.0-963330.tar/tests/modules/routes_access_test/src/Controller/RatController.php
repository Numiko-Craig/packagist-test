<?php

namespace Drupal\routes_access_test\Controller;

class RatController {

  function main() { }
  function access() { }

}
