<?php

namespace Drupal\numiko_security_review\Checks;

use Drupal\security_review\Check;
use Drupal\security_review\CheckResult;

class UserRegistration extends Check {

  /**
   * @inheritDoc
   */
  public function getNamespace() {
    return 'Security Review';
  }

  /**
   * @inheritDoc
   */
  public function getTitle() {
    return 'User registration';
  }

  /**
   * @inheritDoc
   */
  public function run() {
    $userSettings = \Drupal::config('user.settings');
    if ($userSettings->get('register') !== 'admin_only') {
      return $this->createResult(
        CheckResult::INFO,
        ['User registration is allowed']
      );
    }
    else {
      return $this->createResult(
        CheckResult::SUCCESS
      );
    }
  }

  /**
   * {@inheritdoc}
   */
  public function evaluate(CheckResult $result) {
    if ($result->result() == CheckResult::SUCCESS) {
      return [];
    }

    return [
      '#theme' => 'check_evaluation',
      '#paragraphs' => $result->findings(),
      '#items' => [],
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function evaluatePlain(CheckResult $result) {
    $output = '';

    foreach ($result->findings() as $message) {
      $output .= $message . "\n";
    }

    return $output;
  }

  /**
   * @inheritDoc
   */
  public function help() {
    return [];
  }

  /**
   * @inheritDoc
   */
  public function getMessage($result_const) {
    switch ($result_const) {
      case CheckResult::SUCCESS:
        return $this->t('User registration is not allowed.');

      case CheckResult::INFO:
      case CheckResult::FAIL:
        return $this->t('Confirm user registration settings.');

      default:
        return $this->t("Unexpected result.");
    }
  }

}
