<?php

namespace Drupal\numiko_security_review\tests\Kernel;

use Drupal\KernelTests\KernelTestBase;
use Drupal\numiko_security_review\Checks\WebformUploads;
use Drupal\security_review\CheckResult;

/**
 * Test that dangerous webform settings are detected by the WebformUploads check.
 */
class WebformUploadsTest extends KernelTestBase {

  /**
   * Modules to enable.
   *
   * @var array
   */
  protected static $modules = [
    'user',
    'security_review',
    'numiko_security_review',
    'webform',
  ];

  function testPublicUploadsNotAllowedAndAllElementsExcluded() {
    $this->config('webform.settings')
      ->set('file.file_public', false)
      ->set('element.excluded_elements', $this->getAllDangerousElements())
      ->save();

    $check = new WebformUploads();
    $result = $check->run();
    $this->assertEquals(
      CheckResult::SUCCESS,
      $result->result()
    );
  }

  function testPublicUploadsAllowed() {
    $this->config('webform.settings')
      ->set('file.file_public', true)
      ->set('element.excluded_elements', $this->getAllDangerousElements())
      ->save();

    $check = new WebformUploads();
    $result = $check->run();
    $this->assertEquals(
      CheckResult::FAIL,
      $result->result()
    );
  }

  function testAllDangerousElementsAllowed() {
    $this->config('webform.settings')
      ->set('file.file_public', false)
      ->set('element.excluded_elements', [])
      ->save();

    $check = new WebformUploads();
    $result = $check->run();
    $this->assertEquals(
      CheckResult::FAIL,
      $result->result()
    );
  }

  function testSomeDangerousElementsAllowed() {
    $elements = $this->getAllDangerousElements();
    unset($elements[1]);
    $this->config('webform.settings')
      ->set('file.file_public', false)
      ->set('element.excluded_elements', $elements)
      ->save();

    $check = new WebformUploads();
    $result = $check->run();
    $this->assertEquals(
      CheckResult::FAIL,
      $result->result()
    );
  }

  protected function getAllDangerousElements() {
    return [
      'managed_file',
      'password',
      'password_confirm',
      'webform_audio_file',
      'webform_document_file',
      'webform_image_file',
      'webform_signature',
      'webform_video_file',
    ];
  }

}
