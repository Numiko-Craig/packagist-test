<?php

namespace Drupal\numiko_security_review\tests\Kernel;

use Drupal\KernelTests\KernelTestBase;
use Drupal\numiko_security_review\Checks\PasswordPolicy as PasswordPolicyCheckAlias;
use Drupal\password_policy\Entity\PasswordPolicy;
use Drupal\security_review\CheckResult;
use Drupal\user\Entity\Role;

/**
 * Test that the password policy check find good and bad policies correctly.
 */
class PasswordPolicyTest extends KernelTestBase {

  /**
   * Modules to enable.
   *
   * @var array
   */
  protected static $modules = [
    'system',
    'user',
    'security_review',
    'numiko_security_review',
  ];

  function setUp(): void {
    parent::setUp();
    $this->installConfig('user');
    Role::create([
      'id' => 'test_role',
      'label' => 'Test Role'
    ])->save();
  }

  function testModuleNotEnabled() {
    $policyCheck = new PasswordPolicyCheckAlias();
    $result = $policyCheck->run();
    $this->assertEquals(
      CheckResult::FAIL,
      $result->result()
    );
    $this->assertContains(
      'Module not enabled',
      $result->findings()
    );
  }

  function testNoPolicy() {
    $this->installModules();
    $policyCheck = new PasswordPolicyCheckAlias();
    $result = $policyCheck->run();
    $this->assertEquals(
      CheckResult::FAIL,
      $result->result()
    );
    $this->assertContains(
      'No policy',
      $result->findings()
    );
  }

  function testGoodPolicy() {
    $this->installModules();
    $policy = $this->createPolicy();
    $constraints[] = [
      'id' => 'password_length',
      'character_length' => PasswordPolicyCheckAlias::RECOMMENDED_MIN_PASSWORD_LENGTH,
      'character_operation' => 'minimum',
    ];
    $policy->set('policy_constraints', $constraints);
    $policy->save();

    $policyCheck = new PasswordPolicyCheckAlias();
    $result = $policyCheck->run();
    $this->assertEquals(
      CheckResult::SUCCESS,
      $result->result()
    );
  }

  function testTooShortLengthPolicy() {
    $this->installModules();
    $policy = $this->createPolicy();
    $constraints[] = [
      'id' => 'password_length',
      'character_length' => PasswordPolicyCheckAlias::RECOMMENDED_MIN_PASSWORD_LENGTH-1,
      'character_operation' => 'minimum',
    ];
    $policy->set('policy_constraints', $constraints);
    $policy->save();

    $policyCheck = new PasswordPolicyCheckAlias();
    $result = $policyCheck->run();
    $this->assertEquals(
      CheckResult::FAIL,
      $result->result()
    );
  }

  protected function createPolicy() {
    return PasswordPolicy::create([
      'id' => 'test',
      'label' => 'test',
      'password_reset' => '1',
      'roles' => [
        'authenticated' => 'authenticated',
        'test_role' => 'test_role'
      ],
    ]);
  }

  protected function installModules() {
    \Drupal::service('module_installer')->install([
      'password_policy',
      'password_policy_length',
    ]);
  }

}
