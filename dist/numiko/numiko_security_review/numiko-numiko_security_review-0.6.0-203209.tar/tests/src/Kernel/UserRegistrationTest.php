<?php

namespace Drupal\numiko_security_review\tests\Kernel;

use Drupal\KernelTests\KernelTestBase;
use Drupal\numiko_security_review\Checks\UserRegistration;
use Drupal\security_review\CheckResult;

/**
 * Test that different user registration config values are detected by the
 * UserRegistration check.
 */
class UserRegistrationTest extends KernelTestBase {

  /**
   * Modules to enable.
   *
   * @var array
   */
  protected static $modules = [
    'system',
    'user',
    'security_review',
    'numiko_security_review',
  ];

  function testAdminOnlyReg() {
    $this->config('user.settings')
      ->set('register', 'admin_only')
      ->save();

    $check = new UserRegistration();
    $result = $check->run();
    $this->assertEquals(
      CheckResult::SUCCESS,
      $result->result()
    );
  }

  function testAdminApproval() {
    $this->config('user.settings')
      ->set('register', 'visitors_admin_approval')
      ->save();

    $check = new UserRegistration();
    $result = $check->run();
    $this->assertEquals(
      CheckResult::INFO,
      $result->result()
    );
  }

  function testVisitors() {
    $this->config('user.settings')
      ->set('register', 'visitors')
      ->save();

    $check = new UserRegistration();
    $result = $check->run();
    $this->assertEquals(
      CheckResult::INFO,
      $result->result()
    );
  }

}
