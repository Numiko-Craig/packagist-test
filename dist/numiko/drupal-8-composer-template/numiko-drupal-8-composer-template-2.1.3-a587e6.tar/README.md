# Numiko Composer template for Drupal Project

This template is a fork of [Composer template for Drupal Projects](https://github.com/drupal-composer/drupal-project) with additional functionality specific to Numiko.

## Usage

### Create the project

```
composer create-project numiko/drupal-8-composer-template:2.* PROJECT_NAME --stability dev --no-interaction --repository-url=https://numiko.github.io/packagist --ignore-platform-reqs
```

Where PROJECT_NAME is the folder to create the project in.

### Quick Environment & Docker Setup

Copy your key into the container context so that it can be accessed during the build, then run the setup script:

* `cat ~/.ssh/my_selected_key > docker/web/.env.key`
* `./scripts/docker/setup`

Now move on to *Install the site*

### Manual Environment Setup

1. Setup the environment variables in `.env` (duplicated from `.env.example`)
    ```
    cp .env.example .env
    ```
2. Add your SSH key to the docker container `docker/web/.env.key` (duplicated from `.env.key.example`)
    ```
    cat ~/.ssh/my_selected_key > docker/web/.env.key
    ```

### Manual Docker Setup

This script will download and install the docker configuration, so just run;

```
docker-compose build
docker-compose up -d
```

You can find out url / port by running

```
docker-compose ps
```

### Install the site

* Go to the site's domain in a browser and follow the steps to install (generating a secure password and adding the site name in the process)
* Alternatively, run `drush si` (site install)

## What does this template do

This template will:

* Drupal will be installed in the `docroot`-directory.
* Autoloader is implemented to use the generated composer autoloader in `vendor/autoload.php`,
  instead of the one provided by Drupal (`web/vendor/autoload.php`).
* Modules (packages of type `drupal-module`) will be placed in `docroot/modules/contrib/`
* Theme (packages of type `drupal-theme`) will be placed in `docroot/themes/contrib/`
* Profiles (packages of type `drupal-profile`) will be placed in `docroot/profiles/contrib/`
* Creates default writable versions of `settings.php` and `services.yml`.
* Creates `sites/default/files`-directory.
* Latest version of drush is installed locally for use at `vendor/bin/drush`.
* Latest version of DrupalConsole is installed locally for use at `vendor/bin/drupal`.
* Numiko install profiles added:
	* [Numiko D8 Profile](https://bitbucket.org/numiko/d8-profile)
* All dependencies of install profiles placed in appropriate directories

These files will then be ready for you to point the web server at and run the install process (selecting the profile best suited to the projects requirements).

For more information see [the original docs](https://github.com/drupal-composer/drupal-project).

## Installing new modules

Once the site has been installed, adding new modules must be done with composer. From the root of the site (as the modules are being added to the main composer.json):

```
composer require drupal/modulename
```

See https://packagist.drupal-composer.org for modules.

## Non-docker Setup

Even though docker is the default setup approach, you may have a requirement to use a non-docker approach.

### Point the domain

* Choose a domain (currently a \*.sites.numiko.local one), based on Numiko internal domain guidelines
* Setup the virtual host in Apache to accept the domain

## Working with this repo

After the project has been created the above steps can be removed from the README and replaced with the following usage.

### Usage

To get up & running do the following:

 * Git clone the repo
 * Copy the .env.example to .env:
```
cp .env.example .env
```
 * Duplicate the .env.key and add your key:
```
cp docker/web/.env.key.example docker/web/.env.key
```
 * Add a database dump to db-backups/
 * Docker build:
```
docker-compose build
```
 * Docker up:
```
docker-compose up -d
```
 * Composer install:
```
docker-compose exec web composer install
```
 * Copy the example.settings.local.php to the default directory:
```
cp sites/example.settings.local.php sites/default/settings.local.php
```
 * Import the database - the first command opens a bash terminal in the database container and will give no response:
```
  docker-compose exec db /bin/bash
  mysql -u drupal -pdrupal drupal </var/lib/mysql/backups/database-dump.sql
```
 * Now go to your site:
```
docker-compose ps
```

## Known Issues

* Currently pathauto causes an error on the status page, there are a number of ways around this issue ([all of them ugly one-off hacks](https://www.drupal.org/node/2601762#comment-10835098)), hopefully this will be resolved soon.
