# Numiko Theme

## What is it?

A Numiko Theme Starting point for theme creation in Drupal.
