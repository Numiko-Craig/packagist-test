# Webform Field Selector #

This module adds a new field formatter for webform entity references, allowing optional fields (marked within the webform element) to be selected when adding a webform.
