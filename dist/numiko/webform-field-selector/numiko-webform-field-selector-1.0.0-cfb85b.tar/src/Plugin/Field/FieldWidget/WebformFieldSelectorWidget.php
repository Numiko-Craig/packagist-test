<?php

namespace Drupal\webform_field_selector\Plugin\Field\FieldWidget;

use Drupal\Core\Field\FieldItemListInterface;
use Drupal\webform\Plugin\Field\FieldWidget\WebformEntityReferenceAutocompleteWidget;
use Drupal\Core\Form\FormStateInterface;
use Drupal\webform\WebformInterface;
use Drupal\Component\Utility\Html;

/**
 * Plugin implementation of the 'webform_field_selector' widget.
 *
 * @FieldWidget(
 *   id = "webform_field_selector",
 *   label = @Translation("Autocomplete Field Selector"),
 *   description = @Translation("An autocomplete text field with the ability to select fields from a webform."),
 *   field_types = {
 *     "webform_optional_fields"
 *   }
 * )
 */
class WebformFieldSelectorWidget extends WebformEntityReferenceAutocompleteWidget {

  /**
   * {@inheritdoc}
   */
  public static function defaultSettings() {
    return [
      'webform_to_use' => '',
      'allow_webform_override' => FALSE
    ] + parent::defaultSettings();
  }

  /**
   * {@inheritdoc}
   */
  public function settingsForm(array $form, FormStateInterface $form_state) {
    $elements = parent::settingsForm($form, $form_state);
 
    $elements['webform_to_use'] = [
      '#title' => $this->t('Webform to display'),
      '#type' => 'select',
      '#default_value' => $this->getSetting('webform_to_use'),
      '#options' => \Drupal::entityQuery('webform')->execute(),
    ];

    $elements['allow_webform_override'] = [
      '#title' => $this->t('Allow webform override'),
      '#type' => 'checkbox',
      '#default_value' => $this->getSetting('allow_webform_override'),
    ];

    return $elements;
  }

  /**
   * {@inheritdoc}
   */
  public function settingsSummary() {
    $summary = [];
    $webform_to_use = $this->getSetting('webform_to_use');
    $override = ($this->getSetting('allow_webform_override')) ? 'Override allowed' : 'No override allowed';
    if (empty($webform_to_use)) {
      $summary[] = $this->t('No webform selected');
    }
    else {
      if (!empty($webform_to_use)) {
        $summary[] = $this->t('Webform: @webform_to_use (@override)', ['@webform_to_use' => $webform_to_use, '@override' => $override]);
      }
    }
    return $summary;
  }

  /**
   * {@inheritdoc}
   */
  public function formElement(FieldItemListInterface $items, $delta, array $element, array &$form, FormStateInterface $form_state) {
    if (!isset($items[$delta]->status)) {
      $items[$delta]->status = WebformInterface::STATUS_OPEN;
    }

    $element = parent::formElement($items, $delta, $element, $form, $form_state);
    
    if (!$this->getSetting('allow_webform_override')) {
      $webform = \Drupal::entityTypeManager()->getStorage('webform')->load($this->getSetting('webform_to_use'));
      if ($webform) {
        $element['target_id']['#access'] = FALSE;
        $element['target_id']['#default_value'] = $webform;
      }
    }

    $selectedValues = [];
    if (!$items->get($delta)->get('optional_field_switch')->isEmpty()) {
      $selectedValues = $items->get($delta)->get('optional_field_switch')->getValue();
    }
    
    $element['settings']['optional_field_switch'] = [
      '#type' => 'checkboxes',
      '#options' => $this->getPotentialOptionalFields($element['target_id']['#default_value']),
      '#default_value' => $selectedValues,
      '#title' => $this->t('Tick the optional fields you wish to display'),
      '#description' => $this->t('Tick any of the pre-selected optional fields to display when the webform is displayed')
    ];
    
    return $element;
  }
  
  /**
   * Get a list of optional fields from the selected webform fields.
   */
  protected function getPotentialOptionalFields($webform) {
    $options = [];
    if ($webform) {
      $flattenedFormElements = $webform->getElementsDecodedAndFlattened();
      if ($flattenedFormElements) {
        $options = array_map(function($element) {
            return $element['#title'];
          }, array_filter($flattenedFormElements, function($element) {
            return (isset($element['#optional_field']) && $element['#optional_field']);
          }));
      }
    }
    return $options;
  }

}