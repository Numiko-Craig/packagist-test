# Paragraphs Parent Revision Access

Updating paragraphs while using content moderation requires access checking the parent entity that is being updated (not the latest published entity) so this module alters the access controller so it checks against the latest revision.
