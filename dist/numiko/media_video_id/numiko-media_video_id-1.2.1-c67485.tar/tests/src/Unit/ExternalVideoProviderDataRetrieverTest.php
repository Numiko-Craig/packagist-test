<?php

namespace Drupal\Tests\media_video_id\Unit;

use Drupal\Tests\UnitTestCase;
use Drupal\media_video_id\ExternalVideoProviderDataRetriever;

/**
 * Testing the parsing of video url's.
 */
class ExternalVideoProviderDataRetrieverTest extends UnitTestCase {

  /**
   * The data retriever.
   *
   * @var \Drupal\media_video_id\ExternalVideoProviderDataRetriever
   */
  protected $dataRetreiver;

  /**
   * Create new ExternalVideoProviderDataRetriever object.
   */
  public function setUp(): void {
    $this->dataRetreiver = new ExternalVideoProviderDataRetriever();
  }

  /**
   * @covers Drupal\media_video_id\ExternalVideoProviderDataRetriever::getExternalProviderVideoId
   * @covers Drupal\media_video_id\ExternalVideoProviderDataRetriever::getYoutubeId
   */
  public function testYoutubeVideoId() {
    $videoUrl = "https://www.youtube.com/watch?v=_KSxRj9YhG8";
    $expectedId = "_KSxRj9YhG8";
    $actualId = $this->dataRetreiver->getExternalProviderVideoId($videoUrl);
    $this->assertEquals($expectedId, $actualId);
  }

  /**
   * @covers Drupal\media_video_id\ExternalVideoProviderDataRetriever::getExternalProviderVideoId
   * @covers Drupal\media_video_id\ExternalVideoProviderDataRetriever::getYoutubeId
   */
  public function testYoutubeShareVideoId() {
    $videoUrl = "https://youtu.be/_KSxRj9YhG8";
    $expectedId = "_KSxRj9YhG8";
    $actualId = $this->dataRetreiver->getExternalProviderVideoId($videoUrl);
    $this->assertEquals($expectedId, $actualId);
  }

  /**
   * @covers Drupal\media_video_id\ExternalVideoProviderDataRetriever::getExternalProviderVideoId
   * @covers Drupal\media_video_id\ExternalVideoProviderDataRetriever::getVimeoId
   */
  public function testVimeoVideoId() {
    $videoUrl = "https://vimeo.com/392793169";
    $expectedId = "392793169";
    $actualId = $this->dataRetreiver->getExternalProviderVideoId($videoUrl);
    $this->assertEquals($expectedId, $actualId);
  }

  /**
   * @covers Drupal\media_video_id\ExternalVideoProviderDataRetriever::getProvider
   */
  public function testYoutubeVideoProvider() {
    $videoUrl = "https://www.youtube.com/watch?v=_KSxRj9YhG8";
    $expectedProvider = "youtube";
    $actualProvider = $this->dataRetreiver->getProvider($videoUrl);
    $this->assertEquals($expectedProvider, $actualProvider);
  }

  /**
   * @covers Drupal\media_video_id\ExternalVideoProviderDataRetriever::getProvider
   */
  public function testYoutubeShareVideoProvider() {
    $videoUrl = "https://youtu.be/_KSxRj9YhG8";
    $expectedProvider = "youtube";
    $actualProvider = $this->dataRetreiver->getProvider($videoUrl);
    $this->assertEquals($expectedProvider, $actualProvider);
  }

  /**
   * @covers Drupal\media_video_id\ExternalVideoProviderDataRetriever::getProvider
   */
  public function testVimeoVideoProvider() {
    $videoUrl = "https://vimeo.com/392793169";
    $expectedProvider = "vimeo";
    $actualProvider = $this->dataRetreiver->getProvider($videoUrl);
    $this->assertEquals($expectedProvider, $actualProvider);
  }

}
