<?php

namespace Drupal\domain_simple_sitemap\Routing;

use Drupal\Core\Routing\RouteSubscriberBase;
use Symfony\Component\Routing\RouteCollection;

/**
 * Listens to the dynamic route events.
 */
class RouteSubscriber extends RouteSubscriberBase {

  /**
   * {@inheritdoc}
   *
   * Override the sitemap controller.
   */
  protected function alterRoutes(RouteCollection $collection) {
    if ($route = $collection->get('simple_sitemap.sitemap_default')) {
      $route->setDefaults([
        '_controller' => '\Drupal\domain_simple_sitemap\Controller\DomainSimplesitemapController::getSitemap',
      ]);
    }
  }

}
