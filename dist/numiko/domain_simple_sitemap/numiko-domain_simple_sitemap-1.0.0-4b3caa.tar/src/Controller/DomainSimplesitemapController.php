<?php

namespace Drupal\domain_simple_sitemap\Controller;

use Drupal\simple_sitemap\Controller\SimplesitemapController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * Class DomainSimplesitemapController.
 *
 * @package Drupal\domain_simple_sitemap\Controller
 */
class DomainSimplesitemapController extends SimplesitemapController {

  /**
   * {@inheritdoc}
   *
   * Sets the current domain as the default variant so the sitemap can be
   * accessed at /sitemap.xml.
   */
  public function getSitemap(Request $request, $variant = NULL) {
    if (!$variant) {
      $variant = \Drupal::service('domain.negotiator')->getActiveId();
    }

    $output = $this->generator->setVariants($variant)->getSitemap($request->query->getInt('page'));
    if (!$output) {
      throw new NotFoundHttpException();
    }

    return new Response($output, Response::HTTP_OK, [
      'Content-type' => 'application/xml; charset=utf-8',
      'X-Robots-Tag' => 'noindex, follow',
    ]);
  }

}
