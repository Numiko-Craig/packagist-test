<?php

namespace Drupal\Tests\twig_smart_split\Kernel;

use Drupal\Core\DependencyInjection\ContainerBuilder;
use Drupal\Core\Messenger\MessengerTrait;
use Drupal\twig_smart_split\Twig\TwigSmartSplitExtension;
use Drupal\KernelTests\KernelTestBase;

/**
 * Tests Twig extensions.
 *
 * @group twig_smart_split
 */
class TwigSmartSplitExtensionTest extends KernelTestBase {

  use MessengerTrait;

  /**
   * Modules to enable.
   *
   * @var array
   */
  public static $modules = ['twig_smart_split'];

  /**
   * {@inheritdoc}
   */
  protected function setUp() {
    parent::setUp();
  }

  /**
   * {@inheritdoc}
   */
  public function register(ContainerBuilder $container) {
    parent::register($container);

    $parameters = $container->getParameter('twig.config');
    $parameters['debug'] = TRUE;
    $container->setParameter('twig.config', $parameters);
  }

  /**
   * Tests that Twig extension loads appropriately.
   */
  public function testTwigExtensionLoaded() {
    $twig_service = \Drupal::service('twig');
    $extension = $twig_service->getExtension(TwigSmartSplitExtension::class);
    $this->assertEquals(get_class($extension), TwigSmartSplitExtension::class, 'Twig Smart Split Extension loaded successfully.');
  }

  /**
   * Tests that the Twig extension filter produces the expected output.
   */
  public function testSmartSplitFilters() {
    /* @var \Drupal\Core\Template\TwigEnvironment $environment */
    $environment = \Drupal::service('twig');

    // Ensure that when only the first part of two para's is requested then only
    // show the first.
    $context = [
      'twig_string' => '<p>Some content</p><p>Some more content</p>',
    ];
    $template = '{{ twig_string|smart_split|first }}';
    $expected_template_output = '<p>Some content</p>';
    $output = (string) $environment->renderInline($template, $context);
    $this->assertSame($expected_template_output, $output, 'Outputting first element from smart_split');

    // Ensure that when only the first part of three para's is requested then
    // only show the first two.
    $context = [
      'twig_string' => '<p>Some content</p><p>Some more content</p><p>Some other content</p>',
    ];
    $template = '{{ twig_string|smart_split|first }}';
    $expected_template_output = '<p>Some content</p><p>Some more content</p>';
    $output = (string) $environment->renderInline($template, $context);
    $this->assertSame($expected_template_output, $output, 'Outputting first and second element from smart_split');

    // Ensure that when only a full-stop is available we seperate on that.
    $context = [
      'twig_string' => '<p>Some content Some more content. Some other content</p>',
    ];
    $template = '{{ twig_string|smart_split|first }}';
    $expected_template_output = '<p>Some content Some more content.</p>';
    $output = (string) $environment->renderInline($template, $context);
    $this->assertSame($expected_template_output, $output, 'Outputting first element split by full-stop from smart_split');

    // Ensure that when no seperator is found we just return the whole string
    // in the first part.
    $context = [
      'twig_string' => '<p>Some content Some more content - Some other content - and some more</p>',
    ];
    $template = '{{ twig_string|smart_split|first }}';
    $expected_template_output = '<p>Some content Some more content - Some other content - and some more</p>';
    $output = (string) $environment->renderInline($template, $context);
    $this->assertSame($expected_template_output, $output, 'Outputting first element with no split - so shows everything from smart_split');

    // Ensure that we can store the output and output both parts with a
    // seperator.
    $context = [
      'twig_string' => '<p>Some content</p><p>Some more content</p><p>Some other content</p>',
    ];
    $template = '{% set split_string = twig_string|smart_split %}{{ split_string|first }}|{{ split_string|last }}';
    $expected_template_output = '<p>Some content</p><p>Some more content</p>|<p>Some other content</p>';
    $output = (string) $environment->renderInline($template, $context);
    $this->assertSame($expected_template_output, $output, 'Outputting all elements with a seperator from smart_split');
  }

}
