<?php

namespace Drupal\custom_caption_filter\Plugin\Filter;

use Drupal\Component\Utility\Html;
use Drupal\Component\Utility\Unicode;
use Drupal\Component\Utility\Xss;
use Drupal\filter\FilterProcessResult;
use Drupal\filter\Plugin\FilterBase;
use Drupal\filter\Render\FilteredMarkup;

/**
 * Provides a filter to caption elements, with the <caption> element placed inside
 * the media embed template instead of the filter template (as with Drupal's
 * FilterCaption class, which this is heavily based on).
 *
 * @Filter(
 *   id = "embedded_caption_filter",
 *   title = @Translation("Caption images with caption placed within the media entity markup."),
 *   description = @Translation("Uses a caption tag within the media entity markup."),
 *   type = Drupal\filter\Plugin\FilterInterface::TYPE_TRANSFORM_REVERSIBLE
 * )
 */
class EmbeddedCaptionFilter extends FilterBase {

  /**
   * {@inheritdoc}
   */
  public function process($text, $langcode) {
    $result = new FilterProcessResult($text);

    if (stristr($text, 'data-caption') !== FALSE) {
      $dom = Html::load($text);
      $xpath = new \DOMXPath($dom);
      foreach ($xpath->query('//*[@data-caption]') as $node) {

        // Read the data-caption attribute's value, then delete it.
        $caption = Html::escape($node->getAttribute('data-caption'));
        $node->removeAttribute('data-caption');

        // Sanitize caption: decode HTML encoding, limit allowed HTML tags; only
        // allow inline tags that are allowed by default, plus <br>.
        $caption = Html::decodeEntities($caption);
        $caption = FilteredMarkup::create(Xss::filter($caption, array('a', 'em', 'strong', 'cite', 'code', 'br')));

        // The caption must be non-empty.
        if (Unicode::strlen($caption) === 0) {
          continue;
        }

        // Given the updated node and caption: re-render it with a caption, but
        // bubble up the value of the class attribute of the captioned element,
        // this allows it to collaborate with e.g. the filter_align filter.
        $tag = $node->tagName;
        $classes = $node->getAttribute('class');
        $node = ($node->parentNode->tagName === 'a') ? $node->parentNode : $node;

        $captionElement = new \DOMElement('figcaption', $caption);

        $descendant = $this->findDescendantWithClass($node, 'media__wrapper');
        if ($descendant) {
          $descendant->parentNode->appendChild($captionElement);
        }

        $filter_caption = array(
          '#theme' => 'filter_caption',
          // We pass the unsanitized string because this is a text format
          // filter, and after filtering, we always assume the output is safe.
          // @see \Drupal\filter\Element\ProcessedText::preRenderText()
          '#node' => FilteredMarkup::create($node->C14N()),
          '#tag' => $tag,
          '#caption' => '',
          '#classes' => $classes,
        );

        $altered_html = drupal_render($filter_caption);

        // Load the altered HTML into a new DOMDocument and retrieve the element.
        $updated_nodes = Html::load($altered_html)->getElementsByTagName('body')
          ->item(0)
          ->childNodes;

        foreach ($updated_nodes as $updated_node) {
          // Import the updated node from the new DOMDocument into the original
          // one, importing also the child nodes of the updated node.
          $updated_node = $dom->importNode($updated_node, TRUE);
          $node->parentNode->insertBefore($updated_node, $node);
        }
        // Finally, remove the original data-caption node.
        $node->parentNode->removeChild($node);

      }

      $result->setProcessedText(Html::serialize($dom))
        ->addAttachments(array(
          'library' => array(
            'filter/caption',
          ),
        ));
    }

    return $result;
  }

  /**
   * Recursively search for a descendant of a DOM node with a certain class.
   *
   * @param \DOMElement $node
   * @param string $className
   * @return \DOMElement
   */
  function findDescendantWithClass(\DOMElement $node, $className) {
    if ($node->hasChildNodes()) {
      foreach ($node->childNodes as $child) {
        if ($child instanceof \DOMElement) {

          if ($child->getAttribute('class') && strpos(
              $child->getAttribute('class'),
              $className
            ) !== FALSE
          ) {
            return $child;
          }
          else {
            return $this->findDescendantWithClass($child, $className);
          }

        }
      }
    }
    return null;
  }

  /**
   * {@inheritdoc}
   */
  public function tips($long = FALSE) {
    return '';
  }

}
