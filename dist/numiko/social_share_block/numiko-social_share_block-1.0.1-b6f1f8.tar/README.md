# Social Share Block

Provides a block plugin for displaying social share links. There is no configuraton for this block, content is derived from the node that is being displayed. Gives flexibility to position the social share block between other blocks and regions.

The provided block template gives a minimum layout with text based links and no icons. Copy this template to the theme before styling.