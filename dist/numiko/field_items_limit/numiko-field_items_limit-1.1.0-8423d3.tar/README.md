# Field Items Limit

This module contains a number of field formatters to show a limited number of items of the type given.

## Supported Field Types

Support for limiting the amount of items output is currently limited to the following field types.

* String
* Entity Reference Label