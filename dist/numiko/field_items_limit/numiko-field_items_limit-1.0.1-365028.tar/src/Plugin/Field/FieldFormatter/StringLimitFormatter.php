<?php

namespace Drupal\field_items_limit\Plugin\Field\FieldFormatter;

use Drupal\Core\Field\Plugin\Field\FieldFormatter\StringFormatter;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Form\FormStateInterface;

/**
 * Plugin implementation of the 'string' formatter.
 *
 * @FieldFormatter(
 *   id = "string_limit",
 *   label = @Translation("Plain text (with limit)"),
 *   field_types = {
 *     "string",
 *     "uri",
 *   }
 * )
 */
class StringLimitFormatter extends StringFormatter {

  /**
   * {@inheritdoc}
   */
  public static function defaultSettings() {
    $options = parent::defaultSettings();

    $options['limit'] = 0;
    return $options;
  }

  /**
   * {@inheritdoc}
   */
  public function settingsForm(array $form, FormStateInterface $form_state) {
    $form = parent::settingsForm($form, $form_state);

    $form['limit'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Limit to n items'),
      '#default_value' => $this->getSetting('limit'),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function settingsSummary() {
    $summary = [];
    if ($this->getSetting('link_to_entity')) {
      $entity_type = $this->entityManager->getDefinition($this->fieldDefinition->getTargetEntityTypeId());
      $summary[] = $this->t('Linked to the @entity_label', ['@entity_label' => $entity_type->getLabel()]);
    }
    if ($this->getSetting('limit')) {
      $summary[] = $this->t('Limited to @limit items', ['@limit' => $this->getSetting('limit')]);
    }
    return $summary;
  }

  /**
   * {@inheritdoc}
   */
  public function viewElements(FieldItemListInterface $items, $langcode) {
    $elements = parent::viewElements($items, $langcode);
    if ($this->getSetting('limit')) {
      return array_slice($elements, 0, $this->getSetting('limit'));
    }
    return $elements;
  }

}
