<?php

namespace Drupal\Tests\twig_field_values\Unit\Twig;

use Drupal\Core\Render\Markup;
use Drupal\Tests\UnitTestCase;
use Drupal\Core\Template\TwigExtension;
use Drupal\twig_field_values\Twig\FieldValuesTwigExtension;

/**
 * Testing the field values twig extension.
 */
class FieldValuesTwigExtensionTest extends UnitTestCase {

  /**
   * Create a new instance of FieldValuesTwigExtension.
   *
   * The fieldDisplayValueFilter makes heavy use of the renderVar function
   * which at its most basic level generates a Markup object which is then
   * transformed into a string.
   *
   * For this reason we can mock the renderVar function with a created Markup
   * object created from the same string as we want to feed into the various
   * methods being tested.
   */
  protected function getTwigExtensionFromString(string $string) {
    // Mock core twig extension.
    $twigExtension = $this->getMockBuilder(TwigExtension::class)
      ->disableOriginalConstructor()
      ->getMock();
    $twigExtension->method('renderVar')
      ->willReturn(Markup::create($string));
    return new FieldValuesTwigExtension($twigExtension);
  }

  /**
   * Test the field_display filter function.
   */
  public function testFieldDisplayValueFilter() {
    $fieldValue = "Just a plain text string";
    $twigExtension = $this->getTwigExtensionFromString($fieldValue);
    $actual = $twigExtension->fieldDisplayValueFilter(['#markup' => $fieldValue]);
    $expected = "Just a plain text string";
    $this->assertEquals($expected, $actual);
  }

  /**
   * Test the field_display filter function with comments.
   *
   * Field display should strip out comments.
   */
  public function testFieldDisplayValueFilterWithComments() {
    $fieldValue = "Just a plain text string<!-- with some comments -->";
    $twigExtension = $this->getTwigExtensionFromString($fieldValue);
    $actual = $twigExtension->fieldDisplayValueFilter(['#markup' => $fieldValue]);
    $expected = "Just a plain text string";
    $this->assertEquals($expected, $actual);
  }

  /**
   * Test the field_display filter function with HTML tags & comments.
   *
   * Field display should strip out comments.
   */
  public function testFieldDisplayValueFilterWithTagsAndComments() {
    $fieldValue = "<div>Just a text string with HTML<!-- with some comments --></div>";
    $twigExtension = $this->getTwigExtensionFromString($fieldValue);
    $actual = $twigExtension->fieldDisplayValueFilter(['#markup' => $fieldValue]);
    $expected = "<div>Just a text string with HTML</div>";
    $this->assertEquals($expected, $actual);
  }

  /**
   * Test the field_display filter function with special characters.
   */
  public function testFieldDisplayValueFilterWithSpecialCharacters() {
    $fieldValue = "Just a text string with special character's";
    $twigExtension = $this->getTwigExtensionFromString($fieldValue);
    $actual = $twigExtension->fieldDisplayValueFilter(['#markup' => $fieldValue]);
    $expected = "Just a text string with special character's";
    $this->assertEquals($expected, $actual);
  }

  /**
   * Test the has_value filter function with HTML tags & comments.
   *
   * Has value method should exclude comments.
   */
  public function testHasValueExcludesComments() {
    $fieldValue = "<!-- with some comments -->";
    $twigExtension = $this->getTwigExtensionFromString($fieldValue);
    $actual = $twigExtension->hasValueFunction(['#markup' => $fieldValue]);
    $expected = FALSE;
    $this->assertEquals($expected, $actual);
  }

  /**
   * Test the has_value filter function with HTML tags & comments.
   *
   * Has value method should exclude comments.
   */
  public function testHasValueMatchesTrue() {
    $fieldValue = "<div><!-- with some comments -->Some content</div>";
    $twigExtension = $this->getTwigExtensionFromString($fieldValue);
    $actual = $twigExtension->hasValueFunction(['#markup' => $fieldValue]);
    $expected = TRUE;
    $this->assertEquals($expected, $actual);
  }

  /**
   * Bool values array, and their expected mapping.
   */
  public function boolValueProvider() {
    return [
      ["False", FALSE],
      ["No", FALSE],
      ["Off", FALSE],
      ["Disabled", FALSE],
      ["", FALSE],
      ["<div></div>", FALSE],
      ["<div><!-- with JUST some comments --></div>", FALSE],
      ["0", FALSE],
      ["True", TRUE],
      ["Yes", TRUE],
      ["On", TRUE],
      ["Enabled", TRUE],
      ["Any content", TRUE],
      ["1", TRUE],
    ];
  }

  /**
   * Test the bool_value filter function matches the expected value.
   *
   * Bool value filter should exclude markup and still match true/false.
   *
   * @dataProvider boolValueProvider
   */
  public function testBoolValueComparisonExcludesTags($boolValue, $expectedValue) {
    $fieldValue = "<div><!-- with some comments -->{$boolValue}</div>";
    $twigExtension = $this->getTwigExtensionFromString($fieldValue);
    $actual = $twigExtension->boolValueFilter(['#markup' => $fieldValue]);
    $this->assertEquals($actual, $expectedValue);
  }

  /**
   * Test the array_value filter function.
   *
   * Array value filter should exclude comments from all markup items in an
   * array of field values.
   */
  public function testArrayValueFilterExcludesComments() {
    $fieldValues = [
      ['#markup' => "This value<!-- with some comments -->"],
      ['#markup' => "<div>That value<!-- with some comments --></div>"],
      ['#markup' => "Another value's value<!-- with some comments -->"],
      ['#markup' => "TRUE<!-- with some comments -->"],
      ['#markup' => "<!-- with some comments -->FALSE"],
    ];
    $expectedValues = [
      "This value",
      "<div>That value</div>",
      "Another value's value",
      "TRUE",
      "FALSE",
    ];
    $twigExtension = $this->getTwigExtensionFromString("");
    $actual = $twigExtension->arrayValueFilter($fieldValues);
    $this->assertEquals($actual, $expectedValues);
  }

}
