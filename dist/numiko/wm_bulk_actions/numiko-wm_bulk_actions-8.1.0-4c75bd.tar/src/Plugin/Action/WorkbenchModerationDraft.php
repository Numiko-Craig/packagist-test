<?php

namespace Drupal\wm_bulk_actions\Plugin\Action;

/**
 * Returns a node to draft.
 *
 * @Action(
 *   id = "workbench_moderation_node_draft_action",
 *   label = @Translation("Workbench Moderation Return to Draft"),
 *   type = "node"
 * )
 */
class WorkbenchModerationDraft extends AbstractWorkbenchModerationAction
{
	const STATE_TARGET = 'draft';
}
