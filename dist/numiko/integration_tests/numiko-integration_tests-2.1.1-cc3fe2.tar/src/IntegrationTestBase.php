<?php

namespace Drupal\integration_tests;

use Drupal\Core\Session\AnonymousUserSession;
use Drupal\Core\Url;
use Drupal\search_api_solr\Utility\SolrCommitTrait;
use weitzman\DrupalTestTraits\ExistingSiteBase;

/**
 * A test base class for integration tests.
 *
 * Useful methods are provided for testing a Drupal site loaded with
 * configuration.
 */
abstract class IntegrationTestBase extends ExistingSiteBase {

  use EntityCreationTrait, AssertTrait, SolrCommitTrait;

  /**
   * {@inheritDoc}
   */
  protected function setUp(): void {
    parent::setUp();
    // It is necessary to clear the cache before each test so we have a
    // known state. If it is desirable to check whether functionality is
    // playing nicely with the cache, then create tests to check this
    // explicitly, rather than relying on the cache being preserved between
    // tests.
    $this->clearCache();
  }

  /**
   * Create a user with a persona and login.
   */
  protected function createUserWithPersonaAndLogin(array $personas) {
    // Create a user with a the given role machine name.
    $user = $this->createUserWithPersonas($personas);

    // Login.
    $this->drupalGet('user/login');
    $this->submitForm([
      'name' => $user->getAccountName(),
      'pass' => $user->passRaw,
    ], t('Log in'));

    $this->setCurrentUser($user);
  }

  /**
   * Create a user with a role and login.
   */
  protected function createUserWithRoleAndLogin(string $role) {
    // Create a user with a the given role machine name.
    $user = $this->createUser();
    $user->addRole($role);
    $user->save();

    // Login.
    $this->drupalGet('user/login');
    $this->submitForm([
      'name' => $user->getAccountName(),
      'pass' => $user->passRaw,
    ], t('Log in'));

    $this->setCurrentUser($user);
  }

  /**
   * Index any items that are waiting to be indexed.
   *
   * @param string $searchIndex
   *   The search index ID. The default 'site' is the one that comes with the
   *   install profile.
   *
   * @throws \Drupal\Component\Plugin\Exception\PluginException
   * @throws \Drupal\search_api\SearchApiException
   */
  protected function indexItemsInSearch($searchIndex = 'site') {
    $index = $this->container->get('entity_type.manager')
      ->getStorage('search_api_index')
      ->load($searchIndex);

    $index->indexItems();
    $this->ensureCommit($index);
  }

  /**
   * Indexes all (unindexed) items on the specified index.
   *
   * @param string $searchIndex
   *   The search index ID. The default 'site' is the one that comes with the
   *   install profile.
   *
   * @throws \Drupal\Component\Plugin\Exception\PluginException
   * @throws \Drupal\search_api\SearchApiException
   */
  protected function clearIndex($searchIndex = 'site') {
    $index = $this->container->get('entity_type.manager')
      ->getStorage('search_api_index')
      ->load($searchIndex);

    $index->clear();
    $this->ensureCommit($index);
  }
  /**
   * Clear Drupal's cache.
   */
  protected function clearCache() {
    drupal_flush_all_caches();
  }

  /**
   * Override UiHelperTrait::drupalLogout to allow for changes to login form.
   *
   * UiHelperTrait::drupalLogout checks for username and password fields on the
   * form. We may want to use email instead of username.
   */
  protected function drupalLogout() {
    $this->drupalGet(
      Url::fromRoute('user.logout', [], ['query' => ['destination' => 'user']])
    );

    // @see BrowserTestBase::drupalUserIsLoggedIn()
    unset($this->loggedInUser->sessionId);
    $this->loggedInUser = FALSE;
    $this->container->get('current_user')->setAccount(new AnonymousUserSession());
  }

}
