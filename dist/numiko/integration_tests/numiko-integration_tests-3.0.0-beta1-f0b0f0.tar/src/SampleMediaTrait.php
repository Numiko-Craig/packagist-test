<?php

namespace Drupal\integration_tests;

use Drupal\media\MediaInterface;
use Drupal\Core\File\FileSystemInterface;
use weitzman\DrupalTestTraits\Entity\MediaCreationTrait;

/**
 * A trait for creating sample media items.
 *
 * This includes core video and images (from a sample image - in the assets
 * folder).
 */
trait SampleMediaTrait {

  use AssertTrait, MediaCreationTrait;

  /**
   * Get a sample document media item.
   */
  public function getSampleDocumentMedia(array $settings = [], string $destinationFileName = 'sample_document.pdf') : MediaInterface {
    $source = __DIR__ . '/../tests/assets/sample_document.pdf';
    $destination = "public://" . $destinationFileName;
    $file = \Drupal::service('file.repository')->writeData(file_get_contents($source), $destination, FileSystemInterface::EXISTS_REPLACE);
    $settings += [
      'bundle' => 'document',
      'field_media_file' => ['target_id' => $file->id()],
    ];
    return $this->createMedia($settings);
  }

  /**
   * Get a sample image media item.
   */
  public function getSampleImageMedia(array $settings = [], string $destinationFileName = 'sample_image.jpg') : MediaInterface {
    $source = __DIR__ . '/../tests/assets/sample_image.jpg';
    $destination = "public://" . $destinationFileName;
    $file = \Drupal::service('file.repository')->writeData(file_get_contents($source), $destination, FileSystemInterface::EXISTS_REPLACE);
    $settings += [
      'bundle' => 'image',
      'field_image' => ['target_id' => $file->id()],
    ];
    return $this->createMedia($settings);
  }

  /**
   * Get a sample core video media item.
   */
  public function getSampleCoreVideoMedia(array $settings = []) : MediaInterface {
    $settings += [
      'bundle' => 'core_video',
    ];
    return $this->createMedia($settings);
  }

  /**
   * Find the media image source.
   */
  protected function findMediaImageSource(MediaInterface $media) {
    return $media->field_image->entity->getFilename();
  }

}
