<?php

namespace Drupal\Tests\integration_tests\ExistingSite\Workflow;

use Drupal\integration_tests\IntegrationTestBase;
use Symfony\Component\HttpFoundation\Response;

/**
 * Test workflow transitions.
 *
 * @group workflow
 */
class Workflow extends IntegrationTestBase {

  /**
   * Checks the workflow transition from draft to published.
   */
  public function testDraftToPublished() {
    $this->createUserWithPersonaAndLogin(['editor']);

    $node = $this->createNode();
    $this->drupalGet('node/' . $node->id() . '/edit');
    $this->assertEquals($node->get('moderation_state')->value, 'draft');

    $page = $this->getCurrentPage();
    $page->fillField('moderation_state[0][state]', 'published');
    $submit_button = $page->findButton('Save');
    $submit_button->press();

    $node = \Drupal::entityTypeManager()->getStorage('node')->loadUnchanged($node->id());
    $this->assertEquals($node->get('moderation_state')->value, 'published');
  }

  /**
   * Checks the creation of a new draft of a published node.
   */
  public function testNewDraft() {
    $this->createUserWithPersonaAndLogin(['editor']);

    // Create a new published node and check the state.
    $node = $this->createPublishedNode();
    $this->assertEquals($node->get('moderation_state')->value, 'published');

    // Edit the node and save as a draft.
    $this->drupalGet('node/' . $node->id() . '/edit');
    $page = $this->getCurrentPage();
    $page->fillField('title[0][value]', 'New_draft_page');
    $page->fillField('moderation_state[0][state]', 'draft');
    $submit_button = $page->findButton('Save');
    $submit_button->press();

    // Check we can view the latest version and the title was updated.
    $this->visitCheckCode('node/' . $node->id() . '/latest', Response::HTTP_OK);
    $this->assertSession()->pageTextContains('New_draft_page');

    // Check the published page was not effected by the title update.
    $this->drupalGet('node/' . $node->id());
    $this->assertSession()->pageTextContains($node->getTitle());
  }

  /**
   * Checks the archived transition.
   */
  public function testArchived() {
    $this->createUserWithPersonaAndLogin(['editor']);

    $node = $this->createPublishedNode();
    $this->drupalGet('node/' . $node->id() . '/edit');
    $page = $this->getCurrentPage();
    $page->fillField('moderation_state[0][state]', 'archived');
    $submit_button = $page->findButton('Save');
    $submit_button->press();

    $node = \Drupal::entityTypeManager()->getStorage('node')->loadUnchanged($node->id());
    $this->assertEquals($node->get('moderation_state')->value, 'archived');

    // Check the node cannot be viewed logged out.
    $this->drupalLogout();
    $this->visitCheckCode('node/' . $node->id(), Response::HTTP_FORBIDDEN);
  }

}
