<?php

namespace Drupal\Tests\integration_tests\ExistingSite\Slices;

use Drupal\integration_tests\IntegrationTestBase;
use Symfony\Component\HttpFoundation\Response;

/**
 * Test that an accordion can be created/edited.
 *
 * @group slices
 */
class AccordionSliceTest extends IntegrationTestBase {

  /**
   * Test adding an accordion slice to a node.
   */
  public function testCreateContentSlice() {
    $this->createUserWithPersonaAndLogin(['editor']);
    $num = rand(1, 5);
    for ($x = 1; $x <= $num; $x++) {
      $items[] = $this->createParagraph('accordion_item', [
        'field_title' => 'Accordion item ' . $x,
        'field_content' => 'Accordion content ' . $x,
      ]);
    }
    $paragraphs[] = $this->createParagraph('slice_accordion', [
      'field_title' => 'Accordion Slice',
      'field_items' => $items,
    ]);

    $node = $this->createNode(['field_slices' => $paragraphs]);

    $this->visitCheckCode('node/' . $node->id(), Response::HTTP_OK);
    $this->assertSession()->pageTextContains('Accordion Slice');
    for ($x = 1; $x <= $num; $x++) {
      $this->assertSession()->pageTextContains('Accordion item ' . $x);
      $this->assertSession()->pageTextContains('Accordion content ' . $x);
    }
  }

}
