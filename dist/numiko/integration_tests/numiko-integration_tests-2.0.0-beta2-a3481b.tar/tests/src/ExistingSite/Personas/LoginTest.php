<?php

namespace Drupal\Tests\integration_tests\ExistingSite\Personas;

use Drupal\integration_tests\IntegrationTestBase;
use Symfony\Component\HttpFoundation\Response;

/**
 * Test that an admin user can login.
 *
 * @group personas
 * @group smoke_test
 */
class LoginTest extends IntegrationTestBase {

  public function testLogin() {
    $this->createUserWithPersonaAndLogin(['editor']);
    $this->visitCheckCode('admin/content', Response::HTTP_OK);
  }

}
