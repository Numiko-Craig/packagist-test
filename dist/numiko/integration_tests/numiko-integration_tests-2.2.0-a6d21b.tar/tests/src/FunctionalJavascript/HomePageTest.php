<?php

namespace Drupal\Tests\integration_tests\FunctionalJavascript;

use Drupal\integration_tests\AssertTrait;
use Drupal\integration_tests\IntegrationTestBase;
use Symfony\Component\HttpFoundation\Response;
use Drupal\integration_tests\ScreenShotTrait;
use weitzman\DrupalTestTraits\WebDriverTrait;

/**
 * Test the home page is viewable.
 *
 * @group content
 * @group smoke_test
 */
class HomePageTest extends IntegrationTestBase {

  use AssertTrait;
  use WebDriverTrait;
  use ScreenShotTrait;

  /**
   * Test the homepage can be viewed.
   */
  public function testAnonymousCanViewHomePage() {
    $this->visitCheckCode('<front>', Response::HTTP_OK);
    $this->captureScreenshot();
  }

}
