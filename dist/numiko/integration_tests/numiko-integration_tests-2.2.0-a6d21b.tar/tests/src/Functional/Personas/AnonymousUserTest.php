<?php

namespace Drupal\Tests\integration_tests\Functional\Personas;

use Drupal\integration_tests\IntegrationTestBase;
use Symfony\Component\HttpFoundation\Response;
use Drupal\Core\Url;
use weitzman\DrupalTestTraits\Entity\MediaCreationTrait;

/**
 * Test the site permissions.
 *
 * General site permissions tests, checks for adding / editing permissions
 * as well as access to site administration sections, such as but not exclusive
 * to:
 *   - Taxonomy
 *   - Menus
 *   - Webforms
 *   - People.
 *
 * @group personas
 */
class AnonymousUserTest extends IntegrationTestBase {

  /**
   * Test that the registration page is inaccessible to an anon user.
   */
  public function testRegistrationDenied() {
    // Get the user registration path from the route.
    $user_registration_path = Url::fromRoute('user.register');

    // Navigate to the settings form.
    $this->drupalGet($user_registration_path);

    // Assure we loaded settings with proper permissions.
    $this->assertSession()->statusCodeEquals(Response::HTTP_FORBIDDEN);
  }

  /**
   * Test admin pages.
   *
   * Test the personas access to administration functionality.
   */
  public function testAdminFunctions() {
    // Check they cannot view the content list.
    $this->visitCheckCode('admin/content', Response::HTTP_FORBIDDEN);

    // Check Taxonomy access.
    $this->visitCheckCode('admin/structure/taxonomy', Response::HTTP_FORBIDDEN);

    // Check Menu access.
    $this->visitCheckCode('admin/structure/menu', Response::HTTP_FORBIDDEN);

    // Check Webform access.
    $this->visitCheckCode('admin/structure/webform', Response::HTTP_FORBIDDEN);

    // Check Webform adding.
    $this->visitCheckCode('admin/structure/webform/add', Response::HTTP_FORBIDDEN);

    // Check the people list access.
    $this->visitCheckCode('admin/people', Response::HTTP_FORBIDDEN);

    // Check they can can add people.
    $this->visitCheckCode('admin/people/create', Response::HTTP_FORBIDDEN);
  }

  /**
   * Test unpublished content view access.
   */
  public function testContentViewUnpublished() {
    $this->assertViewUnpublishedContentTypeReturnsStatusCode('page', Response::HTTP_FORBIDDEN);
  }

  /**
   * Test content add access.
   */
  public function testContentAdd() {
    $this->assertAddContentTypeReturnsStatusCode('page', Response::HTTP_FORBIDDEN);
  }

  /**
   * Test content edit access.
   */
  public function testContentEdit() {
    $this->assertEditContentTypeReturnsStatusCode('page', Response::HTTP_FORBIDDEN);
  }

  /**
   * Test content edit access.
   */
  public function testContentDelete() {
    $this->assertDeleteContentTypeReturnsStatusCode('page', Response::HTTP_FORBIDDEN);
  }

  /**
   * Test the media add access.
   */
  public function testAddMediaAccess() {
    $this->assertAddMediaTypeReturnsStatusCode('image', Response::HTTP_FORBIDDEN);
    $this->assertAddMediaTypeReturnsStatusCode('core_video', Response::HTTP_FORBIDDEN);
    $this->assertAddMediaTypeReturnsStatusCode('document', Response::HTTP_FORBIDDEN);
  }

  /**
   * Test the media edit access.
   */
  public function testEditMediaAccess() {
    $this->assertEditMediaTypeReturnsStatusCode('image', Response::HTTP_FORBIDDEN);
    $this->assertEditMediaTypeReturnsStatusCode('core_video', Response::HTTP_FORBIDDEN);
    $this->assertEditMediaTypeReturnsStatusCode('document', Response::HTTP_FORBIDDEN);
  }

  /**
   * Test the media edit access.
   */
  public function testDeleteMediaAccess() {
    $this->assertDeleteMediaTypeReturnsStatusCode('image', Response::HTTP_FORBIDDEN);
    $this->assertDeleteMediaTypeReturnsStatusCode('core_video', Response::HTTP_FORBIDDEN);
    $this->assertDeleteMediaTypeReturnsStatusCode('document', Response::HTTP_FORBIDDEN);
  }

}
