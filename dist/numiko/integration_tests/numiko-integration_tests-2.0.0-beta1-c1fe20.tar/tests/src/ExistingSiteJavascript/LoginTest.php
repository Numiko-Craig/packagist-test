<?php

namespace Drupal\Tests\integration_tests\ExistingSiteJavascript;

use Drupal\integration_tests\IntegrationTestBase;
use Drupal\integration_tests\ScreenShotTrait;
use Symfony\Component\HttpFoundation\Response;
use weitzman\DrupalTestTraits\WebDriverTrait;

/**
 * Test that an admin user can login.
 *
 * @group personas
 * @group smoke_test
 */
class LoginTest extends IntegrationTestBase {

  use WebDriverTrait;
  use ScreenShotTrait;

  public function testLogin() {
    $this->createUserWithPersonaAndLogin(['editor']);
    $this->visitCheckCode('admin/content', Response::HTTP_OK);
    $this->captureScreenshot();
  }

}
