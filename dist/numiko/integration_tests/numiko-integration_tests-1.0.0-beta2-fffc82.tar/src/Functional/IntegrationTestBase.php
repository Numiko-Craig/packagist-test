<?php

namespace Drupal\integration_tests\Functional;

use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Session\AnonymousUserSession;
use Drupal\Core\Url;
use weitzman\DrupalTestTraits\ExistingSiteBase;

/**
 * A test base class for integration tests.
 *
 * Useful methods are provided for testing a Drupal site loaded with
 * configuration.
 */
abstract class IntegrationTestBase extends ExistingSiteBase {

  use EntityCreationTrait, AssertTrait;

  /**
   * {@inheritDoc}
   */
  protected function setUp() {
    parent::setUp();
    // It is necessary to clear the cache before each test so we have a
    // known state. If it is desirable to check whether functionality is
    // playing nicely with the cache, then create tests to check this
    // explicitly, rather than relying on the cache being preserved between
    // tests.
    $this->clearCache();
  }

  /**
   * Index any items that are waiting to be indexed.
   *
   * @param string $searchIndex
   *   The search index ID. The default 'site' is the one that comes with the
   *   install profile.
   * @return int
   *   Number of items indexed.
   */
  protected function indexItemsInSearch($searchIndex = 'site') {
    $index = $this->container->get('entity_type.manager')
      ->getStorage('search_api_index')
      ->load($searchIndex);
    return $index->indexItems();
  }

  /**
   * Clear Drupal's cache.
   */
  protected function clearCache() {
    drupal_flush_all_caches();
  }

  /**
   * Search for a user and add them to the cleanup array for removal after the
   * test.
   */
  protected function findUserAndAddToCleanup($mail) {
    $user = $this->container->get('entity_type.manager')
      ->getStorage('user')
      ->loadByProperties(['mail' => $mail]);
    $this->cleanupEntities[] = current($user);
  }

  /**
   * Log in to Drupal.
   *
   * This is just a copy of Drupal\Tests\UiHelperTrait::drupalLogin() that
   * doesn't assert that the user is logged in, allowing the login status
   * to be checked in the test, and so test what happens when there is a login
   * failure.
   *
   * @param \Drupal\Core\Session\AccountInterface $account
   *   User object representing the user to log in.
   */
  protected function attemptDrupalLogin(AccountInterface $account) {
    if ($this->loggedInUser) {
      $this->drupalLogout();
    }

    $this->drupalGet('user/login');

    // Check if username field should actually take email address.
    // This is the case if the email_registration module is enabled.
    $username = NULL;
    if ($this->getCurrentPage()->find('css', '#user-login-form input[type=email]')) {
      $username = $account->getEmail();
    }
    else {
      $username = $account->getAccountName();
    }

    $this->submitForm(
      [
        'name' => $username,
        'pass' => $account->passRaw,
      ],
      t('Sign in')
    );

    $request = $this->container->get('request_stack')->getCurrentRequest();
    $cookieName = $this->container
      ->get('session_configuration')
      ->getOptions($request)['name'];
    $account->sessionId = $this->getSession()
      ->getCookie($cookieName);

    if ($this->drupalUserIsLoggedIn($account)) {
      $this->loggedInUser = $account;
      $this->container->get('current_user')->setAccount($account);
    }
  }

  /**
   * Override UiHelperTrait::drupalLogout to allow for changes to login form.
   *
   * UiHelperTrait::drupalLogout checks for username and password fields on the
   * form. We may want to use email instead of username.
   */
  protected function drupalLogout() {
    $this->drupalGet(
      Url::fromRoute('user.logout', [], ['query' => ['destination' => 'user']])
    );

    // @see BrowserTestBase::drupalUserIsLoggedIn()
    unset($this->loggedInUser->sessionId);
    $this->loggedInUser = FALSE;
    $this->container->get('current_user')->setAccount(new AnonymousUserSession());
  }

}
