<?php

namespace Drupal\integration_tests\Functional;

/**
 * Example integration tests.
 */
class Example extends IntegrationTestBase {

  /**
   * Create node, slice and user, login and check location.
   */
  public function test1() {
    $subscriptionsSlice = $this->createParagraph(
      'dashboard_slice_subscriptions',
      ['field_title' => 'Subscriptions']
    );
    $this->createPublishedNode(
      [
        'title' => 'Dashboard',
        'type' => 'dashboard',
        'field_subheading' => 'Subheading here',
        'field_dashboard_slices' => [
          [ 'entity' => $subscriptionsSlice ],
        ],
      ],
      '/user/dashboard/registered'
    );
    $registeredUser = $this->createUserWithPersonas(
      ['registered_user'],
      'integration test registered user',
      ['mail' => 'registereduser@test.com']
    );

    $this->attemptDrupalLogin($registeredUser);
    $this->assertTrue(
      $this->drupalUserIsLoggedIn($registeredUser)
    );

    $this->assertSession()->addressEquals('/dashboard');
    $this->assertSession()->pageTextContains('Look for text');

    $this->visitCheckCode('/restricted', 403);
  }

  /**
   * Fill form fields, check fields exist, submit form.
   */
  public function test2() {
    $this->drupalGet('membership/apply', ['query' => ['type' => 'full']]);
    $this->assertSession()->statusCodeEquals(200);

    $this->getCurrentPage()->fillField('edit-county', 'W Yorks');
    $this->getCurrentPage()->fillField('edit-country', 'United Kingdom');
    $this->getCurrentPage()->fillField('edit-telephone', '01132548732');

    $this->assertSession()->fieldExists('edit-nationality');

    $this->getCurrentPage()->pressButton('edit-submit');
  }

  /**
   * Find text in a particular place in the markup.
   */
  protected function test3() {
    // Twig debugging must be off - debugging comments will break this.
    $container = $this->getSession()->getPage()
      ->find('xpath', "//a[contains(@href, '/event-123')]");
    $this->assertNotNull($container);
    $this->assertContains(strtolower('Sold out'), strtolower($container->getText()));
  }

}
