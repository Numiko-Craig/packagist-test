# Full Configuration Drupal Functional Testing

Functional test infrastructure for tests that run on a site with configuration.

The idea is to be able to write tests that expect a "real" version of the site - one with the site's configuration loaded. Because much of what we do depends on config, core, contrib modules **and** our code.

The tests are run with `phpunit` and use [Mink](http://mink.behat.org/en/latest/) and [Goutte](https://github.com/FriendsOfPHP/Goutte) to browse the site. [Drupal Test Traits](https://gitlab.com/weitzman/drupal-test-traits) (DTT) is composer-required by this module to bootstrap Drupal and provides test data creation methods and UI helpers.

The `IntegrationTestBase` class provides some extra useful assertion and test data creation methods.

A testing environment should have all Drupal caches turned on for a realistic test (and these tests can be particularly useful to test how custom code works in different situations with the cache).  `IntegrationTestBase::setUp` clears the cache before each test.

Previous versions of this module attempted to install Drupal from scratch before tests were run, but this is unreliable and takes too long. Whether you write tests to be run on a site with content (e.g. a DB dump taken from prod) or with all entities deleted may depend on the application.

## Usage

The module does not need to be installed.

Create a module in the custom folder and copy example tests (if required) from this module.

1. Write tests that extend `IntegrationTestBase`.
2. Place tests in the correct folder structure `Functional` `FunctionalJavascript`.
3. Make sure Drupal caches are on as they would be on production.
4. Run `./vendor/phpunit/phpunit/phpunit --configuration . --testsuite existing-site` to run all Existing Site tests in `modules/custom`.
5. Run `./vendor/phpunit/phpunit/phpunit --configuration . --testsuite existing-site-javascript` to run all Existing Site Javascript tests in `modules/custom`.
6. Run `./vendor/phpunit/phpunit/phpunit --configuration . --testsuite unit` to run all unit tests in `modules/custom`.

The projects `phpunit.xml` should be updated with the contents of the `phpunit.xml` file in this module.

## Javascript tests

In order to run FunctionalJavascript tests you need to add chrome into the projects `docker-compose.yml`

```
  chrome:
    # Note: chrome 67/68 is giving errors so we pin to 65 for now.
    image: previousnext/chrome-headless:65
    ports:
      - "${CHROMEDRIVER_PORT-9222}:9222"
```

and `composer require 'dmore/chrome-mink-driver' --dev`

Any tests need to use the `WebDriver` trait.

There is useful trait `ScreenShotTrait` added to this module which will take Screenshots in different window sizes.
To use this just add `Use ScreenShotTrait;` to your test (the one from this module) and use with `$this->captureScreenshot()`.

## Example tests in this module

Copy these tests into your own projects module.

1. Check the homepage can be reached.
2. Check a page can be created / edited.
3. Check the search is showing results.
4. Check various slices can be created / viewed.
5. Check the workflow transitions are working.
6. Check user permissions for site admins, content editor and anonymous user.

## Creating test content

`EntityCreationTrait` uses the DTT entity creation methods but provides methods tailored to our particular needs. I would expect this trait to be expanded upon.

The `EntityCreationTrait::createPublishedNode()` is a useful method to create a published node (with moderation taken into account) optionally with a path.

`EntityCreationTrait::createUserWithPersonas` is useful for creating user with personas.

`EntityCreationTrait::createParagraph` is used to create slices.

Any entities created using the DTT methods will automatically be deleted during `tearDown()`.

If you add custom-created entities (i.e. not using DTT or creation methods from this module), manually add them to `$this->markEntityForCleanup`so that they are during `tearDown()`.

It is important that the tests do not leave any data behind that would prevent the tests running again successfully e.g. if the test expects only one node with a certain title.

`AssertTrait` contains useful assertions.

`visitCheckCode` should be used when you want to go to a url and check a status code.
Other assertions are available to check permissions for creating/editing/deleting nodes and media.

To login use `createUserWithPersonaAndLogin` or `createUserWithRoleAndLogin` depending on if Personas are enabled or not.

## Test environment suggestions

Ways to set up the test environment:

1. Development - have a separate local docker environment with a clean DB (i.e. no content)
2. Development - have a second, clean DB in your docker environment
3. Development - write tests that allow for real content on the site
4. CI - have a process that will install Drupal and import config before running tests (future aim).

After using option 2 initially, I've settled on 3 during development. This may vary between projects.
