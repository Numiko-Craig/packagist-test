<?php

namespace Drupal\Tests\integration_tests\Functional\Content;

use Drupal\integration_tests\IntegrationTestBase;
use Symfony\Component\HttpFoundation\Response;

/**
 * Test that a node can be created/edited.
 *
 * @group content
 */
class NodeTest extends IntegrationTestBase {

  protected $node;

  function setUp(): void {
    parent::setUp();
    $this->node = $this->createPublishedNode();
    $this->createUserWithPersonaAndLogin(['editor']);
  }

  /**
   * Checks the node exists from setup.
   */
  public function testCreateNode() {
    $this->drupalGet('node/' . $this->node->id());
    $this->visitCheckCode('node/' . $this->node->id(), Response::HTTP_OK);
  }

  /**
   * Test the node can be edited.
   *
   * Updates the title and checks the title is present on the page.
   */
  public function testEditNode() {
    $this->visitCheckCode('node/' . $this->node->id() . '/edit', Response::HTTP_OK);
    $page = $this->getCurrentPage();
    $page->fillField('title[0][value]', 'Updated Title');
    $submit_button = $page->findButton('Save');
    $submit_button->press();
    $this->assertSession()->statusCodeEquals(Response::HTTP_OK);
    $this->assertSession()->pageTextContains('Updated title');
  }

}
