<?php

namespace Drupal\media_gallery\Transform;

use Drupal\file\FileInterface;
use Drupal\Core\Image\ImageFactory;
use Drupal\Core\Entity\EntityTypeManager;

/**
 * Transform a media gallery file.
 */
class MediaGalleryFile {

  const UNCROPPED_IMAGE_STYLE = 'uncropped_large';

  const DEFAULT_ASPECT_RATIO = 56.25;

  /**
   * The entity type manager.
   *
   * @var Drupal\Core\Entity\EntityTypeManager
   */
  protected $entityTypeManager;

  /**
   * The image factory.
   *
   * @var Drupal\Core\Image\ImageFactory
   */
  protected $imageFactory;

  /**
   * Creates a new MediaGalleryFile instance.
   *
   * @param \Drupal\Core\Entity\EntityTypeManager $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\Core\Image\ImageFactory $image_factory
   *   The image factory.
   */
  public function __construct(EntityTypeManager $entity_type_manager, ImageFactory $image_factory) {
    $this->entityTypeManager = $entity_type_manager;
    $this->imageFactory = $image_factory;
  }

  /**
   * Get dimensions of image file once processed by image style.
   */
  public function getDimensions(FileInterface $file) {
    $imageStyle = $this->entityTypeManager
      ->getStorage('image_style')
      ->load(self::UNCROPPED_IMAGE_STYLE);

    $fileUri = $file->getFileUri();
    $buildUri = $imageStyle->buildUri($fileUri);

    // Preload image style for display in the modal.
    //
    // The data we need won't be available if the derivative image hasn't been
    // generated yet. See this commit and accompanying ticket:
    // https://bitbucket.org/numiko/ravensbourne-university/commits/e4b67be1ead6c90e1cd5a15be9e89828167d9ab5
    if (!file_exists($buildUri)) {
      $imageStyle->createDerivative($fileUri, $buildUri);
    }

    $imageFactory = $this->imageFactory->get($buildUri);
    $dimensions['width'] = $imageFactory->getToolkit()->getWidth();
    $dimensions['height'] = $imageFactory->getToolkit()->getHeight();

    // Calculate an aspect ratio based on the largest of height or width.
    $dimensions['aspect_ratio'] = self::DEFAULT_ASPECT_RATIO;
    if ($dimensions['width'] && $dimensions['height']) {
      $dimensions['aspect_ratio'] = $this->getAspectRatioAsPercentage($dimensions['width'], $dimensions['height']);
    }

    return $dimensions;
  }

  /**
   * Get the aspect ratio as a percentage.
   *
   * This is calculated by taking the larger of the two and diving by the
   * smaller and dividing 100 by the result.
   *
   * For example on a 16:9 ratio it would be:
   *
   * 100 / (16 / 9) = 56.25
   */
  private function getAspectRatioAsPercentage($width, $height) {
    if ($width >= $height) {
      return round(100 / ($width / $height), 2);
    }
    return round(100 / ($height / $width), 2);
  }

}
