<?php

namespace Drupal\slice_jump_links\Entity;

/**
 * @file
 * Contains a jump link entity.
 */

class JumpLink {

  protected $label;
  protected $anchor;

  public function setLabel($label) {
    $this->label = $label;
    return $this;
  }

  public function getLabel() {
    return $this->label;
  }

  public function setAnchor($anchor) {
    $this->anchor = $anchor;
    return $this;
  }

  public function getAnchor() {
    $anchor = $this->anchor;
    if (!$anchor) {
      $anchor = $this->getLabel();
    }
    return $this->sanitizeAnchor($anchor);
  }

  /**
   * Santitize the given anchor.
   *
   * Using regex we will create a default anchor, replacing any amount
   * of spaces with a single hyphen and removing any non-alpha numeric
   * characters (except hyphens).
   *
   * @return string
   *   A sanitized anchor.
   */
  protected function sanitizeAnchor($anchor) {
    return preg_replace('/[^\da-z\-]/i', '', preg_replace('/[ -]+/', '-', trim(strtolower($anchor))));
  }

  public function justAnchor() {
    if (!$this->label) {
      return TRUE;
    }
    return FALSE;
  }

  public function isEmpty() {
    if ($this->label || $this->anchor) {
      return FALSE;
    }
    return TRUE;
  }

}
