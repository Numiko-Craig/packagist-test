<?php

namespace Drupal\slice_jump_links\tests\Unit\Factory;

use Drupal\Tests\UnitTestCase;
use Drupal\slice_jump_links\Factory\EntityJumpLinkFactory;
use Drupal\slice_jump_links\Factory\AbstractEntityJumpLinkFactory;
use Drupal\node\Entity\Node;

/**
 * Check the entity jump link factory functions correctly.
 *
 * @group phpunit_example
 */
class EntityJumpLinkFactoryTest extends UnitTestCase {

  protected $node;
  protected $jumpLinkFactory;

  /**
   * Before a test method is run, setUp() is invoked.
   * Create new jump link object.
   */
  public function setUp() {
    $this->node = Node::create([
      'type' => 'page',
      'title' => 'New Page',
      'field_jump_link_label' => "Test Label",
    ]);
    $this->jumpLinkFactory = new EntityJumpLinkFactory();
  }

  public function testSetLabel() {
    $label = "Test Label";
    $jumpLink = $this->jumpLinkFactory->create($this->node);
    $this->assertEquals($label, $this->jumpLink->getLabel());
  }

}