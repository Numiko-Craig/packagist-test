<?php

namespace Drupal\slice_jump_links\tests\Unit\Entity;

use Drupal\Tests\UnitTestCase;
use Drupal\slice_jump_links\Entity\JumpLink;

/**
 * Check the jump link object functions correctly.
 *
 * @group phpunit_example
 */
class JumpLinkTest extends UnitTestCase {

  protected $jumpLink;

  /**
   * Before a test method is run, setUp() is invoked.
   * Create new jump link object.
   */
  public function setUp() {
    $this->jumpLink = new JumpLink();
  }

  /**
   * @covers Drupal\slice_jump_links\Entity\JumpLink::setLabel
   */
  public function testSetLabel() {
    $this->assertEquals(0, $this->jumpLink->getLabel());
    $label = "Test Label";
    $this->jumpLink->setLabel($label);
    $this->assertEquals($label, $this->jumpLink->getLabel());
  }

  /**
   * @covers Drupal\slice_jump_links\Entity\JumpLink::getAnchor
   */
  public function testGetAnchor() {
    $anchor = "test-label";
    $label = "Test Label";
    $this->jumpLink->setLabel($label);
    $this->assertEquals($anchor, $this->jumpLink->getAnchor());
  }

  /**
   * @covers Drupal\slice_jump_links\Entity\JumpLink::getAnchor
   */
  public function testGetAnchorMultipleSpaces() {
    $anchor = "test-label";
    $label = "Test   Label  ";
    $this->jumpLink->setLabel($label);
    $this->assertEquals($anchor, $this->jumpLink->getAnchor());
  }

  /**
   * @covers Drupal\slice_jump_links\Entity\JumpLink::getAnchor
   */
  public function testGetAnchorNumeric() {
    $anchor = "test12-label-123";
    $label = "Test12 Label 123";
    $this->jumpLink->setLabel($label);
    $this->assertEquals($anchor, $this->jumpLink->getAnchor());
  }

  /**
   * @covers Drupal\slice_jump_links\Entity\JumpLink::getAnchor
   */
  public function testGetAnchorSpecialChars() {
    $anchor = "test-label";
    $label = "Test L£$%@$%£~''abel";
    $this->jumpLink->setLabel($label);
    $this->assertEquals($anchor, $this->jumpLink->getAnchor());
  }

  /**
   * @covers Drupal\slice_jump_links\Entity\JumpLink::setAnchor
   */
  public function testSetAnchor() {
    $anchor = "test-anchor";
    $this->jumpLink->setAnchor($anchor);
    $this->assertEquals($anchor, $this->jumpLink->getAnchor());
  }

  /**
   * Once test method has finished running, whether it succeeded or failed, tearDown() will be invoked.
   * Unset the $jumpLink object.
   */
  public function tearDown() {
    unset($this->jumpLink);
  }

}
