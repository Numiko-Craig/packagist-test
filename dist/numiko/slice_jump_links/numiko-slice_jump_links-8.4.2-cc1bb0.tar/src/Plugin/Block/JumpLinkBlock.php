<?php

namespace Drupal\slice_jump_links\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\node\NodeInterface;
use Drupal\slice_jump_links\Factory\NodeJumpLinkListFactory;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides a block for displaying jump links.
 *
 * @Block(
 *   id = "jump_link_block",
 *   admin_label = @Translation("Jump link block"),
 *   context_definitions = {
 *     "node" = @ContextDefinition("entity:node", label = @Translation("Node"))
 *   }
 * )
 */
class JumpLinkBlock extends BlockBase implements ContainerFactoryPluginInterface {

  /**
   * @var NodeJumpLinkListFactory
   */
  private $nodeJumpLinkListFactory;

  /**
   * {@inheritdoc}
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, NodeJumpLinkListFactory $nodeJumpLinkListFactory) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->nodeJumpLinkListFactory = $nodeJumpLinkListFactory;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('jump_link.list.factory.node')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    $node = $this->getContextValue('node');
    if ($node instanceof NodeInterface) {
      $jumpLinkList = $this->nodeJumpLinkListFactory->fetch($node);
      if (!$jumpLinkList->isEmpty()) {
        return [
          '#theme' => 'slice_jump_links',
          '#list' => $jumpLinkList,
        ];
      }
    }
    return [];
  }

}
