<?php

namespace Drupal\slice_jump_links\Entity;

/**
 * @file
 * Contains factory for creating jump link list from node with slices.
 */

class JumpLinkButton extends JumpLink {

  protected $link;

  public function setLink($link) {
    $this->link = $link;
    return $this;
  }

  public function getLink() {
    if ($this->link) {
      return $this->link;
    }
    else {
      return '#' . $this->getAnchor();
    }
  }

  public function isEmpty() {
    if ($this->label || $this->link) {
      return FALSE;
    }
    return TRUE;
  }

}
