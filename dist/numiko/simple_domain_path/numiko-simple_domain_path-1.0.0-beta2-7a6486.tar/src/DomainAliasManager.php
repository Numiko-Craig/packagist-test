<?php

namespace Drupal\simple_domain_path;

use Drupal\domain\DomainNegotiatorInterface;
use Drupal\path_alias\AliasManager;

class DomainAliasManager extends AliasManager {

  /**
   * @var DomainNegotiatorInterface
   */
  protected $domainNegotiator;

  /**
   * @return \Drupal\domain\DomainNegotiatorInterface
   */
  public function getDomainNegotiator() {
    return $this->domainNegotiator;
  }

  /**
   * @param \Drupal\domain\DomainNegotiatorInterface $domainNegotiator
   */
  public function setDomainNegotiator($domainNegotiator) {
    $this->domainNegotiator = $domainNegotiator;
  }

  /**
   * {@inheritdoc}
   */
  public function setCacheKey($key) {
    // Prefix the cache key to avoid clashes with other caches.
    $domainId = $this->domainNegotiator->getActiveDomain()->id();
    $this->cacheKey = 'preload-paths:' . $domainId . ':' . $key;
  }

}
