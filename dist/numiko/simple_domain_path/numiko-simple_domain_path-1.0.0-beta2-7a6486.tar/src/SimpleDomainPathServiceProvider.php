<?php

namespace Drupal\simple_domain_path;

use Drupal\Core\DependencyInjection\ContainerBuilder;
use Drupal\Core\DependencyInjection\ServiceProviderBase;
use Symfony\Component\DependencyInjection\Reference;

class SimpleDomainPathServiceProvider extends ServiceProviderBase {

  /**
   * {@inheritdoc}
   */
  public function alter(ContainerBuilder $container) {
    if ($container->hasDefinition('path_alias.repository')) {
      $definition = $container->getDefinition('path_alias.repository');
      if (!$definition->isDeprecated()) {
        $definition
          ->setClass(DomainAliasRepository::class)
          ->addMethodCall('setDomainNegotiator', [new Reference('domain.negotiator')]);
      }
    }

    if ($container->hasDefinition('path_alias.manager')) {
      $definition = $container->getDefinition('path_alias.manager');
      if (!$definition->isDeprecated()) {
        $definition
          ->setClass(DomainAliasManager::class)
          ->addMethodCall('setDomainNegotiator', [new Reference('domain.negotiator')]);
      }
    }
  }

}
