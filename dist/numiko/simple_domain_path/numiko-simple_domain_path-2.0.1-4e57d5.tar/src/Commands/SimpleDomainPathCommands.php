<?php

namespace Drupal\simple_domain_path\Commands;

use Drupal\Core\Database\DatabaseExceptionWrapper;
use Drupal\domain\Entity\Domain;
use Drupal\path_alias\Entity\PathAlias;
use Drush\Commands\DrushCommands;
use Exception;
use PDO;

/**
 * A Drush command file.
 *
 * In addition to this file, you need a drush.services.yml
 * in root of your module, and a composer.json file that provides the name
 * of the services file to use.
 *
 * See these files for an example of injecting Drupal services:
 *   - http://cgit.drupalcode.org/devel/tree/src/Commands/DevelCommands.php
 *   - http://cgit.drupalcode.org/devel/tree/drush.services.yml
 */
class SimpleDomainPathCommands extends DrushCommands {

  /**
   * Move domain IDs from existing domain_path table to path_alias table.
   *
   * @command add:domain-to-aliases
   *
   * @aliases ad2a,add-domain-to-aliases
   */
  public function domainToAliases() {
    $langcode = \Drupal::service('language_manager')->getDefaultLanguage()->getId();
    $db = \Drupal::service('database');
    $missingDomains = [];
    try {
      \Drupal::messenger()->addMessage("\tPorting domain_path aliases to path_alias.");
      if ($db->schema()->tableExists('domain_path')) {
        $domainPathResult = $db->query(
          "SELECT * FROM domain_path;"
        );
        while ($domainPathRow = $domainPathResult->fetchAssoc()) {
          $pathAliasResult = $db->query(
            'SELECT * FROM path_alias WHERE path = :path',
            [':path' => $domainPathRow['source']]
          );
          $pathAliasRows = $pathAliasResult->fetchAll(PDO::FETCH_ASSOC);
          \Drupal::messenger()->addMessage('Path from domain_path table: ' . $domainPathRow['source']);
          if ($pathAliasRows) {
            foreach ($pathAliasRows as $pathAliasRow) {
              \Drupal::messenger()->addMessage("\tAlias in path_alias: " . $pathAliasRow['alias']);
              $stringDomainId = $this->getStringDomainId($domainPathRow['domain_id']);
              if (!$stringDomainId) {
                throw new \Exception("Can't find domain ID");
              }
              \Drupal::messenger()->addMessage("\tSetting domain: " . $stringDomainId);
              $db->query("UPDATE path_alias SET domain = :domainId WHERE id = :id", [
                'domainId' => $stringDomainId,
                'id' => $pathAliasRow['id'],
              ]);
            }
          }
          else {
            // No path alias - create one.
            \Drupal::messenger()->addMessage("\tCreating new path alias");
            $domainId = $this->findDomainFromPath($domainPathRow['source']);
            if ($domainId) {
              $pathAlias = PathAlias::create([
                'langcode' => $langcode,
                'path' => $domainPathRow['source'],
                'alias' => $domainPathRow['alias'],
                'status' => 1,
                'domain' => $domainId,
              ]);
              $pathAlias->save();
            }
            else {
              $missingDomains[] = $domainPathRow['source'] . '/' . $domainPathRow['alias'] . "\tNo domain found!";
              \Drupal::messenger()->addMessage("\tNo domain found!");
            }
          }
        }
      }
      else {
        \Drupal::messenger()->addMessage("\tNo domain_path table found. No domain_path aliases ported.");
      }
    }
    catch (DatabaseExceptionWrapper $exception) {
      \Drupal::messenger()->addMessage("\tA database exception has occurred. Message: " . $exception->getMessage());
      throw new \Exception($exception->getMessage());
    }
    \Drupal::messenger()->addMessage("\tPorting existing path_alias aliases.");
    $pathAliases = $db->query(
      "SELECT * FROM path_alias WHERE domain is NULL OR domain = '';"
    );
    while ($pathAliasRow = $pathAliases->fetchAssoc()) {
      \Drupal::messenger()->addMessage("\tAlias in path_alias: " . $pathAliasRow['alias']);
      $domainId = $this->findDomainFromPath($pathAliasRow['path']);
      if (isset($domainId)) {
        \Drupal::messenger()->addMessage("\tSetting domain: " . $domainId);
        $db->query("UPDATE path_alias SET domain = :domainId WHERE id = :id", [
          'domainId' => $domainId,
          'id' => $pathAliasRow['id'],
        ]);
      }
      else {
        $missingDomains[] = $pathAliasRow['source'] . '/' . $pathAliasRow['alias'];
      }
    }
    if (!empty($missingDomains)) {
      \Drupal::messenger()->addMessage('Missing domains for:');
      drush_print_r($missingDomains);
    }
  }

  /**
   * Validate that all paths are accessible via their domain aliases.
   *
   * @command validate:path-aliases
   *
   * @aliases vpa,validate-path-aliases
   */
  public function pathAliases() {
    $this->validateAliasTable('domain_path');
    $this->validateAliasTable('path_alias');
  }

  /**
   * Finds the domain ID for a given path.
   *
   * Finds the domain ID for a given path. If the path is for a non-node
   * entity, the 'global' domain is returned, marked by an empty string.
   * If the path is for a node, but a domain for it cannot be found, NULL
   * is returned.
   *
   * @param string $path
   *   The subject entity path.
   *
   * @return string|null
   *   Domain ID if found, NULL otherwise.
   */
  protected function findDomainFromPath(string $path) {
    if (strpos($path, '/node') === 0) {
      $nid = substr($path, 6);
      $node = \Drupal::service('entity_type.manager')
        ->getStorage('node')
        ->load($nid);
      if ($node) {
        $domain = $node->get('field_domain_access')->referencedEntities();
      }
    }
    else {
      // Not supported entity, mark as global.
      return '';
    }
    if ($domain) {
      return $domain[0]->id();
    }
    else {
      \Drupal::messenger()->addMessage("\tNo domain found!");
    }
    return NULL;
  }

  /**
   * This function returns a domain ID, if the domain exists.
   *
   * @param string $domainId
   *   Domain ID to check.
   *
   * @return string|null
   *   Domain ID if domain exists, NULL otherwise.
   */
  protected function getStringDomainId($domainId) {
    static $domains;
    if (!$domains) {
      $domains = \Drupal::service('entity_type.manager')
        ->getStorage('domain')
        ->loadMultiple();
    }
    foreach ($domains as $domain) {
      if ($domain->getDomainId() == $domainId) {
        return $domain->id();
      }
    }
    return NULL;
  }

  /**
   * Makes request to validate that an alias is still accessible.
   *
   * @param array $allDomains
   *   Array of all site's domain entities.
   * @param string $alias
   *   The alias path to test.
   * @param string $domainId
   *   The domain from which to access the alias path.
   *
   * @return int|null
   *   Status code of response, NULL if domain not found.
   */
  protected function getRequestStatus(array $allDomains, string $alias, string $domainId) {
    if ($domainId !== '') {
      if (isset($allDomains[$domainId])) {
        $domain = $allDomains[$domainId];
      }
      else {
        throw new \Exception("\tNo domain with ID $domainId found. Validation of alias failed");
        return NULL;
      }
    }
    else {
      // If alias is global, test on any domain.
      $domain = reset($allDomains);
    }
    $host = $domain->getPath();
    // Alias starts with '/'. This is removed because host will end with '/'.
    $url = $host . substr($alias, 1);

    $client = \Drupal::httpClient();
    // Here http_errors is set to FALSE to prevent exceptions being thrown
    // for responses with status codes in the range 400 to 599.
    $response = $client->get($url, ['http_errors' => FALSE]);
    return $response->getStatusCode();
  }

  /**
   * Print formatted validation summary.
   *
   * @param int $total
   *   Total number of aliases checked.
   * @param array $invalidAliases
   *   Associative array of categorised, invalid aliases.
   * @param string $tableName
   *   Database table that was validated.
   */
  protected function printValidationSummary(int $total, array $invalidAliases, string $tableName) {
    $totalInvalidAliases = 0;
    foreach ($invalidAliases as $groupedAliases) {
      $totalInvalidAliases += count($groupedAliases);
    }
    \Drupal::messenger()->addMessage("\t$total aliases from $tableName checked");
    $totalPassed = $total - $totalInvalidAliases;
    \Drupal::messenger()->addMessage("\t$totalPassed aliases passed validation.");
    if (empty($invalidAliases)) {
      return;
    }
    \Drupal::messenger()->addMessage("\t$totalInvalidAliases aliases failed validation, please address these below:");
    foreach ($invalidAliases as $statusCode => $invalidAliasGroup) {
      if ($statusCode == 'Error') {
        \Drupal::messenger()->addMessage("\tThe following aliases failed with a request exception. The full error message is shown for each");
      }
      else {
        \Drupal::messenger()->addMessage("\tThe following aliases failed with status code $statusCode:");
      }
      foreach ($invalidAliasGroup as $invalidAlias) {
        $path = $invalidAlias['path'];
        $alias = $invalidAlias['alias'];
        $domain = $invalidAlias['domain'];
        \Drupal::messenger()->addMessage("\t\tPath:\t$path");
        \Drupal::messenger()->addMessage("\t\tAlias:\t$alias");
        if ($invalidAlias['domain'] === '') {
          \Drupal::messenger()->addMessage("\t\tDomain:\t--Global--");
        }
        else {
          \Drupal::messenger()->addMessage("\t\tDomain:\t$domain");
        }
        if ($statusCode == 'Error') {
          $errorMessage = $invalidAlias['message'];
          \Drupal::messenger()->addMessage("\t\tError message:\t$errorMessage");
        }
        // Print line break for formatting.
        \Drupal::messenger()->addMessage("\r\n");
      }
      // Print line break for formatting.
      \Drupal::messenger()->addMessage("\r\n");
    }
  }

  /**
   * Validates and outputs results for aliases from specific table.
   *
   * @param string $tableName
   *   Database table name that contains aliases to validate.
   */
  protected function validateAliasTable(string $tableName) {
    $allDomains = Domain::loadMultiple();
    if (!isset($allDomains) || empty($allDomains)) {
      throw new \Exception("\tNo domains found. Validation of aliases failed");
    }
    else {
      try {
        \Drupal::messenger()->addMessage("\tValidating $tableName aliases.");
        $db = \Drupal::service('database');
        if ($db->schema()->tableExists($tableName)) {
          $processedAliases = 0;
          $invalidAliases = [];
          $queryResult = $db->query("SELECT * FROM $tableName;")->fetchAll();
          $totalAliases = count($queryResult);
          foreach ($queryResult as $queryRow) {
            try {
              $statusCode = $this->getRequestStatus($allDomains, $queryRow->alias, $queryRow->domain);
              if (isset($statusCode) && $statusCode != 200) {
                $invalidAliases[$statusCode][] = [
                  'path' => $queryRow->path,
                  'domain' => $queryRow->domain,
                  'alias' => $queryRow->alias,
                ];
              }
            }
            catch (Exception $exception) {
              $invalidAliases['Error'][] = [
                'path' => $queryRow->path,
                'domain' => $queryRow->domain,
                'alias' => $queryRow->alias,
                'message' => $exception->getMessage(),
              ];
              throw new \Exception($exception->getMessage());
            }
            $processedAliases++;
            \Drupal::messenger()->addMessage("\t\tProcessed $processedAliases of $totalAliases");
          }
          $this->printValidationSummary($totalAliases, $invalidAliases, $tableName);
          \Drupal::messenger()->addMessage("\tCompleted $tableName alias validation.");
        }
        else {
          \Drupal::messenger()->addMessage("\t$tableName table does not exist. Validation of $tableName aliases skipped.");
        }
      }
      catch (DatabaseExceptionWrapper $exception) {
        \Drupal::messenger()->addMessage("\t$tableName alias validation failed! Please address error message below:");
        \Drupal::messenger()->addMessage($exception->getMessage());
        throw new \Exception($exception->getMessage());
      }
    }
  }

}
