<?php

namespace Drupal\link_template_formatter\Plugin\Field\FieldFormatter;

use Drupal\file\Plugin\Field\FieldFormatter\GenericFileFormatter;
use Drupal\Component\Utility\Unicode;
use Drupal\Core\Field\FieldItemListInterface;

/**
 * Plugin implementation of the 'file_link_template' formatter.
 *
 * @FieldFormatter(
 *   id = "file_link_template",
 *   label = @Translation("Link Template"),
 *   field_types = {
 *     "file"
 *   }
 * )
 */
class FileLinkTemplateFormatter extends GenericFileFormatter {

  /**
   * {@inheritdoc}
   */
  public static function defaultSettings() {
    return parent::defaultSettings();
  }

  /**
   * {@inheritdoc}
   */
  public function viewElements(FieldItemListInterface $items, $langcode) {
    $elements = parent::viewElements($items, $langcode);
    foreach ($elements as &$element) {
      $element['#theme'] = 'link_link';
    }
    return $elements;
  }

}
