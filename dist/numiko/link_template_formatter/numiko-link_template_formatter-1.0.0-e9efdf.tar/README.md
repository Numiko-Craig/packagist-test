# Link Template Formatter #

This is a field formatter for link / file fields, giving a single template for both field types which output links.

The template is overridable, but the default gives the following values.

```
#!twig

<a href="{{ url }}" {{ attributes }}><span>{{ title }}</span></a>
```