<?php

namespace Drupal\adestra\Map;

use \PhpXmlRpc\Value;

/**
 * Convert a XMLRPC Value.
 */
class XmlRpcValueMap {

  /**
   * Convert the value to an array of data.
   */
  public function valueToArray(Value $value) {
    $data = [];
    if (isset($value->me) && isset($value->me['struct'])) {
      foreach ($value->me['struct'] as $name => $field) {
        $fieldValue = $this->getFieldValue($field);
        if (is_array($fieldValue)) {
          $data[$name] = $this->getArrayFieldValues($fieldValue);
        }
        else {
          $data[$name] = $fieldValue;
        }
      }
    }
    elseif (isset($value->me) && isset($value->me['array'])) {
      foreach ($value->me['array'] as $item) {
        $data[] = $this->valueToArray($item);
      }
    }
    return $data;
  }

  /**
   * Get the array value of the first item.
   */
  protected function getFieldValue($field) {
    $fieldValues = array_values($field->me);
    return array_shift($fieldValues);
  }

  /**
   * Map all of the array values into array items from XmlRpcValues.
   */
  protected function getArrayFieldValues($arrayValues) {
    return array_map([$this, 'valueToArray'], $arrayValues);
  }

}
