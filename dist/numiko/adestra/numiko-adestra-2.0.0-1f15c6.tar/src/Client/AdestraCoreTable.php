<?php

namespace Drupal\adestra\Client;

use Drupal\adestra\Client\AdestraClient;

/**
 * Functions for creating and subscribing adestra contacts.
 */
class AdestraCoreTable {

  protected $adestraClient;

  /**
   * Instantiate an Adestra Factory.
   */
  public function __construct(AdestraClient $adestra_client) {
    $this->adestraClient = $adestra_client;
  }

  /**
   * Retrieve a core table item.
   */
  public function get() {
    $response = $this->adestraClient->request('coreTable.get', ['table_id' => $this->adestraClient->getTableId()]);
    $value = $response->val;
    if (empty($value)) {
      // Nothing found.
      return NULL;
    }
    else {
      $data = $this->adestraClient->xmlRpcValueToArray($value);
      return $data;
    }
  }

}
