<?php

namespace Drupal\adestra\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Class ContentTypeForm.
 *
 * @package Drupal\section_node\Form
 */
class SettingsForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      'adestra.settings',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'adestra_settings_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('adestra.settings');

    $form['credentials'] = [
      '#type' => 'details',
      '#title' => $this->t('Authentication'),
      '#open' => TRUE,
    ];

    $form['credentials']['account'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Account name'),
      '#description' => $this->t('This is the account name found on the login screen'),
      '#default_value' => $config->get('account'),
    ];

    $form['credentials']['username'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Username'),
      '#description' => $this->t('The username of the account'),
      '#default_value' => $config->get('username'),
    ];

    $form['credentials']['password'] = [
      '#type' => 'password',
      '#title' => $this->t('Password'),
      '#description' => $this->t("The password of the account - we recommend not putting in your password here, but instead using an override e.g. <b>\$config['adestra.settings']['password'] = '';</b>"),
      '#default_value' => $config->get('password'),
    ];

    $form['api'] = [
      '#type' => 'details',
      '#title' => $this->t('API Settings'),
      '#open' => TRUE,
    ];

    $form['api']['table_id'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Core Table ID'),
      '#description' => $this->t('The core table ID (can be obtained by going to the Workspace in Adestra and then Data > Core Tables)'),
      '#default_value' => $config->get('table_id'),
    ];

    $form['debug'] = [
      '#type' => 'details',
      '#title' => $this->t('Debug Options'),
      '#open' => ($config->get('debug')) ? TRUE : FALSE,
    ];

    $form['debug']['debug'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Enable API debugging output'),
      '#description' => $this->t('Set debug on the XMLRPC library'),
      '#default_value' => $config->get('debug'),
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    parent::submitForm($form, $form_state);

    $config = $this->config('adestra.settings');

    $config->set('account', $form_state->getValue('account'));
    $config->set('username', $form_state->getValue('username'));
    $config->set('password', $form_state->getValue('password'));
    $config->set('debug', ($form_state->getValue('debug') ? TRUE : FALSE));
    $config->set('table_id', $form_state->getValue('table_id'));

    $config->save();
  }

}
