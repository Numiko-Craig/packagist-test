# Adestra

Module for interacting with the Adestra MessageFocus API.

The base module includes the client for interacting with the various adestra endpoints, as well as controllers to list campaigns and lists.

`/admin/adestra/list/all`

`/admin/adestra/campaign/all`

## Adestra Webform

The adestra webform module provides integration bewteen the Adestra API and the webform module.

This includes the following options:

* Updating / creating contacts based on email address
* Subscribing contacts to a given list
* Send campaign email to a contact
* Attach an optional launch reference value
* Map webform fields to fields in Adestra (both campaign transaction data and user data fields)