<?php

namespace Drupal\adestra\Client;

use Drupal\adestra\Client\AdestraClient;

/**
 * Functions for creating and subscribing adestra contacts.
 */
class AdestraContact {

  protected $adestraClient;

  /**
   * Instantiate an Adestra Contact.
   */
  public function __construct(AdestraClient $adestra_client) {
    $this->adestraClient = $adestra_client;
  }

  /**
   * Create an adestra contact.
   */
  public function create($data = []) {
    // contact.create(table_id, contact_data, dedupe_field).
    $response = $this->adestraClient->request('contact.create', [
      'table_id' => $this->adestraClient->getTableId(),
      'contact_data' => $data,
    ]);
    // Set the id from response.
    if (isset($response->val) && isset($response->val->me)) {
      $values = array_values($response->val->me);
      $id = array_shift($values);
      return $id;
    }
  }

  /**
   * Subscribe the given contact id.
   */
  public function subscribe($id, $listId) {
    // contact.addList(contact_id, list_id)
    $response = $this->adestraClient->request('contact.addList', [
      'contact_id' => $id,
      'list_id' => $listId,
    ]);
    $result = NULL;
    if (isset($response->val) && isset($response->val->me)) {
      $values = array_values($response->val->me);
      $result = array_shift($values);
    }
    return $result == 1;
  }

  /**
   * Unsubscribe the given contact id.
   */
  public function unsubscribe($id, $listId) {
    // contact.removeList(contact_id, list_id)
    $response = $this->adestraClient->request('contact.removeList', [
      'contact_id' => $id,
      'list_id' => $listId,
    ]);
    $result = NULL;
    if (isset($response->val) && isset($response->val->me)) {
      $values = array_values($response->val->me);
      $result = array_shift($values);
    }
    return $result == 1;
  }

  /**
   * Update the contact data.
   */
  public function update($id, $data = []) {
    // contact.create(table_id, contact_data, dedupe_field)
    $response = $this->adestraClient->request('contact.update', [
      'contact_id' => $id,
      'contact_data' => $data,
    ]);
    // Set the id from response.
    if (isset($response->val) && isset($response->val->me)) {
      $values = array_values($response->val->me);
      $id = array_shift($values);
      return $id;
    }
  }

  /**
   * Find a contact using an array of search arguments.
   */
  public function search($searchArgs) {
    $response = $this->adestraClient->request('contact.search', [
      'table_id' => $this->adestraClient->getTableId(),
      'search_args' => $searchArgs,
    ]);
    $value = $response->val->me['array'];
    if (empty($value)) {
      // Nothing found.
      return NULL;
    }
    elseif (is_array($value) && count($value) == 1) {
      // Only one found.
      return $this->adestraClient->xmlRpcValueToArray($value[0]);
    }
    else {
      // Return array of results.
      return array_map([$this->adestraClient, 'xmlRpcValueToArray'], $value);
    }
  }

}
