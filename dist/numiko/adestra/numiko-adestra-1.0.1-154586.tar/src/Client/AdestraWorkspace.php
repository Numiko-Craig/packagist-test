<?php

namespace Drupal\adestra\Client;

use Drupal\adestra\Client\AdestraClient;

/**
 * Functions for creating and subscribing adestra contacts.
 */
class AdestraWorkspace {

  protected $adestraClient;

  /**
   * Instantiate an Adestra Workspace.
   */
  public function __construct(AdestraClient $adestra_client) {
    $this->adestraClient = $adestra_client;
  }

  /**
   * Find all workspaces.
   */
  public function all() {
    $response = $this->adestraClient->request('workspace.all');
    $value = $response->val->me['array'];
    if (empty($value)) {
      // Nothing found.
      return NULL;
    }
    else {
      // Return array of results.
      return array_map([$this->adestraClient, 'xmlRpcValueToArray'], $value);
    }
  }

}
