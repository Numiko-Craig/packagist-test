<?php

namespace Drupal\adestra\Exception;

/**
 * A base exception thrown in any adestra exception.
 */
class AdestraNoContactFoundException extends AdestraException {

}
