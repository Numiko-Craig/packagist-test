# Numiko Drupal 9 Install Profile

This is the standard Numiko Drupal 9 profile.

In most cases the install profile will be used as part of the [Drupal 9 Composer Template](https://bitbucket.org/numiko/drupal-9-composer-template) - see the instructions there if you want to create a new site from the profile.

# Features

## Initial Install Script

Run this, as per the instruction on the [Composer template README](https://bitbucket.org/numiko/drupal-9-composer-template), and it will build and bring up the Docker environment, create your local settings file, install Drupal, make sure Drupal permissions are correct and build the FE. Now you have a working site.

## Hero

There is an embedded video field, and a field to be used to link directly to a video. It is likely that only one of these will be needed in a project, so remove the one that isn't.

## Useful Scripts

Once you install the site you will have:

`dev/scripts/install-local` - use this after pulling or merging new work, or cloning an existing site for the first time. It's a reliable way to "deploy" a site locally, including all Drupal and FE build steps.
`dev/scripts/build-fe` - builds the front end.

Modify these for the site and keep them up-to-date. Can also be used as a basis for deploy steps.

## Other features of the full Site Kit

* Content types
    * Content Page    
    * Article
* Tidy content editing forms    
* Gin admin theme  
* Slices
    * Accordion
    * Carousel
    * Rich content
    * Form
    * Gallery
    * Media
    * Quote
    * Teaser
    * Views
        * Related content view    
* Base theme and frontend framework
* Media features
    * Focal point and cropping
    * Image API optimise
    * Media types:
      * Document
      * Image
      * Video
    * Responsive images
* Date and time formats
* Security
    * CSP Per Page (Content Security Policy on targeted pages)
    * Password Policy
    * Roles and Personas (user permissions)
    * Seckit module (Various security headers and checks)
    * User login admin (Login uses admin theme)
    * Username Enumeration Prevention module (prevent reveal of usernames)
* Performance modules
    * Advanced Aggregation
    * Minify HTML
    * Redis
* Developer tool modules
    * Config Ignore
    * Mail Safety
    * Stage File Proxy
    * Token
* Search
    * Attachments (searching document files)
    * Autocomplete
    * Facets
* Other Standard modules
    * Client-side Hierarchical Select (for easily selecting tags)
    * Easy Breadcrumb
    * Entity Clone (for duplicating pages)
    * Form UI (Numiko UI improvements)
    * Menu Block (flexible menus)
    * Metatag (meta tags for social media and more)
    * Path Redirect Import (bulk redirect import)
    * Pathauto (automatically assign nice paths to pages)
    * Redirect
    * Schema Metatag (JSON-LD structured data)
    * Simple Sitemap (XML sitemap)
    * Webform
* Local Docker environment


# Demo Site

Work on the install profile can only be tested by deploying a newly built site (the "install" part must have been done again) - anything else wouldn't be a realistic test.

[The demo site is here on Platform.sh](https://console.platform.sh/numiko-user/vitcocdrjuugs). This can be used for internal or client demos and testing. It will be torn down and rebuilt regularly.

To deploy to the site we must delete everything from the repository and drop the database. Files can then be added from the newly built site and its database imported to the Platform server.

After deleting all files from the repository:

* Restore Platform.sh files (`.platform` directory, `.platform.app.yaml`, `settings.platformsh.php`)
* Restore `settings.php` so that the following are done:
** DB array is removed from settings.php
** Platform include is added  
** `$settings['config_sync_directory']` is set
* Do `composer require platformsh/config-reader`

# Development

We're aiming at a moving target. Updates to Drupal and its dependencies will regularly break the profile.

Amending the install profile is not simply a case of making changes on a site and exporting config. You need to make changes on a fresh site that has been built from the install profile. You will probably need to work on multiple related projects - Composer template, theme and framework, modules in their own repos, Docker setup - as the site kit comprises all of these too.

Copy code changes to the appropriate projects. Copy changed config to an install profile working copy, removing unnecessary lines (see below).

It's now necessary to test this on a new site. Tag the changes and update our [package repository](http://non-dev-perm.numiko.local:4567/Numiko-Package-Repository) - the changes must be known to the package repository before a full test can be performed. Create a new site with the [Composer template](https://bitbucket.org/numiko/drupal-9-composer-template).

As you build and destroy sites, you'll need to use `docker-compose down` rather than `stop` to remove all containers and the network, otherwise you'll end up with a lot of unused Docker resources. You will be creating a lot of sites.

It can be better to work on features in batches as doing all of the above one-by-one is too time-consuming.

## Removing unnecessary lines from all config files in a directory:

```
find . -name '*.yml' | xargs sed -i '/^\_core/d'
find . -name '*.yml' | xargs sed -i '/^uuid/d'
find . -name '*.yml' | xargs sed -i '/default\_config\_hash/d'
```
# Diagram

Here is a diagram to show the interaction of the various parts of the Site Kit.

![Diagram](site%20kit.png)