# Numiko Drupal 9 Profile #

This is the standard Numiko Drupal 9 profile.

## How do I get set up? ##

Installation using this distribution will import all modules required, plus all configuration of those modules.

This distribution is included as part of the [Drupal 9 Composer Template](https://bitbucket.org/numiko/drupal-9-composer-template) but can also be imported by cloning this repo or including it in your Drupal installation composer.json file.

```
composer require numiko/d9-profile:*
```
