<?php

namespace Drupal\site_alerts\Form;

use Drupal\Core\Cache\Cache;
use Drupal\Core\Entity\ContentEntityForm;
use Drupal\Core\Form\FormStateInterface;

/**
 * Form controller for Alert edit forms.
 *
 * @ingroup site_alerts
 */
class AlertForm extends ContentEntityForm {

  /**
   * {@inheritdoc}
   */
  public function save(array $form, FormStateInterface $form_state) {
    $entity = $this->entity;

    $status = parent::save($form, $form_state);
    // Clear alerts block cache.
    Cache::invalidateTags(['block:site_alerts']);

    switch ($status) {
      case SAVED_NEW:
        $this->messenger()->addMessage($this->t('Created the %label Alert.', [
          '%label' => $entity->label(),
        ]));
        break;

      default:
        $this->messenger()->addMessage($this->t('Saved the %label Alert.', [
          '%label' => $entity->label(),
        ]));
    }

    $form_state->setRedirect('entity.alert.collection', ['alert' => $entity->id()]);
  }

}
