<?php

namespace Drupal\site_alerts;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityListBuilder;
use Drupal\Core\Link;

/**
 * Defines a class to build a listing of Alert entities.
 *
 * @ingroup site_alerts
 */
class AlertTypeListBuilder extends EntityListBuilder {

  /**
   * {@inheritdoc}
   */
  public function buildHeader() {
    $header['name'] = $this->t('Name');
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    /* @var $entity \Drupal\site_alerts\Entity\Alert */
    $row['name'] = Link::createFromRoute(
      $entity->label(),
      'entity.alert_type.edit_form',
      ['alert_type' => $entity->id()]
    );

    return $row + parent::buildRow($entity);
  }

}
