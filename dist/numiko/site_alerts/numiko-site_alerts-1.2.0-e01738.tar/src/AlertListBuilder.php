<?php

namespace Drupal\site_alerts;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityListBuilder;
use Drupal\Core\Link;

/**
 * Defines a class to build a listing of Alert entities.
 *
 * @ingroup site_alerts
 */
class AlertListBuilder extends EntityListBuilder {

  /**
   * {@inheritdoc}
   */
  public function buildHeader() {
    $header['name'] = $this->t('Name');
    $header['type'] = $this->t('Type');
    $header['warning_level'] = $this->t('Warning level');
    $header['active'] = $this->t('Active');
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    /* @var $entity \Drupal\site_alerts\Entity\Alert */
    $row['name'] = Link::createFromRoute(
      $entity->label(),
      'entity.alert.edit_form',
      ['alert' => $entity->id()]
    );

    $row['type'] = $entity->type->entity->label();
    $row['warning_level'] = $entity->getWarningLevel();
    $row['active'] = $entity->isPublished() ? $this->t('Yes') : $this->t('No');

    return $row + parent::buildRow($entity);
  }

}
