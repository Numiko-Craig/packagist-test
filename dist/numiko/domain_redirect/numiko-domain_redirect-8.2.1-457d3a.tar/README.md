# Domain-Aware Redirects

This module is for sites that use the Domain module.

Once installed, every redirect will have an associated domain. If you add a redirect, the redirect will be associated with the current domain (the one you are logged into).

Add a 'domain' filter to the redirect module to auto-filter admin domain list to the current domain (see domain_redirect_views_pre_build()).

__Important:__ If you have existing redirects with no domain field i.e. you have just installed this module, these will become redirects for the default domain. This seems like a sensible default, but if your use-case is different, you will need to fork this module. 

## TODO

* Modify the redirect view during install.
