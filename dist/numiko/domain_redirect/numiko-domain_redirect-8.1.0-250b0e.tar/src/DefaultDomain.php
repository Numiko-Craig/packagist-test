<?php

namespace Drupal\domain_redirect;

class DefaultDomain {

  /**
   * This is the default value callback for the domain field on the
   * redirect table.
   *
   * Return current domain
   *
   * @return \Drupal\domain\Entity\Domain
   */
  public function defaultValue() {
    $domainNegotiator = \Drupal::service('domain.negotiator');
    if ($domainNegotiator) {
      $domainId = $domainNegotiator->getActiveDomain()->getDomainId();
      return $domainId;
    }
  }
}