<?php
namespace Drupal\domain_redirect;

use Drupal\Core\DependencyInjection\ContainerBuilder;
use Drupal\Core\DependencyInjection\ServiceProviderBase;

class DomainRedirectServiceProvider extends ServiceProviderBase {

  /**
   * {@inheritdoc}
   */
  public function alter(ContainerBuilder $container) {
    // Overrides language_manager class to test domain language negotiation.
    $definition = $container->getDefinition('redirect.repository');
    $definition->setClass('Drupal\domain_redirect\DomainRedirectRepository');
  }
  
}