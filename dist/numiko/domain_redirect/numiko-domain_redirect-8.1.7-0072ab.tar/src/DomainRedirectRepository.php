<?php

namespace Drupal\domain_redirect;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Database\Connection;
use Drupal\Core\Entity\EntityManagerInterface;
use Drupal\Core\Language\Language;
use Drupal\domain\DomainNegotiatorInterface;
use Drupal\redirect\Entity\Redirect;
use Drupal\redirect\Exception\RedirectLoopException;
use Drupal\redirect\RedirectRepository;

/**
 * Overrides RedirectRepository so that we can make redirect domain-aware.
 */
class DomainRedirectRepository extends RedirectRepository {

  /**
   * @var \Drupal\domain\DomainNegotiatorInterface
   */
  private $domainNegotiator;

  public function __construct(EntityManagerInterface $manager, Connection $connection, ConfigFactoryInterface $config_factory) {
    parent::__construct($manager, $connection, $config_factory);
    $this->domainNegotiator = \Drupal::service('domain.negotiator');
  }

  /**
   * {inheritdoc}
   *
   * Had to duplicate an uncomfortable amount of code to add in domain-awareness
   * in this method.
   */
  public function findMatchingRedirect($source_path, array $query = [], $language = Language::LANGCODE_NOT_SPECIFIED) {
    $hashes = [Redirect::generateHash($source_path, $query, $language)];
    if ($language != Language::LANGCODE_NOT_SPECIFIED) {
      $hashes[] = Redirect::generateHash($source_path, $query, Language::LANGCODE_NOT_SPECIFIED);
    }

    // Add a hash without the query string if using passthrough querystrings.
    if (!empty($query) && $this->config->get('passthrough_querystring')) {
      $hashes[] = Redirect::generateHash($source_path, [], $language);
      if ($language != Language::LANGCODE_NOT_SPECIFIED) {
        $hashes[] = Redirect::generateHash($source_path, [], Language::LANGCODE_NOT_SPECIFIED);
      }
    }

    // Only find redirects on the current domain.
    $domainId = $this->domainNegotiator->getActiveDomain()->getDomainId();

    // Load redirects by hash. A direct query is used to improve performance.
    $rid = $this->connection->query('SELECT rid FROM {redirect} WHERE hash IN (:hashes[])  AND domain = :domainId ORDER BY LENGTH(redirect_source__query) DESC', [':hashes[]' => $hashes, ':domainId' => $domainId])->fetchField();

    if (!empty($rid)) {
      // Check if this is a loop.
      if (in_array($rid, $this->foundRedirects)) {
        throw new RedirectLoopException('/' . $source_path, $rid);
      }
      $this->foundRedirects[] = $rid;

      $redirect = $this->load($rid);

      // Find chained redirects.
      if ($recursive = $this->findByRedirect($redirect, $language)) {
        // Reset found redirects.
        $this->foundRedirects = [];
        return $recursive;
      }

      return $redirect;
    }

    return NULL;
  }

  /**
   * {inheritdoc}
   *
   * Add domain-awareness
   */
  public function findBySourcePath($source_path) {
    $domainId = $this->domainNegotiator->getActiveDomain()->getDomainId();
    $ids = $this->manager->getStorage('redirect')->getQuery()
      ->condition('redirect_source.path', $source_path, 'LIKE')
      ->condition('domain', $domainId)
      ->execute();
    return $this->manager->getStorage('redirect')->loadMultiple($ids);
  }
}
