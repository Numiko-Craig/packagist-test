<?php

namespace Drupal\domain_redirect\Plugin\Field\FieldWidget;

use Drupal\Component\Utility\UrlHelper;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Url;
use Drupal\Core\Form\FormStateInterface;
use Drupal\redirect\Plugin\Field\FieldWidget\RedirectSourceWidget;

/**
 * Extend RedirectSourceWidget to add domain-aware validation.
 *
 * Annoyingly there is validation here as well as in RedirectForm.
 *
 * @FieldWidget(
 *   id = "domain_redirect_source",
 *   label = @Translation("Redirect source domain-aware"),
 *   field_types = {
 *     "link"
 *   },
 *   settings = {
 *     "placeholder_url" = "",
 *     "placeholder_title" = ""
 *   }
 * )
 */
class DomainRedirectSourceWidget extends RedirectSourceWidget {

  /**
   * {@inheritdoc}
   */
  public function formElement(FieldItemListInterface $items, $delta, array $element, array &$form, FormStateInterface $form_state) {
    $default_url_value = $items[$delta]->path;
    if ($items[$delta]->query) {
      $default_url_value .= '?' . http_build_query($items[$delta]->query);
    }
    $element['path'] = array(
      '#type' => 'textfield',
      '#title' => $this->t('Path'),
      '#placeholder' => $this->getSetting('placeholder_url'),
      '#default_value' => $default_url_value,
      '#maxlength' => 2048,
      '#required' => $element['#required'],
      '#field_prefix' => Url::fromRoute('<front>', array(), array('absolute' => TRUE))->toString(),
      '#attributes' => array('data-disable-refocus' => 'true'),
    );

    // If creating new URL add checks.
    if ($items->getEntity()->isNew()) {
      $element['status_box'] = array(
        '#prefix' => '<div id="redirect-link-status">',
        '#suffix' => '</div>',
      );

      $source_path = $form_state->getValue(array('redirect_source', 0, 'path'));
      if ($source_path) {
        $source_path = trim($source_path);

        // Warning about the path being already redirected.
        $parsed_url = UrlHelper::parse($source_path);
        $path = isset($parsed_url['path']) ? $parsed_url['path'] : NULL;
        if (!empty($path)) {
          /** @var \Drupal\redirect\RedirectRepository $repository */
          $repository = \Drupal::service('redirect.repository');
          $redirects = $repository->findBySourcePath($path);

          if (!empty($redirects)) {
            $redirect = array_shift($redirects);
            $element['status_box'][]['#markup'] = '<div class="messages messages--warning">' . t('The base source path %source is already being redirected. Do you want to <a href="@edit-page">edit the existing redirect</a>?', array('%source' => $source_path, '@edit-page' => $redirect->url('edit-form'))) . '</div>';
          }
        }
      }

      $element['path']['#ajax'] = array(
        'callback' => 'redirect_source_link_get_status_messages',
        'wrapper' => 'redirect-link-status',
      );
    }

    return $element;
  }

}
