<?php

namespace Drupal\descendants_menu_block\Plugin\Block;

use Drupal\Core\Form\FormStateInterface;

//use Drupal\menu_block\Plugin\Block\MenuBlock;
use Drupal\system\Plugin\Block\SystemMenuBlock;

/**
 * Provides a 'DescendantsMenuBlock' block.
 *
 * @Block(
 *  id = "descendants_menu_block",
 *  admin_label = @Translation("Descendants menu block"),
 *  category = @Translation("Descendants menu"),
 *  deriver = "Drupal\descendants_menu_block\Plugin\Derivative\DescendantsMenuBlock"
 * )
 */
class DescendantsMenuBlock extends SystemMenuBlock {

  /**
   * {@inheritdoc}
   */
  public function blockForm($form, FormStateInterface $form_state) {
    $config = $this->configuration;
    $defaults = array_merge(parent::defaultConfiguration(), $this->defaultConfiguration());

    $form = parent::blockForm($form, $form_state);

    // Default "Expand all menu links" to true
    $form["menu_levels"]["expand_all_items"]["#default_value"] = isset($config['expand_all_items']) ? $config['expand_all_items'] : $defaults['expand_all_items'];
    $form["menu_levels"]["expand_all_items"]["#description"] .= ' ' . $this->t('This must be checked to display descendant links.');

    $form['descendants'] = [
      '#type' => 'details',
      '#title' => $this->t('Descendants options'),
      '#open' => FALSE,
      '#process' => [[get_class(), 'processBlockFieldSets']],
    ];

    $form['descendants']['use_current_page'] = array(
      '#type' => 'checkbox',
      '#title' => '<strong>' . $this->t('Descendants of current page') . '</strong>',
      '#description' => $this->t('Sets fixed parent to the current page and displays child links to the maximum set in "Menu levels".'),
      '#default_value' => isset($config['use_current_page']) ? $config['use_current_page'] : $defaults['use_current_page'],
      '#weight' => '10',
    );

    return $form;
  }

  /**
   * Form API callback: Processes the elements in field sets.
   *
   * Adjusts the #parents of field sets to save its children at the top level.
   */
  public static function processBlockFieldSets(&$element, FormStateInterface $form_state, &$complete_form) {
    array_pop($element['#parents']);
    return $element;
  }

  /**
   * {@inheritdoc}
   */
  public function blockSubmit($form, FormStateInterface $form_state) {
    parent::blockSubmit($form, $form_state);
    $this->configuration['use_current_page'] = $form_state->getValue('use_current_page');
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    $config = $this->configuration;

    if ($config['use_current_page']) {
      $node = \Drupal::routeMatch()->getParameter('node');
      if ($node) {
        $nid = $node->id();
        $parent_plugin_id = $this->getParentPluginID($nid);
        // If we are unable to find node in the menu then we will not show the menu block.
        if (!$parent_plugin_id) {
          return [];
        }
        $config['parent'] = $parent_plugin_id;
        $this->setConfigurationValue('parent', $config['parent']);
      }
    }

    /**
     * Modified MenuBlock::build() from the menu_block module.
     */
    $menu_name = $this->getDerivativeId();
    $parameters = $this->menuTree->getCurrentRouteMenuTreeParameters($menu_name);

    // Adjust the menu tree parameters based on the block's configuration.
    $level = $this->configuration['level'];
    $depth = $this->configuration['depth'];
    $expand = $this->configuration['expand_all_items'];

    $parameters->setMinDepth($level);

    // When the depth is configured to zero, there is no depth limit. When depth
    // is non-zero, it indicates the number of levels that must be displayed.
    // Hence this is a relative depth that we must convert to an actual
    // (absolute) depth, that may never exceed the maximum depth.
    if ($depth > 0) {
      $parameters->setMaxDepth(min($level + $depth - 1, $this->menuTree->maxDepth()));
    }

    // If expandedParents is empty, the whole menu tree is built.
    if ($expand) {
      $parameters->expandedParents = [];
    }

    // When a fixed parent item is set, root the menu tree at the given ID.
    if ($parent_plugin_id) {
      // Clone the parameters so we can fall back to using them if we're
      // following the active menu item and the current page is part of the
      // active menu trail.
      $fixed_parameters = clone $parameters;
      $fixed_parameters->setRoot($parent_plugin_id);
      $tree = $this->menuTree->load($menu_name, $fixed_parameters);

      // Check if the tree contains links.
      if (empty($tree)) {
        // If the starting level is 1, we always want the child links to appear,
        // but the requested tree may be empty if the tree does not contain the
        // active trail. We're accessing the configuration directly since the
        // $level variable may have changed by this point.
        if ($this->configuration['level'] === 1 || $this->configuration['level'] === '1') {
          // Change the request to expand all children and limit the depth to
          // the immediate children of the root.
          $fixed_parameters->expandedParents = [];
          $fixed_parameters->setMinDepth(1);
          $fixed_parameters->setMaxDepth(1);
          // Re-load the tree.
          $tree = $this->menuTree->load($menu_name, $fixed_parameters);
        }
      }
    }

    // Load the tree if we haven't already.
    if (!isset($tree)) {
      $tree = $this->menuTree->load($menu_name, $parameters);
    }
    $manipulators = [
      ['callable' => 'menu.default_tree_manipulators:checkAccess'],
      ['callable' => 'menu.default_tree_manipulators:generateIndexAndSort'],
    ];
    $tree = $this->menuTree->transform($tree, $manipulators);
    $build = $this->menuTree->build($tree);

    if (!empty($build['#theme'])) {
      // Add the configuration for use in menu_block_theme_suggestions_menu().
      $build['#menu_block_configuration'] = $this->configuration;
      // Remove the menu name-based suggestion so we can control its precedence
      // better in menu_block_theme_suggestions_menu().
      $build['#theme'] = 'menu';
    }

    $build['#contextual_links']['menu'] = [
      'route_parameters' => ['menu' => $menu_name],
    ];
    /**
     * End modified MenuBlock::build() from menu_block module.
     */

    return $build;
  }

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration() {
    return [
      'expand_all_items' => TRUE,
      'use_current_page' => 1,
      'level' => 1,
      'depth' => 0,
    ];
  }

  /**
   * {@inheritdoc}
   */
  private function getParentPluginID($nid) {
    $config = $this->configuration;
    $menu_link_manager = \Drupal::service('plugin.manager.menu.link');
    $links = $menu_link_manager->loadLinksByRoute('entity.node.canonical', array('node' => $nid));
    // Return the first result that matches parent in config.
    foreach ($links as $link) {
      $definition = $link->getPluginDefinition();
      if ($config['id'] == ($config['provider'] . ':' . $definition['menu_name'])) {
        return $link->getPluginId();
      }
    }
    return NULL;
  }

}
