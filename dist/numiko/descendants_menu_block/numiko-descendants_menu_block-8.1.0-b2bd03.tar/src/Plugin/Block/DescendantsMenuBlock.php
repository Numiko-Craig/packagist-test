<?php

namespace Drupal\descendants_menu_block\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\system\Entity\Menu;

use Drupal\menu_block\Plugin\Block\MenuBlock;


/**
 * Provides a 'DescendantsMenuBlock' block.
 *
 * @Block(
 *  id = "descendants_menu_block",
 *  admin_label = @Translation("Descendants menu block"),
 *  category = @Translation("Descendants menu"),
 *  deriver = "Drupal\descendants_menu_block\Plugin\Derivative\DescendantsMenuBlock"
 * )
 */
class DescendantsMenuBlock extends MenuBlock {

  /**
   * {@inheritdoc}
   */
  public function blockForm($form, FormStateInterface $form_state) {
    $config = $this->configuration;
    $defaults = $this->defaultConfiguration();

    $form = parent::blockForm($form, $form_state);

    // Default "Expand all menu links" to true
    $form['advanced']['expand']['#default_value'] = isset($config['expand']) ? $config['expand'] : $defaults['expand'];
    $form['advanced']['expand']['#description'] .= ' ' . $this->t('This must be checked to display descendant links.');

    $form['descendants'] = [
      '#type' => 'details',
      '#title' => $this->t('Descendants options'),
      '#open' => FALSE,
      '#process' => [[get_class(), 'processBlockFieldSets']],
    ];

    $form['descendants']['use_current_page'] = array(
      '#type' => 'checkbox',
      '#title' => '<strong>' . $this->t('Descendants of current page') . '</strong>',
      '#description' => $this->t('Sets fixed parent to the current page and displays child links to the maximum set in "Menu levels".'),
      '#default_value' => isset($config['use_current_page']) ? $config['use_current_page'] : $defaults['use_current_page'],
      '#weight' => '10',
    );

    return $form;
  }

  /**
   * Form API callback: Processes the elements in field sets.
   *
   * Adjusts the #parents of field sets to save its children at the top level.
   */
  public static function processBlockFieldSets(&$element, FormStateInterface $form_state, &$complete_form) {
    array_pop($element['#parents']);
    return $element;
  }

  /**
   * {@inheritdoc}
   */
  public function blockSubmit($form, FormStateInterface $form_state) {
    parent::blockSubmit($form, $form_state);
    $this->configuration['use_current_page'] = $form_state->getValue('use_current_page');
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    $config = $this->configuration;

    if ($config['use_current_page']) {
      $node = \Drupal::routeMatch()->getParameter('node');
      if ($node) {
        $nid = $node->id();
        $menu_link_manager = \Drupal::service('plugin.manager.menu.link');
        $result = $menu_link_manager->loadLinksByRoute('entity.node.canonical', array('node' => $nid));
        if (!empty($result)) {
          $config['parent'] = reset($result)->getPluginId();
          $this->setConfigurationValue('parent', $config['parent']);
        }
      }
    }

    $build = parent::build();

    return $build;
  }

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration() {
    return [
      'use_current_page' => 1,
      'expand' => 1,
      'suggestion' => 'descendant',
    ];
  }

}
