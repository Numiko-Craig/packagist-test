<?php

namespace Drupal\form_ui\Form;

use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Form\FormErrorHandler as FormErrorHandlerBase;
use Drupal\Core\Render\Element;
use Drupal\Component\Utility\Unicode;
use Drupal\Core\StringTranslation\TranslatableMarkup;

/**
 * Provides validation of form submissions.
 */
class FormErrorHandler extends FormErrorHandlerBase {

  /**
   * Loops through and displays all form errors.
   *
   * @param array $form
   *   An associative array containing the structure of the form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The current state of the form.
   */
  protected function displayErrorMessages(array $form, FormStateInterface $form_state) {
    $config = \Drupal::config('form_ui.settings');
    if ($config->get('edit_form.form_error_handler')) {
      $this->displayDetailedErrorMessages($form, $form_state);
    } else {
      parent::displayErrorMessages($form, $form_state);
    }
  }

  protected function displayDetailedErrorMessages($form, FormStateInterface $form_state) {
    $errors = $form_state->getErrors();

    // Loop through all form errors and set an error message.
    foreach ($errors as $key => $error) {
      if ($error instanceof TranslatableMarkup) {
        $error = $this->getDetailedFormError($form_state, $key, $error);
      }
      $this->drupalSetMessage($error, 'error');
    }
  }

  /**
   *
   */
  protected function getDetailedFormError(FormStateInterface $form_state, $key, $error) {
    $parents = explode('][', $key);
    $error_arguments = $error->getArguments();
    if ($error_arguments['@name'] instanceof TranslatableMarkup) {
      $field_name = 'The <b>@number item</b> in the <b>@title field</b>';
      $field_arguments = $error_arguments['@name']->getArguments();
      $field_arguments['@number'] = $this->getOrdinalNumber($field_arguments['@number']);
    } else {
      $field_name = 'The <b>@title field</b>';
      $field_arguments['@title'] = $error_arguments['@name'];
    }
    if ($tab = $this->findFieldGroupTab($form_state->getCompleteForm(), $parents[0])) {
      $field_name .= ' in the <b>@tab tab</b>';
      $field_arguments['@tab'] = $tab;
    }
    $translation = \Drupal::service('string_translation');
    $error_message = str_replace('field ', '', $error->getUntranslatedString());
    $error_arguments['@name'] = $translation->translate($field_name, $field_arguments);
    return $translation->translate($error_message, $error_arguments);
  }

  /**
   *
   */
  protected function getOrdinalNumber($number) {
    $formatter = \NumberFormatter::create('en_GB', \NumberFormatter::ORDINAL);
    return $formatter->format($number);
  }

  /**
   * Recursively go up through the groups to find the tab
   */
  protected function findFieldGroupTab($complete_form, $field_name) {
    if (isset($complete_form['#group_children']) && isset($complete_form['#group_children'][$field_name])) {
      $group_name = $complete_form['#group_children'][$field_name];
      if ($complete_form['#fieldgroups'][$group_name]->format_type == 'tab') {
        return $complete_form['#fieldgroups'][$group_name]->label;
      } else {
        return $this->findFieldGroupTab($complete_form, $group_name);
      }
    }
  }

}