<?php

namespace Drupal\form_ui\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\Entity\NodeType;
use Drupal\node\Entity\Node;
use Drupal\form_ui\Factory\ContentEntityCollectionFactory;

/**
 * Class ContentTypeForm.
 *
 * @package Drupal\section_node\Form
 */
class SettingsForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      'form_ui.settings',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'ui_settings_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('form_ui.settings');
    
    $form['edit_form'] = [
      '#type' => 'details',
      '#title' => $this->t('Entity Form'),
      '#open' => true,
    ];

    $form['edit_form']['edit_form_styling'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Apply smaller screen styling alterations'),
      '#description' => $this->t('Including reduced breakpoint'),
      '#default_value' => $config->get('edit_form.styling'),
    ];

    $form['edit_form']['form_error_handler'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Apply Form UI Error Handler to increase detail in form error messages'),
      '#description' => $this->t('This includes adding the tab to the error message where applicable'),
      '#default_value' => $config->get('edit_form.form_error_handler'),
    ];

    $form['redirects'] = [
      '#type' => 'details',
      '#title' => $this->t('Manage Redirects'),
      '#open' => true,
    ];

    $form['redirects']['redirect_editor_login'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Redirect editor login to content overview'),
      '#description' => $this->t('For those users with \'access content overview\' permission'),
      '#default_value' => $config->get('redirects.editor_login'),
    ];

    $values = array();
    $options = ContentEntityCollectionFactory::getOptions();
    foreach ($options as $option_id => $option) {
      if ($config->get('redirects.edit_form.' . $option_id)) {
        $values[] = $option_id;
      }
    }

    $form['redirects']['redirect_entity_edit'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('Redirect the selected entities after edit back to listings'),
      '#options' => $options,
      '#default_value' => $values,
    ];

    $form['redirects']['save_and_continue'] = [
      '#type' => 'checkbox',
      '#title' => 'Add a <em>Save and Continue Editing</em> button to all node forms',
      '#default_value' => $config->get('redirects.save_and_continue')
    ];

    $form['toolbar'] = [
      '#type' => 'details',
      '#title' => $this->t('Manage Toolbar'),
      '#open' => true,
    ];

    $form['toolbar']['toolbar_home_button'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Show the home button on the toolbar'),
      '#description' => $this->t('While browsing the site'),
      '#default_value' => $config->get('toolbar.home_button'),
    ];

    $form['toolbar']['toolbar_shortcuts_label'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Shortcuts title override'),
      '#default_value' => $config->get('toolbar.shortcuts_label'),
    ];

    $form['fields'] = [
      '#type' => 'details',
      '#title' => $this->t('Fields'),
      '#open' => true,
    ];

    $form['fields']['fields_description_display'] = [
      '#type' => 'select',
      '#title' => $this->t('Display placement of field description'),
      '#options' => array(
        'before' => 'Before', 
        'after' => 'After',
      ),
      '#default_value' => $config->get('fields.description_display'),
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    parent::submitForm($form, $form_state);

    $config = $this->config('form_ui.settings');

    $config->set('edit_form.styling', $form_state->getValue('edit_form_styling'));
    $config->set('edit_form.form_error_handler', $form_state->getValue('form_error_handler'));
    $config->set('redirects.editor_login', $form_state->getValue('redirect_editor_login'));
    $config->set('toolbar.home_button', $form_state->getValue('toolbar_home_button'));
    $config->set('toolbar.shortcuts_label', $form_state->getValue('toolbar_shortcuts_label'));
    $config->set('fields.description_display', $form_state->getValue('fields_description_display'));
    $config->set('redirects.save_and_continue', $form_state->getValue('save_and_continue'));

    $redirect_entity_edit_values = array_filter($form_state->getValue('redirect_entity_edit'));
    foreach (ContentEntityCollectionFactory::getOptions() as $id => $label) {
      if (in_array($id, $redirect_entity_edit_values)) {
        $config->set('redirects.edit_form.' . $id, ContentEntityCollectionFactory::getOptionUrl($id));
      } else {
        $config->clear('redirects.edit_form.' . $id);
      }
    }

    $config->save();
  }

}
