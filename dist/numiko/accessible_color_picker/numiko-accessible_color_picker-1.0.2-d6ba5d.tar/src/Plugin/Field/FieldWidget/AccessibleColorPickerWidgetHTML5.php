<?php

namespace Drupal\accessible_color_picker\Plugin\Field\FieldWidget;

use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Form\FormStateInterface;

/**
 * Plugin implementation of the accessible_color_picker HTML5 widget.
 *
 * @FieldWidget(
 *   id = "accessible_color_picker_widget_html5",
 *   module = "accessible_color_picker",
 *   label = @Translation("HTML5 Colour Picker"),
 *   field_types = {
 *     "accessible_color_picker_type"
 *   }
 * )
 */
class AccessibleColorPickerWidgetHTML5 extends AccessibleColorPickerWidgetBase {

  /**
   * {@inheritdoc}
   */
  public static function defaultSettings() {
    return [] + parent::defaultSettings();
  }

  /**
   * {@inheritdoc}
   */
  public function settingsForm(array $form, FormStateInterface $form_state) {
    $element = [];

    return $element;
  }

  /**
   * {@inheritdoc}
   */
  public function settingsSummary() {
    $summary = [];

    return $summary;
  }

  /**
   * {@inheritdoc}
   */
  public function formElement(FieldItemListInterface $items, $delta, array $element, array &$form, FormStateInterface $form_state) {
    $element = parent::formElement($items, $delta, $element, $form, $form_state);
    $element['color']['#type'] = 'color';

    return $element;
  }

}
