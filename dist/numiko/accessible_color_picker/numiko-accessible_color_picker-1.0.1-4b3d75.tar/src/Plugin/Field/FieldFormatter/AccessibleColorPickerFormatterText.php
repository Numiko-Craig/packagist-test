<?php

namespace Drupal\accessible_color_picker\Plugin\Field\FieldFormatter;

use Drupal\accessible_color_picker\Plugin\Field\FieldType\AccessibleColorPickerType;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Field\FormatterBase;

/**
 * Plugin implementation of the accessible_color_picker text formatter.
 *
 * @FieldFormatter(
 *   id = "accessible_color_picker_formatter_text",
 *   module = "accessible_color_picker",
 *   label = @Translation("Colour text"),
 *   field_types = {
 *     "accessible_color_picker_type"
 *   }
 * )
 */
class AccessibleColorPickerFormatterText extends FormatterBase {

  /**
   * {@inheritdoc}
   */
  public function viewElements(FieldItemListInterface $items, $langcode) {
    $elements = [];

    foreach ($items as $delta => $item) {
      $elements[$delta] = ['#markup' => $this->viewValue($item)];
    }

    return $elements;
  }

  /**
   * {@inheritdoc}
   */
  protected function viewValue(AccessibleColorPickerType $item) {
    $output = $item->color;
    return $output;
  }

}
