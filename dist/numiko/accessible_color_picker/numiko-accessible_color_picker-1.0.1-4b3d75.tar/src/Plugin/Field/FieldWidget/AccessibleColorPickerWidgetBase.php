<?php

namespace Drupal\accessible_color_picker\Plugin\Field\FieldWidget;

use Drupal\Component\Utility\Html;
use Drupal\Component\Utility\NestedArray;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Field\WidgetBase;
use Drupal\Core\Form\FormStateInterface;
use GuzzleHttp\Exception\RequestException;

/**
 * Base class for accessible_color_picker widgets.
 */
abstract class AccessibleColorPickerWidgetBase extends WidgetBase {

  const API = 'https://webaim.org/resources/contrastchecker/';

  /**
   * {@inheritdoc}
   */
  public function formElement(FieldItemListInterface $items, $delta, array $element, array &$form, FormStateInterface $form_state) {
    $field_name = $this->fieldDefinition->getName();

    $element['#uid'] = Html::getUniqueId('accessible-color-picker-' . $field_name);
    // Prepare color.
    $color = NULL;
    if (isset($items[$delta]->color)) {
      $color = $items[$delta]->color;
      if (substr($color, 0, 1) !== '#') {
        $color = '#' . $color;
      }
    }

    $element['accessibility'] = [
      '#type' => 'container',
      '#prefix' => '<div id="' . $field_name . '_accessibility">',
      '#suffix' => '</div>',
      '#weight' => 50,
    ];

    $input = [
      '#type' => 'textfield',
      '#maxlength' => 7,
      '#size' => 7,
      '#required' => $element['#required'],
      '#default_value' => $color,
      '#ajax' => [
        'callback' => [$this, 'colorCallback'],
        'event' => 'change',
        'wrapper' => $field_name . '_accessibility',
      ],
    ];

    $field_parents = array_merge($element['#field_parents'], [
      $field_name,
      $delta,
    ]);
    if ($color_value = NestedArray::getValue($form_state->getUserInput(), $field_parents)) {
      $element['accessibility']['response'] = [
        '#type' => 'markup',
        '#markup' => $this->checkCompliance($color_value['color']),
      ];
    }

    $element['color'] = $element + $input;

    return $element;
  }

  /**
   * Ajax callback to rebuild the accessibility form element.
   *
   * @param array $form
   *   The form object.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   *
   * @return mixed
   *   The accessibility form element.
   */
  public function colorCallback(array $form, FormStateInterface $form_state) {
    $form_state->setRebuild(TRUE);
    $triggered_element = $form_state->getTriggeringElement();
    $parents = $triggered_element['#array_parents'];
    return NestedArray::getValue($form, $parents)['accessibility'];
  }

  /**
   * Check the color compliance.
   *
   * @param string $color
   *   The color.
   *
   * @return \Drupal\Core\StringTranslation\TranslatableMarkup|string
   *   Return the markup.
   */
  private function checkCompliance($color) {
    $background = $this->stripHash($this->fieldDefinition->getSetting('background'));
    $color = $this->stripHash($color);
    $web_aim = self::API . '?fcolor=' . $color . '&bcolor=' . $background . '&api';
    $client = \Drupal::httpClient();
    try {
      $response = $client->get($web_aim);
      if ($response->getStatusCode() == 200) {
        $data = json_decode($response->getBody()->getContents(), TRUE);
        $output = [];
        $output['background'] = t('@color checked against @background', [
          '@color' => '#' . $color,
          '@background' => '#' . $background,
        ]);
        foreach ($data as $key => $value) {
          $output[$key] = '<strong>' . ucfirst($key) . ': </strong>' . $value;
        }
        unset($output['AALarge']);
        unset($output['AAALarge']);
        return implode("<br />", $output);
      }
    }
    catch (RequestException $e) {
      watchdog_exception('accessible_color_picker', $e);
    }

    return t('Could not access api - please check manually.');
  }

  /**
   * Strip the hash from the color.
   *
   * @param string $color
   *   The color.
   *
   * @return string
   *   The formatted color.
   */
  private function stripHash($color) {
    return str_replace('#', '', $color);
  }

}
