<?php

namespace Drupal\accessible_color_picker\Plugin\Field\FieldType;

use Drupal\Core\Field\FieldDefinitionInterface;
use Drupal\Core\Field\FieldItemBase;
use Drupal\Core\Field\FieldStorageDefinitionInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\Core\TypedData\DataDefinition;

/**
 * Plugin implementation of the 'accessible_color_picker' field type.
 *
 * @FieldType(
 *   id = "accessible_color_picker_type",
 *   label = @Translation("Accessible Colour Picker"),
 *   description = @Translation("Create and store color value."),
 *   default_widget = "accessible_color_picker_widget_html5",
 *   default_formatter = "accessible_color_picker_formatter_text"
 * )
 */
class AccessibleColorPickerType extends FieldItemBase {

  /**
   * {@inheritdoc}
   */
  public static function mainPropertyName() {
    return 'color';
  }

  /**
   * {@inheritdoc}
   */
  public static function defaultFieldSettings() {
    return [
      'background' => '#000000',
    ] + parent::defaultFieldSettings();
  }

  /**
   * {@inheritdoc}
   */
  public function fieldSettingsForm(array $form, FormStateInterface $form_state) {
    $element = [];

    $element['background'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Background Colour'),
      '#description' => $this->t('The background colour to check against.'),
      '#default_value' => $this->getSetting('background'),
    ];

    return $element;
  }

  /**
   * {@inheritdoc}
   */
  public static function schema(FieldStorageDefinitionInterface $field_definition) {
    return [
      'columns' => [
        'color' => [
          'description' => 'The color value',
          'type' => 'varchar',
          'length' => 7,
          'not null' => FALSE,
        ],
      ],
      'indexes' => [
        'color' => ['color'],
      ],
    ];
  }

  /**
   * {@inheritdoc}
   */
  public static function propertyDefinitions(FieldStorageDefinitionInterface $field_definition) {
    $properties['color'] = DataDefinition::create('string')
      ->setLabel(new TranslatableMarkup('Color'));

    return $properties;
  }

  /**
   * {@inheritdoc}
   */
  public function isEmpty() {
    $value = $this->get('color')->getValue();
    return $value === NULL || $value === '';
  }

  /**
   * {@inheritdoc}
   */
  public function getConstraints() {
    $constraint_manager = \Drupal::typedDataManager()
      ->getValidationConstraintManager();
    $constraints = parent::getConstraints();

    $constraints[] = $constraint_manager->create('ComplexData', [
      'color' => [
        'Regex' => [
          'pattern' => '/^#?(([0-9a-fA-F]{2}){3}|([0-9a-fA-F]){3})$/i',
        ],
      ],
    ]);

    return $constraints;
  }

  /**
   * {@inheritdoc}
   */
  public static function generateSampleValue(FieldDefinitionInterface $field_definition) {
    $values['color'] = '#111AAA';
    return $values;
  }

  /**
   * {@inheritdoc}
   */
  public function preSave() {
    parent::preSave();
    $this->color = $this->formatColor($this->color);
  }

  /**
   * Format the color value.
   *
   * @param string $color
   *   The color.
   *
   * @return bool|string
   *   The formatted color.
   */
  protected function formatColor($color) {
    $color = trim($color);
    if (substr($color, 0, 1) === '#') {
      $color = substr($color, 1);
    }

    $color = '#' . strtoupper($color);
    return $color;
  }

}
