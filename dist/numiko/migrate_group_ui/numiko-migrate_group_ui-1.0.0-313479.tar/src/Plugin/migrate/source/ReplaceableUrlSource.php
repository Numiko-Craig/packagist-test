<?php

namespace Drupal\migrate_group_ui\Plugin\migrate\source;

/**
 * The Data Parser interface for use with Migrate Group UI.
 * This data parser interface exists to force any implementing data parsers to implement the replace url method,
 * this method is needed to allow the UI to alter the url that the parser points to. Required as part of giving a 
 * privileged user the ability to upload the data source through the interface.
 */
interface ReplaceableUrlSource {

    /**
     * Function to be implemented to handle replacing source URL for a plugin.
     */
    public function replaceUrl($url);

    /**
     * Function to be implemented to return the valid extensions.
     */
    public function getValidExtensions();

}