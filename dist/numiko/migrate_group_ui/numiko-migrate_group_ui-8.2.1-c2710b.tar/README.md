# Migrate Group UI #

## What is this module? ##

Builds upon the Migrate Tools module to offer a user interface for executing migrations through the UI.

This module also includes the ability to manually specify a source data file as part of the execution process, by specifying the data parser as using the 'ui_' version of the data parser, included within the module.

## Requirements ##

* Migrate
* Migrate Tools
* Migrate Plus