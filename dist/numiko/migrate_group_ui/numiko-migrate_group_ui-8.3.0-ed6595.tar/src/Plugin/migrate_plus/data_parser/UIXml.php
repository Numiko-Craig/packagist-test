<?php

namespace Drupal\migrate_group_ui\Plugin\migrate_plus\data_parser;

use Drupal\migrate_plus\Plugin\migrate_plus\data_parser\Xml;
use Drupal\migrate_group_ui\Plugin\migrate_plus\data_parser\ReplaceableUrlDataParser;

/**
 * Obtain XML data for migration.
 *
 * @DataParser(
 *   id = "ui_xml",
 *   title = @Translation("XML")
 * )
 */
class UIXml extends Xml implements ReplaceableUrlDataParser {

    protected $extensions = array(
        'xml',
      );

    /**
     * Override the source Urls with the given array.
     */
    public function replaceUrls(array $urls) {
      $this->urls = $urls;
    }

    /**
     * Space seperated list of valid extensions for the uploadable file types.
     */
    public function getValidExtensions() {
      return implode(' ', $this->extensions);
    }

}