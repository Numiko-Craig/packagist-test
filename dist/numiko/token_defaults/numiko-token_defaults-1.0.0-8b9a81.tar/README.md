# Token Defaults

Allows a token to be given a default value in the event of no value being found.

This can be altered per content type.

## To do

Add support for token defaults to include tokens; this would need to be done carefully and MUST avoid the possibility of infinite loops.