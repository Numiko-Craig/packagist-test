Creates the `Manage custom blocks` permission granting access to edit custom blocks.

This gives clients the permission to edit custom blocks without giving access to create, delete or configure them.