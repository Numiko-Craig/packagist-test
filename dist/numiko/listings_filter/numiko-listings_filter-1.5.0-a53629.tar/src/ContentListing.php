<?php

namespace Drupal\listings_filter;

use Drupal\Core\Cache\Cache;
use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Path\CurrentPathStack;
use Drupal\listings_filter\Entity\ListingsParagraphInterface;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\path_alias\AliasManagerInterface;
use Drupal\Core\Entity\TranslatableInterface;
use Drupal\Core\Language\LanguageManagerInterface;
use Drupal\Core\Entity\EntityFieldManagerInterface;
use Drupal\listings_filter\Entity\ListingsParagraph;

/**
 * Class ContentListing.
 *
 * @package Drupal\listings_filter
 */
class ContentListing {

  /**
   * The Entity field manager.
   *
   * @var \Drupal\Core\Entity\EntityFieldManagerInterface
   */
  protected $entityFieldManager;

  /**
   * The current path.
   *
   * @var \Drupal\Core\Path\CurrentPathStack
   */
  protected $currentPath;

  /**
   * The alias manager that caches alias lookups based on the request.
   *
   * @var \Drupal\path_alias\AliasManagerInterface
   */
  protected $aliasManager;

  /**
   * The language manager.
   *
   * @var \Drupal\Core\Language\LanguageManagerInterface
   */
  protected $languageManager;

  /**
   * The Listings Config Paragraph.
   *
   * @var \Drupal\listings_filter\Entity\ListingsParagraph
   */
  protected $listingsParagraph;

  /**
   * The Paragraph.
   *
   * @var \Drupal\paragraphs\Entity\Paragraph
   */
  protected $paragraph;

  /**
   * The listings field processor manager service.
   *
   * @var \Drupal\listings_filter\ListingsFieldProcessorManager
   */
  protected $listingsFieldProcessorManager;

  /**
   * The Entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The listings_filter cache bin.
   *
   * @var \Drupal\Core\Cache\CacheBackendInterface
   */
  protected $cache;

  /**
   * ContentListing constructor.
   *
   * @param \Drupal\Core\Entity\EntityFieldManagerInterface $entity_field_manager
   *   The Entity field manager.
   * @param \Drupal\Core\Path\CurrentPathStack $current_path
   *   The current path.
   * @param \Drupal\path_alias\AliasManagerInterface $alias_manager
   *   The AliasManager.
   * @param \Drupal\Core\Language\LanguageManagerInterface $language_manager
   *   The language manager.
   * @param \Drupal\listings_filter\ListingsFieldProcessorManager $listings_field_processor_manager
   *   The listings field processor manager service.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The Entity type manager.
   * @param \Drupal\Core\Cache\CacheBackendInterface $cache
   *   The listings_filter cache bin.
   */
  public function __construct(EntityFieldManagerInterface $entity_field_manager,
                              CurrentPathStack $current_path,
                              AliasManagerInterface $alias_manager,
                              LanguageManagerInterface $language_manager,
                              ListingsFieldProcessorManager $listings_field_processor_manager,
                              EntityTypeManagerInterface $entity_type_manager,
                              CacheBackendInterface $cache) {
    $this->entityFieldManager = $entity_field_manager;
    $this->aliasManager = $alias_manager;
    $this->currentPath = $current_path;
    $this->languageManager = $language_manager;
    $this->listingsFieldProcessorManager = $listings_field_processor_manager;
    $this->entityTypeManager = $entity_type_manager;
    $this->cache = $cache;
  }

  /**
   * Build the JS to pass to VueJS.
   *
   * @param \Drupal\listings_filter\Entity\ListingsParagraph $listings_paragraph
   *   The listings paragraph configuration.
   * @param \Drupal\paragraphs\Entity\Paragraph $paragraph
   *   The paragraph we are viewing.
   *
   * @return array
   *   The JS.
   *
   * @throws \Drupal\Component\Plugin\Exception\PluginException
   */
  public function buildJs(ListingsParagraph $listings_paragraph, Paragraph $paragraph): array {
    $this->listingsParagraph = $listings_paragraph;
    $this->paragraph = $paragraph;
    $itemsPerPageFieldKey = $this->listingsParagraph->getItemsPerPageField();
    return [
      'reset_path' => $this->aliasManager->getAliasByPath($this->currentPath->getPath()),
      'items_per_page' => $this->paragraph->hasField($itemsPerPageFieldKey) ? (int) $this->paragraph->get($itemsPerPageFieldKey)->getString() : $this->listingsParagraph->getItemsPerPageValue(),
      'default_sorts' => $this->listingsParagraph->getSortValues(),
      'user_sorts' => $this->listingsParagraph->getUserSortValues(),
      'facets' => $this->getFacets(),
      'filters' => array_merge($this->listingsParagraph->getPrefilterValues(), $this->getPreFilters()),
      'promoted' => $this->getPinnedItems(),
      'listing_id' => $paragraph->bundle(),
      'paragraph_id' => $paragraph->id(),
      'keyword' => (bool) $this->listingsParagraph->getHasKeyword(),
    ];
  }

  /**
   * Get the pre filters.
   *
   * @return array
   *   The pre filters.
   *
   * @throws \Drupal\Component\Plugin\Exception\PluginException
   */
  private function getPreFilters(): array {
    $preFilters = [];
    foreach ($this->listingsParagraph->getPrefilterFields() as $fieldName => $definition) {
      if ($this->paragraph->hasField($fieldName) && !$this->paragraph->get($fieldName)->isEmpty()) {
        $instance = $this->listingsFieldProcessorManager->createInstance($definition['processor']);
        if ($instance) {
          $preFilters[$definition['search_key']] = $instance->processField($this->paragraph->get($fieldName));
        }
      }
    }
    return $preFilters;
  }

  /**
   * Get the facets.
   *
   * @return array
   *   The facets.
   */
  private function getFacets(): array {
    $activeFacets = [];
    $facetsFieldKey = $this->listingsParagraph->getFacetsField();
    if ($this->paragraph->hasField($facetsFieldKey)) {
      if (!$this->paragraph->get($facetsFieldKey)->isEmpty()) {
        foreach ($this->paragraph->get($facetsFieldKey)->referencedEntities() as $weight => $filter) {
          if ($filter instanceof TranslatableInterface && $filter->isTranslatable() && $filter->hasTranslation($this->languageManager->getCurrentLanguage()->getId())) {
            $filter = $filter->getTranslation($this->languageManager->getCurrentLanguage()->getId());
          }
          $activeFacets[$filter->get('url_alias')] = [
            'weight' => $weight,
            'label' => $filter->label(),
            'show_only_one_result' => $filter->getShowOnlyOneResult() ? TRUE : FALSE,
          ];
        }
      }
    }

    return $activeFacets;
  }

  /**
   * Get the fields on the paragraph.
   *
   * @return \Drupal\Core\Field\FieldDefinitionInterface[]
   *   Paragraph fields.
   */
  private function getFields() {
    $bundleFields = $this->entityFieldManager->getFieldDefinitions('paragraph', $this->paragraph->bundle());
    return array_filter($bundleFields, function ($field) {
      return !$field->getFieldStorageDefinition()->isBaseField();
    });
  }

  /**
   * Get the pinned content items and return the uuid.
   *
   * @return array
   *   The pinned content items.
   */
  private function getPinnedItems(): array {
    $values = [];
    $pinnedItemsFieldKey = $this->listingsParagraph->getPinnedItemsField();
    if ($this->paragraph->hasField($pinnedItemsFieldKey)) {
      foreach ($this->paragraph->get($pinnedItemsFieldKey)->referencedEntities() as $value) {
        $values[$value->uuid()] = $value->uuid();
      }
    }

    return $values;
  }

  /**
   * Get slice/paragraph types are are set as listing paragraphs.
   *
   * @return array
   *   Array of paragraph type IDs.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  public function getListingParagraphSliceTypes() {
    // Attempt to retrieve types from cache.
    $cachedData = $this->cache->get('listings_paragraph:paragraph_types');
    if ($cachedData) {
      $paragraphTypes = $cachedData->data;
    }
    else {
      $listingParagraphEntities =
        $this->entityTypeManager
        ->getStorage('listings_paragraph')
          ->loadMultiple();
      $paragraphTypes = [];
      foreach ($listingParagraphEntities as $listingParagraphEntity) {
        $paragraphTypes[] = $listingParagraphEntity->get('paragraph_type_id');
      }
      // Store in cache.
      // Invalidate when a listing paragraph entity is saved.
      $this->cache->set(
        'listings_paragraph:paragraph_types',
        $paragraphTypes,
        Cache::PERMANENT,
        ['config:listings_paragraph_list']
      );
    }
    return $paragraphTypes;
  }

  /**
   * Get content type prefilter from listing paragraph.
   *
   * @param \Drupal\listings_filter\Entity\ListingsParagraphInterface $listingParagraph
   *   Listing paragraph.
   *
   * @return array
   */
  public function getListingParagraphContentTypePrefilters(ListingsParagraphInterface $listingParagraph) {
    $prefilters = $listingParagraph->getPrefilterValues();
    if (isset($prefilters['prefilter_type'])) {
      $prefilters = $prefilters['prefilter_type'];
      return array_map(function ($prefilter) {
        return $prefilter['target_id'];
      }, $prefilters);
    }
    return [];
  }

  /**
   * Get Listing paragraph entity from slice type.
   *
   * @param string $sliceType
   *   Slice type machine name.
   *
   * @return \Drupal\listings_filter\Entity\ListingsParagraphInterface|null
   *   Get the listing paragraph entity related to a slice type.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  public function getListingParagraphFromSliceType($sliceType) {
    /** @var \Drupal\listings_filter\Entity\ListingsParagraphInterface[] */
    $listingParagraphEntities =
      $this->entityTypeManager
        ->getStorage('listings_paragraph')
        ->loadMultiple();
    foreach ($listingParagraphEntities as $listingParagraphEntity) {
      if ($listingParagraphEntity->get('paragraph_type_id') == $sliceType) {
        return $listingParagraphEntity;
      }
    }
    return NULL;
  }

}
