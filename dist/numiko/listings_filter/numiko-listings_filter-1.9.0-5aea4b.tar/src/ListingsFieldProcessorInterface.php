<?php

namespace Drupal\listings_filter;

use Drupal\Core\Field\FieldItemList;
use Drupal\Component\Plugin\PluginInspectionInterface;

/**
 * The interface for a listings field processor.
 */
interface ListingsFieldProcessorInterface extends PluginInspectionInterface {

  /**
   * The process field method must be implemented.
   */
  public function processField(FieldItemList $field);

}
