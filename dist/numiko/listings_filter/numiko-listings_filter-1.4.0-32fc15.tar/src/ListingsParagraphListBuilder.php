<?php

namespace Drupal\listings_filter;

use Drupal\Core\Config\Entity\ConfigEntityListBuilder;
use Drupal\Core\Entity\EntityInterface;

/**
 * Provides a listing of Listings paragraph entities.
 */
class ListingsParagraphListBuilder extends ConfigEntityListBuilder {

  /**
   * {@inheritdoc}
   */
  public function buildHeader() {
    $header['label'] = $this->t('Listings paragraph');
    $header['id'] = $this->t('Machine name');
    $header['paragraph_bundle'] = $this->t('Paragraph bundle');
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    $row['label'] = $entity->label();
    $row['id'] = $entity->id();
    $row['paragraph_bundle'] = $entity->getParagraphTypeId();
    return $row + parent::buildRow($entity);
  }

}
