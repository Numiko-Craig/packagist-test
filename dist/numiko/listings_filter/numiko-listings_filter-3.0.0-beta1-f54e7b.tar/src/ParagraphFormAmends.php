<?php

namespace Drupal\listings_filter;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityFieldManagerInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\listings_filter\Entity\ListingsParagraphInterface;

/**
 * Class ParagraphFormAmends.
 *
 * Method used to restrict listing paragraph
 * facet options in the paragraph node form.
 *
 * @package Drupal\listings_filter
 */
class ParagraphFormAmends {

  const DEFAULT_SEARCH_INDEX = 'site';
  const FACET_SOURCE_ID_WITHOUT_INDEX = 'listing_filter_search_api_facets:';

  /**
   * The Entity field manager.
   *
   * @var \Drupal\Core\Entity\EntityFieldManagerInterface
   */
  protected $entityFieldManager;

  /**
   * The Entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The listings_filter service.
   *
   * @var \Drupal\listings_filter\ContentListing
   */
  protected $contentListing;

  /**
   * The search_api index used by the JSON API facets.
   *
   * @var string
   */
  protected $searchApiIndex;

  /**
   * ParagraphFormAmends constructor.
   *
   * @param \Drupal\Core\Entity\EntityFieldManagerInterface $entity_field_manager
   *   The Entity field manager.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The Entity type manager.
   * @param \Drupal\listings_filter\ContentListing $content_listing
   *   The listings_filter service.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The config factory service.
   */
  public function __construct(EntityFieldManagerInterface $entity_field_manager,
                              EntityTypeManagerInterface $entity_type_manager,
                              ContentListing $content_listing,
                              ConfigFactoryInterface $config_factory) {
    $this->entityFieldManager = $entity_field_manager;
    $this->entityTypeManager = $entity_type_manager;
    $this->contentListing = $content_listing;
    // Get search api index. Use fallback for backwards compatibility.
    $index = $config_factory->get('listings_filter.settings')->get('index');
    if ($index) {
      $this->searchApiIndex = $index;
    }
    else {
      $this->searchApiIndex = self::DEFAULT_SEARCH_INDEX;
    }
  }

  /**
   * Set field_facets options on listing paragraph slice form.
   *
   * Restricts options to the facets that could filter
   * content types that could appear in the results.
   * For example, the news content type, could not be filtered
   * by event type because it doesn't have the field defined.
   * Therefore the event type facet is removed as an option
   * from a news listing paragraph slice form.
   *
   * @param array $element
   *   Paragraph form element.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  public function setFacetOptions(array &$element) {
    $listingParagraph = $this->contentListing->getListingParagraphFromSliceType($element['#paragraph_type']);
    if (!isset($listingParagraph)) {
      return;
    }

    // Check that listing paragraph can have facets added.
    $facetField = $listingParagraph->getFacetsField();
    if (!isset($facetField)) {
      return;
    }

    // Get content types of any potential result.
    // Either any prefilter types, or any indexed types.
    $availableEntityTypes = $this->getResultsPotentialContentTypes($listingParagraph);

    // Build facet options.
    $availableFacets = ['_none' => '- None -'];
    foreach ($availableEntityTypes as $entityType) {
      $facetsAvailable = $this->getFacetsRelevantToContentType($entityType);
      if (isset($facetsAvailable)) {
        $availableFacets = array_merge($availableFacets, $facetsAvailable);
      }
    }

    // Set select options.
    $element['subform']['field_facets']['widget']['#options'] = $availableFacets;
  }

  /**
   * Get results' potential content types.
   *
   * Calculate potential content types of
   * results. Taking into account content
   * type prefilters and search_api content
   * data source.
   *
   * @param \Drupal\listings_filter\Entity\ListingsParagraphInterface $listingParagraph
   *   Listing paragraph for which to calculate content types.
   *
   * @return array
   *   Array of possible result content types.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  protected function getResultsPotentialContentTypes(ListingsParagraphInterface $listingParagraph) {
    $entityTypePrefilters = $this->contentListing->getListingParagraphPrefilters('type', $listingParagraph);
    $entityBundlePrefilters = $this->contentListing->getListingParagraphPrefilters('bundle', $listingParagraph);
    $entityPrefilters = array_merge($entityTypePrefilters, $entityBundlePrefilters);

    // If content type prefilters are set, return them.
    // Otherwise load all content types indexed on the datasource.
    if (empty($entityPrefilters)) {
      $site = $this->entityTypeManager->getStorage('search_api_index')->load($this->searchApiIndex);
      $bundleSettings = [];
      foreach($site->get('datasource_settings') as $entityTypeId => $entityType) {
        $siteContentBundleSettings = $entityType['bundles'];
        // If default is set, exclude selected from all content types.
        // Otherwise include selected content types.
        if ($siteContentBundleSettings['default']) {
          $bundleType = explode(':', $entityTypeId)[1];
          $datasourceContentTypes = $site->getDatasource($entityTypeId)
            ->getEntityTypeBundleInfo()
            ->getBundleInfo($bundleType);
          foreach ($siteContentBundleSettings['selected'] as $selection) {
            if (isset($datasourceContentTypes[$selection])) {
              unset($datasourceContentTypes[$selection]);
            }
          }
          $bundleSettings[$entityTypeId] = array_keys($datasourceContentTypes);
        }
        else {
          $bundleSettings[$entityTypeId] = $siteContentBundleSettings['selected'];
        }
      }

      return $bundleSettings;
    }
    else {
      return $entityPrefilters;
    }
  }

  /**
   * Get facets relevant to content type.
   *
   * @param array $contentType
   *   Content type.
   *
   * @return array
   *   Array of available facet options.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  protected function getFacetsRelevantToContentType($contentType) {
    $facets = $this->entityTypeManager->getStorage('facets_facet')->loadByProperties(['facet_source_id' => self::FACET_SOURCE_ID_WITHOUT_INDEX . $this->searchApiIndex]);
    $availableFacets = [];
    foreach ($facets as $facet) {
      $searchApiFieldIdentifier = $facet->toArray()['field_identifier'];
      $site = $this->entityTypeManager->getStorage('search_api_index')->load($this->searchApiIndex);
      $fieldsSettings = $site->get('field_settings')[$searchApiFieldIdentifier];
      $fieldName = $fieldsSettings['property_path'];
      // Get the entity type from the search api datasource.
      if (!isset($fieldsSettings['datasource_id'])) {
        continue;
      }
      $entity_type = explode(':', $fieldsSettings['datasource_id'])[1];
      $fieldDefinitions = [];
      if (is_array($contentType)) {
        foreach ($contentType as $type) {
          $fieldDefinitions += $this->entityFieldManager->getFieldDefinitions($entity_type, $type);
        }
      }
      else {
        $fieldDefinitions += $this->entityFieldManager->getFieldDefinitions($entity_type, $contentType);
      }
      if (isset($fieldDefinitions[$fieldName])) {
        $availableFacets[$facet->id()] = $facet->label();
      }
    }

    // Invoke an alter hook so other modules can alter the available facets.
    // This is useful in cases where a facet does not exist on a node such as
    // an aggregated field.
    \Drupal::moduleHandler()->alter('listings_filter_get_relevant_facets', $availableFacets, $contentType);
    return $availableFacets;
  }

}
