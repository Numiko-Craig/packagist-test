<?php

namespace Drupal\listings_filter\Plugin\facets\url_processor;

use Drupal\facets\FacetInterface;
use Drupal\facets\Plugin\facets\url_processor\QueryString;

/**
 * Query string URL processor.
 *
 * @FacetsUrlProcessor(
 *   id = "listings_filter",
 *   label = @Translation("Listing Filter Query string"),
 *   description = @Translation("Process facets for listing filters.")
 * )
 */
class ListingApiQueryString extends QueryString {

  /**
   * An array of the existing non-facet filters.
   *
   * @var array
   *  The filters.
   */
  protected $originalFilters = [];

  /**
   * {@inheritDoc}
   */
  protected function initializeActiveFilters() {
    $url_parameters = $this->request->query;

    // Get the active facet parameters.
    $active_params = $url_parameters->get('filter', []);

    // When an invalid parameter is passed in the url, we can't do anything.
    if (!is_array($active_params)) {
      return;
    }

    foreach ($active_params as $param_identifier => $param_value) {
      // Check if this is a complex filter definition.
      if (isset($param_value['value'])) {
        $facet_id = $this->entityTypeManager->getStorage('facets_facet')->load($param_identifier);
        // Skip filters that do not target facets.
        if ($facet_id === NULL) {
          $this->originalFilters[$param_identifier] = $param_value;
          continue;
        }
        $this->activeFilters[$facet_id->id()] = [];
        foreach ($param_value['value'] as $condition_value) {
          $this->activeFilters[$facet_id->id()][] = $condition_value;
        }
      }
      // This is not a filter condition.
      else {
        $this->originalFilters[$param_identifier] = $param_value;
      }
    }
  }

  /**
   * {@inheritdoc}
   */
  public function setActiveItems(FacetInterface $facet) {
    // Get the filter key of the facet.
    if (isset($this->activeFilters[$facet->id()])) {
      $active_filters = $this->activeFilters[$facet->id()];
      if (is_array($active_filters)) {
        $facet->setActiveItems($active_filters);
      }
      else {
        $facet->setActiveItem($active_filters);
      }
    }
  }
}
