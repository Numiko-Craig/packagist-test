<?php

namespace Drupal\listings_filter\Plugin\ListingsFieldProcessor;

use Drupal\Core\Field\FieldItemList;
use Drupal\listings_filter\ListingsFieldProcessorBase;

/**
 * Provides a value field listing processor.
 *
 * @ListingsFieldProcessor(
 *   id = "value_target",
 *   name = @Translation("Value to Target"),
 *   description = @Translation("Map the value")
 * )
 */
class ValueTargetFieldProcessor extends ListingsFieldProcessorBase {

  /**
   * Get the value from the value field.
   */
  public function processField(FieldItemList $field) {
    $values = [
      'op' => 'IN',
      'value' => [],
    ];

    $values['value'] += array_map(function ($value) {
      return $value['value'];
    }, $field->getValue());

    return $values;
  }

}
