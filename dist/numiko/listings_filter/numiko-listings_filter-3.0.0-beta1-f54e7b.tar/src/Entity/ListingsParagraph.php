<?php

namespace Drupal\listings_filter\Entity;

use Drupal\Core\Config\Entity\ConfigEntityBase;

/**
 * Defines the Listings paragraph entity.
 *
 * @ConfigEntityType(
 *   id = "listings_paragraph",
 *   label = @Translation("Listings paragraph"),
 *   handlers = {
 *     "view_builder" = "Drupal\Core\Entity\EntityViewBuilder",
 *     "list_builder" = "Drupal\listings_filter\ListingsParagraphListBuilder",
 *     "form" = {
 *       "add" = "Drupal\listings_filter\Form\ListingsParagraphForm",
 *       "edit" = "Drupal\listings_filter\Form\ListingsParagraphForm",
 *       "delete" = "Drupal\listings_filter\Form\ListingsParagraphDeleteForm"
 *     },
 *     "route_provider" = {
 *       "html" = "Drupal\listings_filter\ListingsParagraphHtmlRouteProvider",
 *     },
 *   },
 *   config_prefix = "listings_paragraph",
 *   admin_permission = "administer site configuration",
 *   entity_keys = {
 *     "id" = "id",
 *     "label" = "label",
 *     "paragraph_type_id" = "paragraph_type_id",
 *     "uuid" = "uuid"
 *   },
 *   config_export = {
 *     "id",
 *     "label",
 *     "paragraph_type_id",
 *     "uuid",
 *     "prefilter_fields",
 *     "filter_fields",
 *     "prefilter_values",
 *     "sort_values",
 *     "user_sort_values",
 *     "facets_field",
 *     "pinned_items_field",
 *     "items_per_page_field",
 *     "items_per_page_value",
 *     "result_count_field",
 *     "result_count_value",
 *     "has_keyword",
 *     "display_mode",
 *     "promoted_display_mode",
 *     "promoted_content_field"
 *   },
 *   links = {
 *     "canonical" = "/admin/structure/listings_paragraph/{listings_paragraph}",
 *     "add-form" = "/admin/structure/listings_paragraph/add",
 *     "edit-form" = "/admin/structure/listings_paragraph/{listings_paragraph}/edit",
 *     "delete-form" = "/admin/structure/listings_paragraph/{listings_paragraph}/delete",
 *     "collection" = "/admin/structure/listings_paragraph"
 *   }
 * )
 */
class ListingsParagraph extends ConfigEntityBase implements ListingsParagraphInterface {

  /**
   * The Listings paragraph ID.
   *
   * @var string
   */
  protected $id;

  /**
   * The Listings paragraph label.
   *
   * @var string
   */
  protected $label;

  /**
   * The paragraph type ID to reference.
   *
   * @var string
   */
  protected $paragraph_type_id;

  /**
   * The Listings paragraph prefilter fields.
   *
   * @var array
   */
  protected $prefilter_fields;

  /**
   * The Listings paragraph facets field.
   *
   * @var string
   */
  protected $facets_field;

  /**
   * The Listings paragraph pinned items field.
   *
   * @var string
   */
  protected $pinned_items_field;

  /**
   * The Listings paragraph items per page field.
   *
   * @var string
   */
  protected $items_per_page_field;

  /**
   * The Listings paragraph items per page value.
   *
   * @var int
   */
  protected $items_per_page_value;

  /**
   * The Listings paragraph result count field.
   *
   * @var string
   */
  protected $result_count_field;

  /**
   * The Listings paragraph result count value.
   *
   * @var int
   */
  protected $result_count_value;

  /**
   * The Listings paragraph prefilter values.
   *
   * @var array
   */
  protected $prefilter_values;

  /**
   * The Listings paragraph sort values.
   *
   * @var array
   */
  protected $sort_values;

  /**
   * The Listings paragraph user sort values.
   *
   * @var array
   */
  protected $user_sort_values;

  /**
   * Whether the listings paragraph has a keyword search.
   *
   * @var bool
   */
  protected $has_keyword;

  /**
   * The display mode used to render the entity markup.
   *
   * @var string
   */
  protected $display_mode;

  /**
   * The display mode used to render the promoted entity markup.
   *
   * @var string
   */
  protected $promoted_display_mode;

  /**
   * The field used to search against for promoted content.
   *
   * @var string
   */
  protected $promoted_content_field;

  /**
   * {@inheritDoc}
   */
  public function getParagraphTypeId() {
    return $this->paragraph_type_id;
  }

  /**
   * {@inheritDoc}
   */
  public function setParagraphTypeId(string $paragraphTypeId) {
    $this->paragraph_type_id = $paragraphTypeId;

    return $this;
  }

  /**
   * {@inheritDoc}
   */
  public function getPrefilterFields() {
    return $this->prefilter_fields;
  }

  /**
   * {@inheritDoc}
   */
  public function setPrefilterFields(array $prefilterFields) {
    $this->prefilter_fields = $prefilterFields;

    return $this;
  }

  /**
   * {@inheritDoc}
   */
  public function getFacetsField() {
    return $this->facets_field;
  }

  /**
   * {@inheritDoc}
   */
  public function setFacetsField(string $facetsField) {
    $this->facets_field = $facetsField;

    return $this;
  }

  /**
   * {@inheritDoc}
   */
  public function getPinnedItemsField() {
    return $this->pinned_items_field;
  }

  /**
   * {@inheritDoc}
   */
  public function setPinnedItemsField(string $pinnedItemsField) {
    $this->pinned_items_field = $pinnedItemsField;

    return $this;
  }

  /**
   * {@inheritDoc}
   */
  public function getItemsPerPageField() {
    return $this->items_per_page_field;
  }

  /**
   * {@inheritDoc}
   */
  public function setItemsPerPageField(string $itemsPerPageField) {
    $this->items_per_page_field = $itemsPerPageField;

    return $this;
  }

  /**
   * {@inheritDoc}
   */
  public function getItemsPerPageValue() {
    return $this->items_per_page_value;
  }

  /**
   * {@inheritDoc}
   */
  public function setItemsPerPageValue(int $itemsPerPageValue) {
    $this->items_per_page_value = $itemsPerPageValue;

    return $this;
  }

  /**
   * {@inheritDoc}
   */
  public function getResultCountField() {
    return $this->result_count_field;
  }

  /**
   * {@inheritDoc}
   */
  public function setResultCountField(string $resultCountField) {
    $this->result_count_field = $resultCountField;

    return $this;
  }

  /**
   * {@inheritDoc}
   */
  public function getResultCountValue() {
    return $this->result_count_value;
  }

  /**
   * {@inheritDoc}
   */
  public function setResultCountValue(int $resultCountValue) {
    $this->result_count_value = $resultCountValue;

    return $this;
  }

  /**
   * {@inheritDoc}
   */
  public function getPrefilterValues() {
    return empty($this->prefilter_values) ? [] : $this->prefilter_values;
  }

  /**
   * {@inheritDoc}
   */
  public function setPrefilterValues(array $prefilterValues) {
    $this->prefilter_values = $prefilterValues;

    return $this;
  }

  /**
   * {@inheritDoc}
   */
  public function getSortValues() {
    return empty($this->sort_values) ? [] : $this->sort_values;
  }

  /**
   * {@inheritDoc}
   */
  public function setSortValues(array $sortValues) {
    $this->sort_values = $sortValues;

    return $this;
  }

  /**
   * {@inheritDoc}
   */
  public function getUserSortValues() {
    if (empty($this->user_sort_values)) {
      return [];
    }

    // For backwards compatibility.
    // If a direction is empty, unset it in the data to return.
    $userSortsToReturn = $this->user_sort_values;
    foreach ($userSortsToReturn as $key => $userSort) {
      if (empty($userSort['direction'])) {
        unset($userSortsToReturn[$key]['direction']);
      }
    }
    return $userSortsToReturn;
  }

  /**
   * {@inheritDoc}
   */
  public function setUserSortValues(array $userSortValues) {
    $this->user_sort_values = $userSortValues;

    return $this;
  }

  /**
   * {@inheritDoc}
   */
  public function getHasKeyword() {
    return $this->has_keyword;
  }

  /**
   * {@inheritDoc}
   */
  public function setHasKeyword(bool $has_keyword) {
    $this->has_keyword = $has_keyword;

    return $this;
  }

  /**
   * {@inheritDoc}
   */
  public function getDisplayMode() {
    return $this->display_mode;
  }

  /**
   * {@inheritDoc}
   */
  public function setDisplayMode(?string $displayMode) {
    $this->display_mode = $displayMode;

    return $this;
  }

  /**
   * {@inheritDoc}
   */
  public function getPromotedDisplayMode() {
    return $this->promoted_display_mode;
  }

  /**
   * {@inheritDoc}
   */
  public function setPromotedDisplayMode(?string $displayMode) {
    $this->promoted_display_mode = $displayMode;

    return $this;
  }

  /**
   * {@inheritDoc}
   */
  public function getPromotedContentField() {
    return $this->promoted_content_field;
  }

  /**
   * {@inheritDoc}
   */
  public function setPromotedContentField(string $field) {
    $this->promoted_content_field = $field;

    return $this;
  }

}
