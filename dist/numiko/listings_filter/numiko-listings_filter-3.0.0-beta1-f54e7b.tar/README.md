# Listings Filter

Map listing filter paragraphs to the drupalSettings.listing javascript object, ready to be accessed by a front-end approach.

## Installation

Install the module as usual `drush en listings_filter`

## Configuration

In order to setup a listing paragraph:

 1. Create a paragraph [/admin/structure/paragraphs_type/add]
 1. Add the following fields (each is optional and should work in any combination):
    * Facets field - entity reference field to select one or more facets to display
    * Pinned items field - entity reference field to select one or more nodes to display pinned
    * Items per page field - integer field if you would like the CMS editor to define how many items show per page
    * Result count field - integer field if you would like the CMS editor to define the maximum number of results
    * Any fields referencing taxonomy or nodes to allow the content to be pre-filtered by the CMS user
 1. Enable the paragraph as a listings filter paragraph type [/admin/structure/listings_paragraph/settings]
 1. Create a listings paragraph config entity [/admin/structure/listings_paragraph/add]
 1. After saving click 'Edit' to configure the fields (optional):
    * Facets field - select the facets entity reference field
    * Pinned items field - select the pinned items content entity reference field
    * Items per page field - select the integer field to store the number of items per page
    * Items per page value - enter the number of items to display per page if Items per page field is not set
    * Result count field - select the integer field to store the maximum number of results for this listing
    * Result count value - enter the maximum number of results if Result count field is not set
    * Check 'provide a keyword search' to enable a keyword search
    * Display mode - The display mode to render the entity.
    * Promoted display mode - If using promoted content set the display mode to render the entity.
    * Promoted content field - Set the field to search on when using promoted content. e.g uuid.
    * Prefilter fields - select any entity reference fields to be used to prefilter the search listing and identify the search field to be mapped to (see Processors below)
    * Prefilter values - enter any hardcoded values to be passed to the filter for this paragraph type (e.g. content_type), as well as the value add the prefilter key for the value array (e.g. target_id for a node reference field ['target_id' => 12] - where 12 is your node ID)
    * Default sorts - define one or more search fields to use to sort the listing results, alongside the sort direction
    * User sorts - define one or more search fields to be exposed to the user as interactable sorts, alongside the label

After carrying out the steps above your paragraph template will now have access to drupalSettings.listing which will be populated from a combination of the predefined values and values stored in the fields selected by the CMS editor.

## Prefilter Value Processors

Most of the prefilter fields are simply a case of passing the data from the field value array to the search field, this is certainly true of taxonomy fields for example, so for these we use the default **Get Value** processor.

However occassionally there is a requirement to cast a field of one format into another, so processors are available for these fields, you can add custom processors using the **@ListingsFieldProcessor** annotation, a couple of options are available for use or as examples, these can be found in the Plugin / ListingFieldProcessor folder.

### Annotation

Listing field processors (**@ListingsFieldProcessor**) should include an ID string, a label and a description.

```
/**
 * Provides a direct field listing processor.
 *
 * @ListingsFieldProcessor(
 *   id = "get_value",
 *   name = @Translation("Get Value"),
 *   description = @Translation("Map the value of the field to search API")
 * )
 */
```

The class must implement the `processField(FieldItemList $field)` method, and return the field value in the format expected for the search field you are trying to map to, for example here is the get value processor processField method:

```
/**
 * Pass the value of the field directly to search API.
 */
public function processField(FieldItemList $field) {
  return $field->getValue();
}
```

Another example of this is the string field processor, which simply extracts the string interpretation of the field value:

```
/**
 * Pass the string interpretation of the field directly to search API.
 */
public function processField(FieldItemList $field) {
  return $field->getString();
}
```

[More about plugins here](https://www.drupal.org/docs/drupal-apis/plugin-api/plugin-api-overview)

## Facets

Facets should use the Listing Filter Search API Facets {Index} source. The URL processor should be set to `Listing Filter Query string`.

When adding a facet use the `Listing Filter JSON` widget.

## Theme'ing

There is a template suggestion added of `paragraph--listings-filter.html.twig` for each of the paragraph types selected above, as well as bundle (`paragraph--listings-filter--{bundle}.html.twig`) and view mode (`paragraph--listings-filter--{bundle}--{view-mode}.html.twig`) variants.

This will most likely be a barebones template, something akin to:

```
<div data-js-views-listing data-js-listing-type="{{ listing_type }}" data-js-listing-title="{{ title }}" data-js-listing-title-id="{{ title_id }}-title">
  <div class="container">
    <h2 {{ create_attribute({ 'class': title_classes }) }} id="{{ title_id }}-title">
      {{ title }}
    </h2>
  </div>
</div>
```
