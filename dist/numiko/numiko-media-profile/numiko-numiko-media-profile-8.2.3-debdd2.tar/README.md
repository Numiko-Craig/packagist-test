# Numiko Media Distribution #

This is the standard Numiko Drupal 8 distribution including Media management (image & video) and paragraphs.

### What modules does this distribution contain? ###

This is a high-level view of the modules within, for a full list checkout the .info.yml file

* [Field Group](https://www.drupal.org/project/field_group)
* [Honey Pot](https://www.drupal.org/project/honeypot)
* [Media Entity](https://www.drupal.org/project/media_entity)
  * [Entity Browser](https://www.drupal.org/project/entity_browser)
* [Meta tag](https://www.drupal.org/project/metatag)
* [Paragraphs](https://www.drupal.org/project/paragraphs)
* [Password Policy](https://www.drupal.org/project/password_policy)
* [Pathauto](https://www.drupal.org/project/pathauto)
* [Url Redirect](https://www.drupal.org/project/redirect)
* [Linkit](https://www.drupal.org/project/linkit)
* [Focal Point](https://www.drupal.org/project/focal_point)

### Modules to add when they have a full (on packagist) Drupal 8 release ###

* [Environment Indicator](https://www.drupal.org/project/environment_indicator)

### How do I get set up? ###

Installation using this distribution will import all modules required, plus all configuration of those modules.

This distribution is included as part of the [Numiko Drupal Project installer](https://bitbucket.org/numiko/drupal-project) but can also be imported by cloning this repo or including it in your Drupal installation composer.json file.

```
composer require numiko/numiko-media-profile:~8.0
```
But you would need to specify the profile repository in your `composer.json` file
```
{
  "type": "vcs",
  "url": "git@bitbucket.org:numiko/numiko-media-profile.git"
}
```