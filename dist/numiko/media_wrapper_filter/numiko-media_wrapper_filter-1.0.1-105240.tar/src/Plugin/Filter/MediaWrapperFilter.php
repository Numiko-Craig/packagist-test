<?php

namespace Drupal\media_wrapper_filter\Plugin\Filter;

use Drupal\Component\Utility\Html;
use Drupal\filter\FilterProcessResult;
use Drupal\filter\Plugin\FilterBase;

/**
 * Provides a filter to copy classes from a media element to its container.
 *
 * @Filter(
 *   id = "media_wrapper",
 *   title = @Translation("Media Wrapper"),
 *   description = @Translation("Add media classes to a wrapper element."),
 *   type = Drupal\filter\Plugin\FilterInterface::TYPE_TRANSFORM_REVERSIBLE
 * )
 */
class MediaWrapperFilter extends FilterBase {

  /**
   * {@inheritdoc}
   */
  public function process($text, $langcode) {
    $result = new FilterProcessResult($text);

    if (stristr($text, 'data-media-wrapper') !== FALSE) {
      $dom = Html::load($text);
      $xpath = new \DOMXPath($dom);
      foreach ($xpath->query('//*[@data-media-wrapper]') as $node) {
        $descendant = $this->findDescendantWithMediaWrapperClass($node);
        if ($descendant) {
          // Append the media wrapper classes from the media data attribute.
          $classes = $node->getAttribute('class') . ' ' . $descendant->getAttribute('data-media-wrapper-class');
          $descendant->removeAttribute('data-media-wrapper-class');

          $node->setAttribute('class', $classes);
        }
        $node->removeAttribute('data-media-wrapper');
      }
      $result->setProcessedText(Html::serialize($dom));
    }

    return $result;
  }

  /**
   * Recursively search for a descendant of a DOM node with a certain class.
   */
  protected function findDescendantWithMediaWrapperClass(\DOMElement $node) {
    if ($node->hasChildNodes()) {
      foreach ($node->childNodes as $child) {
        if ($child instanceof \DOMElement) {
          if ($child->hasAttribute('data-media-wrapper-class')) {
            return $child;
          }
          else {
            return $this->findDescendantWithMediaWrapperClass($child);
          }
        }
      }
    }
    return NULL;
  }

}
