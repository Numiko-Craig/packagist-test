# Media Wrapper Filter

Currently the caption filter adds a separate wrapper template (`filter-caption.html.twig`) which contains the nested media element within it.

This gives correct markup in that it wraps the media div with a figure and appends a figcaption.

However it can cause some issues in styling, resulting in a fixed template that cannot be amended based on the media within.

```
<figure role="group"{%- if classes %} class="{{ classes }}"{%- endif %}>
  {{ node }}
  <figcaption>{{ caption }}</figcaption>
</figure>
```

Where `{{ node }}` is the media element within, quite often we could benefit from having more control over the classes on this figure element for variations in styling.

This requirement resulted in the [custom caption filter module](https://bitbucket.org/numiko/custom-caption-filter) unfortunately this was not compatible with the new version of core media and captions (which directly checked for the use of `filter_caption` in the core code).

## Usage

### Installation

In order to make use of this filter we need to enable it under the wysiwyg format (under text formats and editors).

This filter should be placed after the `Embed media` and `Display embedded entities` filters.

### Templates

Additionally this filter hooks on to two required data attributes.

1. The wrapper element inside `filter-caption.html.twig` must be identifiable to the filter with a data attribute (`data-media-wrapper`).

```
<figure role="group"{%- if classes %} class="{{ classes }}"{%- endif %} data-media-wrapper>
  {{ node }}
  <figcaption>{{ caption }}</figcaption>
</figure>
```

2. The media template then requires a data attribute identifying the classes to be added to the container (`data-media-wrapper-class`).

```
<div{{ attributes }} data-media-wrapper-class="figure-media-{{ media.bundle() }}">
  {{ title_suffix.contextual_links }}
  {{ content }}
</div>
```
