<?php

namespace Drupal\duration\Plugin\Field\FieldWidget;

use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Field\WidgetBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Plugin implementation of the 'duration_field_widget' widget.
 *
 * @FieldWidget(
 *   id = "duration_field_widget",
 *   label = @Translation("Duration"),
 *   field_types = {
 *     "integer"
 *   }
 * )
 */
class DurationFieldWidget extends WidgetBase {
  /**
   * {@inheritdoc}
   */
  public static function defaultSettings() {
    return array(
      'placeholder' => '',
    ) + parent::defaultSettings();
  }

  /**
   * {@inheritdoc}
   */
  public function settingsForm(array $form, FormStateInterface $form_state) {
    $elements = [];

    $elements['placeholder'] = array(
      '#type' => 'textfield',
      '#title' => t('Placeholder'),
      '#default_value' => $this->getSetting('placeholder'),
      '#description' => t('Text that will be shown inside the field until a value is entered. This hint is usually a sample value or a brief description of the expected format.'),
    );

    return $elements;
  }

  /**
   * {@inheritdoc}
   */
  public function settingsSummary() {
    $summary = [];

    $placeholder = $this->getSetting('placeholder');
    if (!empty($placeholder)) {
      $summary[] = t('Placeholder: @placeholder', array('@placeholder' => $placeholder));
    }
    else {
      $summary[] = t('No placeholder');
    }

    return $summary;
  }

  /**
   * {@inheritdoc}
   */
  public function formElement(FieldItemListInterface $items, $delta, array $element, array &$form, FormStateInterface $form_state) {

    $element['mins'] = array(
      '#type' => 'number',
      '#title' => 'Minutes',
      '#default_value' => isset($items[$delta]->value) ? floor($items[$delta]->value / 60) : NULL,
    );
    $element['secs'] = array(
      '#type' => 'number',
      '#title' => 'Seconds',
      '#max' => 60,
      '#default_value' => isset($items[$delta]->value) ? $items[$delta]->value % 60 : NULL,
    );

    if ($this->fieldDefinition->getFieldStorageDefinition()->getCardinality() == 1) {
      $element += array(
        '#type' => 'fieldset',
        '#title' => $element['#title'],
        '#attributes' => array('class' => array('container-inline')),
      );
    }

    return $element;
  }

  public function massageFormValues(array $values, array $form, FormStateInterface $form_state) {

    foreach ($values as $delta => &$value) {
      $seconds = ($value['mins']) ? $value['mins'] * 60 : 0;
      $seconds += ($value['secs']) ? $value['secs'] : 0;
      $value['value'] = $seconds;
    }

    return $values;
  }

}
