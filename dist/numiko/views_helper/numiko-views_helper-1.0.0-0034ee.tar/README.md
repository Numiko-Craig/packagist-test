# Views Helper

Provides a views help page, which shows all views with exposed filters.

This help page also includes a list of taxonomy terms and their ID's, useful for including a link with filters preselected.

## Usage

This new help page is accessible from the help system, or by going direct to: /admin/help/views_helper