# Slice Type Condition

Condition plugin for slice types.

## Description

Manage display of blocks depending on whether slice type(s) appears on the current page.