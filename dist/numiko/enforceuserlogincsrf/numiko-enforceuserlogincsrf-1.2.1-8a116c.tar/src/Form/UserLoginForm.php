<?php

namespace Drupal\enforceuserlogincsrf\Form;

use Drupal\Core\Flood\FloodInterface;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Render\RendererInterface;
use Drupal\user\UserAuthInterface;
use Drupal\user\UserStorageInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\user\Form\UserLoginForm as DefaultUserLoginForm;

use Drupal\Component\Utility\Html;
use Drupal\Component\Utility\Crypt;

/**
 * Provides a user login form.
 */
class UserLoginForm extends DefaultUserLoginForm {

    use UserTraitForm;

}
