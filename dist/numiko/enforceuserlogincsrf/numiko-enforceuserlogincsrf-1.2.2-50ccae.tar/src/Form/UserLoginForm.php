<?php

namespace Drupal\enforceuserlogincsrf\Form;

/**
 * Provides a user login form.
 */
class UserLoginForm extends DefaultUserLoginForm {

    use UserTraitForm;

}
