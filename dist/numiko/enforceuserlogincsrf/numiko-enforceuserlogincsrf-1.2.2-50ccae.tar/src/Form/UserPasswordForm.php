<?php

namespace Drupal\enforceuserlogincsrf\Form;

/**
 * Provides a user login form.
 */
class UserPasswordForm extends DefaultUserPasswordForm {

  use UserTraitForm;

}
