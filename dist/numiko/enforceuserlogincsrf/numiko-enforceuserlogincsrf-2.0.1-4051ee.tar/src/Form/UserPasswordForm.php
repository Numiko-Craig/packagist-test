<?php

namespace Drupal\enforceuserlogincsrf\Form;

use Drupal\user\Form\UserPasswordForm as DefaultUserPasswordForm;

/**
 * Provides a user login form.
 */
class UserPasswordForm extends DefaultUserPasswordForm {

  use UserTraitForm;

}
