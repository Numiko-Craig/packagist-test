# Domain Access Blocking

For use with the Domain module.

Blocks authenticated users from a Domain if they don't have access to edit content on that domain.

Intended for sites where CMS users will be the only ones logging in.

Strange caching-related problems can appear when users log into a site where they are not allowed 
to edit content e.g. the /admin/content page will be missing add and edit links and this will get
cached, but because the user is allowed to edit content on other domains, they are allowed to see 
that page.

It is very difficult to add cache contexts that would prevent this so it's best to prevent users 
from accessing the site altogether.

## Tests

Please run the tests and keep them up to date.