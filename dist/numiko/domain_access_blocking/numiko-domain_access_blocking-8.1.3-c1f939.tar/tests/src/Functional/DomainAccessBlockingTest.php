<?php

namespace Drupal\Tests\domain_access_blocking\Functional;

use Drupal\Core\Url;
use Drupal\domain\DomainInterface;
use Drupal\Tests\domain\Functional\DomainTestBase;

/**
 * Test ability of users to log in to only domain they are assigned to.
 *
 * In order to log in using built-in Domain module code ($this->domainLogin()),
 * this class needs to inherit from the Simpletest version of DomainTestsBase.
 *
 * @group DomainAccessBlocking
 */
class DomainAccessBlockingTest extends DomainTestBase {

  public static $modules = array('domain_access', 'node', 'domain_access_blocking');

  private $testDomains = [];

  protected function setUp() {
    parent::setUp();
    $this->domainCreateTestDomains(3, getenv('SIMPLETEST_BASE_DOMAIN_SUFFIX'), [
      '', // always the "base" domain
      getenv('SIMPLETEST_BASE_MSI_URL_FRAG'),
      getenv('SIMPLETEST_BASE_SCI_URL_FRAG'),
    ]);
    $testDomains = \Drupal::service('domain.loader')->loadMultiple();
    // Store the 2 Domains
    foreach ($testDomains as $domain) {
      if ($domain->getHostname() != getenv('SIMPLETEST_BASE_DOMAIN_SUFFIX')) {
        $this->testDomains[] = $domain;
      }
    }
  }

  protected function domainGet(DomainInterface $domain, $path) {
    $url = 'https://';
    foreach ($this->testDomains as $testDomain) {
      if ($testDomain->id() == $domain->id()) {
        $url .= $domain->getHostname();
      }
    }
    $url .= '/' . $path;
    return $this->drupalGet($url);
  }

  public function testCorrectDomainUser() {
    $domain_user1 = $this->drupalCreateUser([
      // only so that we can test browsing to somewhere useful once logged in
      'access content overview'
    ]);
    $this->addDomainsToEntity(
      'user',
      $domain_user1->id(),
      [$this->testDomains[0]->id()],
      DOMAIN_ACCESS_FIELD
    );
    $this->assertTrue($this->domainLogin($this->testDomains[0], $domain_user1));
    $this->assertSession()->statusCodeEquals(200);
    $this->domainGet($this->testDomains[0], 'admin/content');
    $this->assertSession()->statusCodeEquals(200);
  }

  public function testUserWithNoDomain() {
    // Test that user is blocked from domains they are not assigned to
    $no_domain_user = $this->drupalCreateUser([
      'access content overview'
    ]);
    $this->assertTrue($this->domainLogin($this->testDomains[0], $no_domain_user));
    $this->assertSession()->statusCodeEquals(403);
    $this->domainGet($this->testDomains[0], 'admin/content');
    $this->assertSession()->statusCodeEquals(403);
    $this->assertTrue($this->domainLogin($this->testDomains[1], $no_domain_user));
    $this->assertSession()->statusCodeEquals(403);
    $this->domainGet($this->testDomains[1], 'admin/content');
    $this->assertSession()->statusCodeEquals(403);
  }

  public function testUserWithWrongDomain() {
    $other_domain_user = $this->drupalCreateUser([
      'access content overview'
    ]);
    $this->addDomainsToEntity(
      'user',
      $other_domain_user->id(),
      [$this->testDomains[0]->id()],
      DOMAIN_ACCESS_FIELD
    );
    $this->assertTrue($this->domainLogin($this->testDomains[1], $other_domain_user));
    $this->assertSession()->statusCodeEquals(403);
    $this->domainGet($this->testDomains[1], '/admin/content');
    $this->assertSession()->statusCodeEquals(403);
  }

}
