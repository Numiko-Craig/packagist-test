<?php

namespace Drupal\token_entity_reference\Plugin\Field\FieldWidget;

use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\views\Views;
use Drupal\link\Plugin\Field\FieldWidget\LinkWidget;

/**
 * Plugin implementation of the 'link' widget including tokens.
 *
 * @FieldWidget(
 *   id = "token_link_default",
 *   label = @Translation("Token Link"),
 *   field_types = {
 *     "link"
 *   }
 * )
 */
class TokenLinkWidget extends LinkWidget {

  /**
   * {@inheritdoc}
   */
  public static function defaultSettings() {
    return [
      'token_pattern' => '',
      'view_display' => '',
      'view_args' => '',
    ] + parent::defaultSettings();
  }

  /**
   * {@inheritdoc}
   */
  public function formElement(FieldItemListInterface $items, $delta, array $element, array &$form, FormStateInterface $form_state) {
    $element = parent::formElement($items, $delta, $element, $form, $form_state);

    if ($this->supportsInternalLinks()) {
      list($view_id, $display_id) = explode(':', $this->getSetting('view_display'));

      $element['uri']['#selection_handler'] = 'token_entity_reference_select';
      $element['uri']['#selection_settings']['view'] = [
        'view_name' => $view_id,
        'display_name' => $display_id,
      ];
      $element['uri']['#selection_settings']['token'] = [
        'pattern' => ($this->getSetting('token_pattern')) ? $this->getSetting('token_pattern') : '[node:title]',
      ];
    }

    return $element;
  }

  /**
   * {@inheritdoc}
   */
  public function settingsForm(array $form, FormStateInterface $form_state) {
    $elements = parent::settingsForm($form, $form_state);

    $displays = Views::getApplicableViews('entity_reference_display');
    // Filter views that list the entity type we want, and group the separate
    // displays by view.
    $entity_type = \Drupal::entityTypeManager()->getDefinition('node');
    $view_storage = \Drupal::entityTypeManager()->getStorage('view');

    $options = [];
    foreach ($displays as $data) {
      list($view_id, $display_id) = $data;
      $view = $view_storage->load($view_id);
      if (in_array($view->get('base_table'), [$entity_type->getBaseTable(), $entity_type->getDataTable()])) {
        $display = $view->get('display');
        $options[$view_id . ':' . $display_id] = $view_id . ' - ' . $display[$display_id]['display_title'];
      }
    }

    if ($options) {
      $elements['view_display'] = [
        '#type' => 'select',
        '#title' => $this->t('View used to select the entities'),
        '#required' => TRUE,
        '#options' => $options,
        '#default_value' => $this->getSetting('view_display'),
        '#description' => '<p>' . $this->t('Choose the view and display that select the entities that can be referenced.<br />Only views with a display of type "Entity Reference" are eligible.') . '</p>',
      ];

      $elements['view_args'] = [
        '#type' => 'textfield',
        '#title' => $this->t('View arguments'),
        '#default_value' => $this->getSetting('view_args'),
        '#required' => FALSE,
        '#description' => $this->t('Provide a comma separated list of arguments to pass to the view.'),
      ];
    }

    $elements['token_pattern'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Display label'),
      '#default_value' => $this->getSetting('token_pattern'),
      '#required' => FALSE,
      '#description' => $this->t('Provide a display label to show may include tokens.'),
      '#element_validate' => array('token_element_validate'),
      '#after_build' => array('token_element_validate'),
    ];
    $elements['token_help'] = array(
      '#theme' => 'token_tree_link',
      '#token_types' => ['node'],
    );

    return $elements;
  }

  /**
   * {@inheritdoc}
   */
  public function settingsSummary() {
    $summary = [];

    $token_pattern = $this->getSetting('token_pattern');
    $view_display = $this->getSetting('view_display');
    if (empty($token_pattern) && empty($view_display)) {
      $summary[] = $this->t('No view / pattern');
    }
    else {
      if (!empty($view_display)) {
        $summary[] = $this->t('View display: @view_display', ['@view_display' => $view_display]);
      }
      if (!empty($token_pattern)) {
        $summary[] = $this->t('Token to display: @token_pattern', ['@token_pattern' => $token_pattern]);
      }
    }

    return $summary;
  }

}
