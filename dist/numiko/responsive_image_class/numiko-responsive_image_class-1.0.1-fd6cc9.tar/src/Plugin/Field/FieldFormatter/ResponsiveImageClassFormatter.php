<?php

namespace Drupal\responsive_image_class\Plugin\Field\FieldFormatter;

use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\responsive_image\Plugin\Field\FieldFormatter\ResponsiveImageFormatter;

/**
 * Plugin for responsive image formatter.
 *
 * @FieldFormatter(
 *   id = "responsive_image_class",
 *   label = @Translation("Responsive image class"),
 *   field_types = {
 *     "image",
 *   },
 *   quickedit = {
 *     "editor" = "image"
 *   }
 * )
 */
class ResponsiveImageClassFormatter extends ResponsiveImageFormatter {

  /**
   * {@inheritdoc}
   */
  public static function defaultSettings() {
    return [
      'image_classes' => '',
    ] + parent::defaultSettings();
  }

  /**
   * {@inheritdoc}
   */
  public function settingsForm(array $form, FormStateInterface $form_state) {
    $elements = parent::settingsForm($form, $form_state);

    $elements['image_classes'] = [
      '#title' => t('Image classes'),
      '#type' => 'textfield',
      '#default_value' => $this->getSetting('image_classes') ?: '',
      '#description' => 'One or more space seperated classes to add to the image',
    ];

    return $elements;
  }

  /**
   * {@inheritdoc}
   */
  public function settingsSummary() {
    $summary = parent::settingsSummary();

    if ($this->getSetting('image_classes')) {
      $summary[] = t('Image classes: @image_classes', ['@image_classes' => $this->getSetting('image_classes')]);
    }

    return $summary;
  }

  /**
   * {@inheritdoc}
   */
  public function viewElements(FieldItemListInterface $items, $langcode) {
    $elements = parent::viewElements($items, $langcode);
    if ($this->getSetting('image_classes')) {
      foreach ($elements as &$element) {
        $element['#item_attributes']['class'][] = $this->getSetting('image_classes');
      }
    }
    return $elements;
  }

}
