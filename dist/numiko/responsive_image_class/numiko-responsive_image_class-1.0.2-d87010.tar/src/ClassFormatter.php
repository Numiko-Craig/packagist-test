<?php

namespace Drupal\responsive_image_class;

/**
 * Class ClassFormatter
 *
 * @package Drupal\responsive_image_class
 */
class ClassFormatter {

  /**
   * @param $element
   *
   * @return array
   */
  public function classStringToArray($element, $imageClassSettings) {
    // Handle multiple classes separated by a space.
    $classes = explode(' ', $imageClassSettings);
    // Remove any empty array values, then reset their index.
    $classes = array_values(array_filter($classes));
    if (isset($element['#item_attributes']['class'])) {
      $element['#item_attributes']['class'] = array_merge($element['#item_attributes']['class'], $classes);
    }
    else {
      $element['#item_attributes']['class'] = $classes;
    }
    return $element;
  }

}
