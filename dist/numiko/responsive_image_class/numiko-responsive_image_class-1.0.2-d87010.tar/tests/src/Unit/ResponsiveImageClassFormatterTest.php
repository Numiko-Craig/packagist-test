<?php

namespace Drupal\Tests\tct_tests\Unit;

use Drupal\Core\DependencyInjection\ContainerBuilder;
use Drupal\responsive_image_class\ClassFormatter;
use Drupal\Tests\UnitTestCase;

/**
 * Unit tests to ensure ResponsiveImageClassFormatter formats classes correctly.
 *
 * @group responsive_image_class
 * @group image_formatter
 */
class ResponsiveImageClassFormatterTest extends UnitTestCase {

  protected $emptyElement;
  protected $populatedElement;
  protected $singleClass;
  protected $manyClasses;
  protected $singleClassWithExtraWhitespace;
  protected $manyClassesWithExtraWhitespace;
  protected $expectedResultEmptyElementSingleClass;
  protected $expectedResultPopulatedElementSingleClass;
  protected $expectedResultEmptyElementManyClasses;
  protected $expectedResultPopulatedElementManyClasses;
  protected $classFormatterService;

  public function setUp(): void {
    parent::setUp();
    $this->classFormatterService = new ClassFormatter();

    $this->emptyElement = [];
    $this->populatedElement = [
      '#item_attributes' => [
        'class' => [
          'prepopulated-class-a',
          'prepopulated-class-b',
        ]
      ]
    ];
    $this->singleClass = 'class-a';
    $this->manyClasses = 'class-a class-b class-c';
    $this->singleClassWithExtraWhitespace = '   class-a ';
    $this->manyClassesWithExtraWhitespace = ' class-a class-b   class-c  ';
    $this->expectedResultEmptyElementSingleClass = [
      '#item_attributes' => [
        'class' => ['class-a']
      ]
    ];
    $this->expectedResultPopulatedElementSingleClass = [
      '#item_attributes' => [
        'class' => [
          'prepopulated-class-a',
          'prepopulated-class-b',
          'class-a',
        ]
      ]
    ];
    $this->expectedResultEmptyElementManyClasses = [
      '#item_attributes' => [
        'class' => [
          'class-a',
          'class-b',
          'class-c',
        ]
      ]
    ];
    $this->expectedResultPopulatedElementManyClasses = [
      '#item_attributes' => [
        'class' => [
          'prepopulated-class-a',
          'prepopulated-class-b',
          'class-a',
          'class-b',
          'class-c',
        ]
      ]
    ];
  }

  /**
   * Test that single classes, with and without extra whitespace, are added correctly.
   *
   * @covers Drupal\responsive_image_class\ClassFormatter::classStringToArray
   */
  public function testSingleClassAddedToImageCorrectly() {
    $this->assertEquals(
      $this->expectedResultEmptyElementSingleClass,
      $this->classFormatterService->classStringToArray($this->emptyElement, $this->singleClass),
      'Unexpected result when adding a single class to an image element with no classes.'
    );

    $this->assertEquals(
      $this->expectedResultPopulatedElementSingleClass,
      $this->classFormatterService->classStringToArray($this->populatedElement, $this->singleClass),
      'Unexpected result when adding a single class to an image element with classes.'
    );

    $this->assertEquals(
      $this->expectedResultEmptyElementSingleClass,
      $this->classFormatterService->classStringToArray($this->emptyElement, $this->singleClassWithExtraWhitespace),
      'Unexpected result when adding a single class with extra whitespace to an image element with no classes.'
    );

    $this->assertEquals(
      $this->expectedResultPopulatedElementSingleClass,
      $this->classFormatterService->classStringToArray($this->populatedElement, $this->singleClassWithExtraWhitespace),
      'Unexpected result when adding a single class with extra whitespace to an image element with classes.'
    );
  }

  /**
   * Test that many classes, with and without extra whitespace, are added correctly.
   *
   * @covers Drupal\responsive_image_class\ClassFormatter::classStringToArray
   */
  public function testManyClassesAddedToImageCorrectly() {
    $this->assertEquals(
      $this->expectedResultEmptyElementManyClasses,
      $this->classFormatterService->classStringToArray($this->emptyElement, $this->manyClasses),
      'Unexpected result when adding many classes to an image element with no classes.'
    );

    $this->assertEquals(
      $this->expectedResultPopulatedElementManyClasses,
      $this->classFormatterService->classStringToArray($this->populatedElement, $this->manyClasses),
      'Unexpected result when adding many classes to an image element with classes.'
    );

    $this->assertEquals(
      $this->expectedResultEmptyElementManyClasses,
      $this->classFormatterService->classStringToArray($this->emptyElement, $this->manyClassesWithExtraWhitespace),
      'Unexpected result when adding many classes with extra whitespace to an image element with no classes.'
    );

    $this->assertEquals(
      $this->expectedResultPopulatedElementManyClasses,
      $this->classFormatterService->classStringToArray($this->populatedElement, $this->manyClassesWithExtraWhitespace),
      'Unexpected result when adding many classes with extra whitespace to an image element with classes.'
    );
  }
}
