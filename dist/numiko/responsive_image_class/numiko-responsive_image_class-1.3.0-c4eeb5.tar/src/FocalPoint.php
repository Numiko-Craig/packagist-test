<?php

namespace Drupal\responsive_image_class;

use Drupal\focal_point\FocalPointManager;

/**
 * Calculate the focal point for a given image by uri.
 */
class FocalPoint {

  const DEFAULT_POSITION = 'center center';

  private $focalPointManager;

  /**
   * Set meta tag manager.
   *
   * @param \Drupal\focal_point\FocalPointManager $focalPointManager
   *   Focal point manager.
   */
  public function setFocalPointManager(FocalPointManager $focalPointManager) {
    $this->focalPointManager = $focalPointManager;
  }

  /**
   * Get the focal position for a given file entity.
   */
  public function getFocalPosition($file, $width, $height) {
    if ($file && $this->focalPointManager) {
      /** @var \Drupal\crop\Entity\Crop $crop */
      $crop = $this->focalPointManager->getCropEntity($file, 'focal_point');
      if ($crop) {
        $xPosition = 'center';
        $yPosition = 'center';
        $xPercentage = ($width - $crop->get('x')->value) / $width * 100;
        $yPercentage = ($height - $crop->get('y')->value) / $height * 100;
        // Get the X position.
        if ($xPercentage <= 33) {
          $xPosition = 'right';
        }
        elseif ($xPercentage >= 66) {
          $xPosition = 'left';
        }
        // Get the Y position.
        if ($yPercentage <= 33) {
          $yPosition = 'bottom';
        }
        elseif ($yPercentage >= 66) {
          $yPosition = 'top';
        }
        return $yPosition . ' ' . $xPosition;
      }
    }
    return self::DEFAULT_POSITION;
  }

}
