# Responsive Image Class Formatter

A field formatter for `image` field types, to allow classes to be added to the image via the field formatter configuration.

Useful for utility based styling where images require additional classes for layout.

Optionally this formatter can also be used to:

 * prevent alt attribute output for use with decorative images
 * add focal point data to data attributes for use on the front-end
