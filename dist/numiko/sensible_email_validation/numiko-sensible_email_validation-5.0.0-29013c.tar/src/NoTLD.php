<?php

namespace Drupal\sensible_email_validation;

use Egulias\EmailValidator\Result\Reason\Reason;

class NoTLD implements Reason {

  const CODE = 222;
  const REASON = "No top-level domain";

  /**
   * {@inheritDoc}
   */
  public function code(): int {
    return self::CODE;
  }

  /**
   * {@inheritDoc}
   */
  public function description(): string {
    return self::REASON;
  }

}
