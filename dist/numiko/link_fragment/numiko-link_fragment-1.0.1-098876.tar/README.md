Link Fragment

Adds a 'Fragment' field to the link dialog for appending a fragment to the URL.

e.g. /node/12#summary

This also works with linkit inserted links.

In order to work in both situations it uses a format filter, 
with the fragment field storing itself as a 'data-fragment' attribute,
which is then picked up by the LinkFragmentFilter and appended to the href attribute.

In order for this to work correctly it must run after any processors which are being used to
create the href attribute i.e. LinkitFilter.
