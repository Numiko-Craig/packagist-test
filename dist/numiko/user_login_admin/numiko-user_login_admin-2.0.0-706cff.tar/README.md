# User Login Admin

Switch user login and password reset routes to use the admin theme.

## Usage

In order to use this module the anonymous user must have permission to use the admin theme otherwise it has no way of working.
