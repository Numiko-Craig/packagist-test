# Entity Embed CKeditor #

This module allows an overriding view mode to be used when embedding entities within ckeditor.

## Installation

To use this filter with a text format:

* Go to /admin/config/content/formats/
* Select the format to use the specific entity view mode override
* Select 'Display embedded entities using a ckeditor view mode'
* Go to the 'Filter Settings' and select the entities you wish to override.