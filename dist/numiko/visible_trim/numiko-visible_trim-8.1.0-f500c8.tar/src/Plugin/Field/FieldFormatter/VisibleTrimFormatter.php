<?php

namespace Drupal\visible_trim\Plugin\Field\FieldFormatter;

use Drupal\Core\Field\FormatterBase;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Link;
use Drupal\Component\Utility\Unicode;
use Drupal\smart_trim\Plugin\Field\FieldFormatter\SmartTrimFormatter;
use Drupal\visible_trim\Truncate\TruncateVisible;

/**
 * Plugin implementation of the 'visible_trim' formatter.
 *
 * @FieldFormatter(
 *   id = "plain_visible_trim",
 *   label = @Translation("Plain Visible Trim"),
 *   field_types = {
 *     "string",
 *     "string_long"
 *   },
 *   settings = {
 *     "trim_length" = "40",
 *     "trim_type" = "words",
 *     "trim_options" = ""
 *   }
 * )
 */
class VisibleTrimFormatter extends SmartTrimFormatter {

  /**
   * {@inheritdoc}
   */
  public static function defaultSettings() {
    return array(
      'trim_length' => '40',
      'trim_type' => 'words',
    ) + parent::defaultSettings();
  }

  /**
   * {@inheritdoc}
   */
  public function settingsForm(array $form, FormStateInterface $form_state) {
    $element = parent::settingsForm($form, $form_state);

    return $element;
  }

  /**
   * {@inheritdoc}
   */
  public function viewElements(FieldItemListInterface $items, $langcode = NULL) {
    $element = array();
    $setting_trim_options = $this->getSetting('trim_options');

    foreach ($items as $delta => $item) {
      $output = $item->value;
     
      $truncate = new TruncateVisible();
      $length = $this->getSetting('trim_length');
      if ($this->getSetting('trim_type') == 'words') {
        $output = $truncate->truncateWords($output, $length);
      }
      else {
        $output = $truncate->truncateChars($output, $length);
      }

      $element[$delta] = array('#markup' => $output);
    }
    return $element;
  }

}