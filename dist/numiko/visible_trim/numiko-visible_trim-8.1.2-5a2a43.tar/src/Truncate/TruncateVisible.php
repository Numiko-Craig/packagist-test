<?php

/**
 * @file
 * Contains visible trim functionality.
 */

namespace Drupal\visible_trim\Truncate;

use Drupal\Component\Utility\Html;
use Drupal\Component\Utility\Unicode;

/**
 * Class TruncateVisible.
 */
class TruncateVisible {

  /**
   * Truncates string text by characters.
   *
   * @param string $text
   *   Text to be updated.
   * @param int $limit
   *   Amount of text to allow.
   * @param string $ellipsis
   *   Characters to use at the end of the text.
   *
   * @return mixed
   *   Resulting text.
   */
  public function truncateChars($text, $limit, $ellipsis = '...') {
    if ($limit <= 0 || $limit >= strlen(strip_tags($text))) {
      return $text;
    }
    
    return "<span class='o-visible-text'>" . substr_replace($text, "</span>&nbsp;<span class='o-hidden-text'>", $limit, 1) . "</span>";
  }

  /**
   * Truncates string text by words.
   *
   * @param string $html
   *   Text to be updated.
   * @param int $limit
   *   Amount of text to allow.
   * @param string $ellipsis
   *   Characters to use at the end of the text.
   *
   * @return mixed
   *   Resulting text.
   */
  public function truncateWords($text, $limit, $ellipsis = '...') {
    if ($limit <= 0 || $limit >= $this->countWords(strip_tags($text))) {
      return $text;
    }

    $words = preg_split("/[\n\r\t ]+/", $text, $limit + 1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_OFFSET_CAPTURE);
    end($words);
    $last_word = prev($words);
    return "<span class='o-visible-text'>" . substr_replace($text, "</span>&nbsp;<span class='o-hidden-text'>", $last_word[1] + strlen($last_word[0]), 1) . "</span>";
  }

  /**
   * Gets number of words in text.
   *
   * @param string $text
   *   Text to be counted.
   *
   * @return int
   *   Results
   */
  protected function countWords($text) {
    $words = preg_split("/[\n\r\t ]+/", $text, -1, PREG_SPLIT_NO_EMPTY);
    return count($words);
  }

}