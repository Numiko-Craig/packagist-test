# Fastly File Purge

Purges a file from Fastly when it is updated or deleted. This prevents stale files being
served to the user.
