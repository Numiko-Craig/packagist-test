<?php

namespace Drupal\yamlform2text\Plugin\YamlFormHandler;

use Drupal\yamlform\Plugin\YamlFormHandler\RemotePostYamlFormHandler;
use Drupal\Core\Form\FormStateInterface;
use Drupal\yamlform\YamlFormSubmissionInterface;
use GuzzleHttp\Exception\RequestException;

/**
 * Form submission remote post handler.
 *
 * @YamlFormHandler(
 *   id = "form2text_post",
 *   label = @Translation("Form2Text post"),
 *   category = @Translation("External"),
 *   description = @Translation("Posts form submissions to the Form2Text endpoint."),
 *   cardinality = \Drupal\yamlform\YamlFormHandlerInterface::CARDINALITY_UNLIMITED,
 *   results = \Drupal\yamlform\YamlFormHandlerInterface::RESULTS_PROCESSED,
 * )
 */
class Form2TextYamlFormHandler extends RemotePostYamlFormHandler{

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $form, FormStateInterface $form_state) {
    $form = parent::buildConfigurationForm($form, $form_state);

    unset($form['type']);

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function preSave(YamlFormSubmissionInterface $yamlform_submission) {}

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state, YamlFormSubmissionInterface $yamlform_submission) {
    $operation = ($yamlform_submission->getState() == YamlFormSubmissionInterface::STATE_UPDATED) ? 'update' : 'insert';
    $this->endpointPost($operation, $yamlform_submission, $form_state);
    parent::submitForm($form, $form_state, $yamlform_submission);
  }

  /**
   * Execute a remote post.
   *
   * @param string $operation
   *   The type of form submission operation to be posted. Can be 'insert',
   *   'update', or 'delete'.
   * @param \Drupal\yamlform\YamlFormSubmissionInterface $yamlform_submission
   *   The form submission to be posted.
   */
  protected function endpointPost($operation, YamlFormSubmissionInterface $yamlform_submission, FormStateInterface $form_state) {
    $request_url = $this->configuration[$operation . '_url'];
    if (empty($request_url)) {
      return;
    }

    $request_type = $this->configuration['type'];
    $request_post_data = $this->getPostData($yamlform_submission);

    $request_post_data = \Drupal::service('yamlform2text.mapper')->map($request_post_data, $yamlform_submission);

    try {
      switch ($request_type) {
        case 'json':
          $response = $this->httpClient->post($request_url, ['json' => $request_post_data]);
          break;

        case 'x-www-form-urlencoded':
        default:
          $response = $this->httpClient->post($request_url, ['form_params' => $request_post_data]);
          break;
      }
    }
    catch (RequestException $request_exception) {
      $message = $request_exception->getMessage();
      $response = $request_exception->getResponse();

      // If debugging is enabled, display the error message on screen.
      $this->debug($message, $operation, $request_url, $request_type, $request_post_data, $response, 'error');

      // Log error message.
      $context = [
        '@form' => $this->getYamlForm()->label(),
        '@operation' => $operation,
        '@type' => $request_type,
        '@url' => $request_url,
        '@message' => $message,
        'link' => $this->getYamlForm()->toLink(t('Edit'), 'handlers-form')->toString(),
      ];
      $this->logger->error('@form form remote @type post (@operation) to @url failed. @message', $context);

      drupal_set_message(t('An error has occurred processing this form, please check all fields and retry the submission'), 'error');
      $form_state->setRebuild();
    }

    // If debugging is enabled, display the request and response.
    $this->debug(t('Remote post successful!'), $operation, $request_url, $request_type, $request_post_data, $response, 'warning');
  }

}
