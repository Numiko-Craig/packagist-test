<?php

namespace Drupal\webform_ajax\Controller;

use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\RemoveCommand;
use Drupal\Core\Ajax\PrependCommand;
use Drupal\Core\Ajax\AppendCommand;
use Drupal\Core\Ajax\ReplaceCommand;
use Drupal\Core\Ajax\InvokeCommand;
use Drupal\Core\Form\FormStateInterface;
use Drupal\webform_ajax\Exception\WebformAjaxException;
use Drupal\webform_ajax\Ajax\ScrollToCommand;

/**
 * Defines a controller to load a view via AJAX.
 */
class WebformAjaxController {

  /**
   * Submits webform request via AJAX.
   *
   * @return \Drupal\webform_ajax\Ajax\WebformAjaxResponse
   *   The view response as ajax response.
   */
  public function ajaxSubmission(array $form, FormStateInterface $formState) {
    try {
      $response = new AjaxResponse();
      $wrapper = '#' . $formState->getBuildInfo()['form_id'] . '_wrapper';
      $response->addCommand(new RemoveCommand("{$wrapper} .js-webform-error-list"));
      $response->addCommand(new InvokeCommand("{$wrapper} .js-webform-error-item", "removeClass", ["js-webform-error-item"]));
      $response->addCommand(new ReplaceCommand("{$wrapper}", \Drupal::Service('ajax.webform')->submit($form, $formState)->getRenderableMessage()));
      $response->addCommand(new ScrollToCommand("{$wrapper}"));
      \Drupal::moduleHandler()->alter('webform_ajax_response', $response, $formState);
    }
    catch (WebformAjaxException $e) {
      $response->addCommand(new RemoveCommand("{$wrapper} .js-webform-messages"));
      $response->addCommand(new PrependCommand($wrapper, $e->getRenderableMessage()));
      $firstError = true;
      foreach ($formState->getErrors() as $elementName => $error) {
        $itemWrapper = '.js-form-item-' . preg_replace('/[^a-zA-Z0-9]+/', '-', $elementName);
        $fieldError = ['#theme' => 'webform_ajax_field_error', '#error' => ['#markup' => $error]];
        $response->addCommand(new AppendCommand("{$wrapper} {$itemWrapper}", $fieldError));
        $response->addCommand(new InvokeCommand("{$wrapper} {$itemWrapper} input", "addClass", ["js-webform-error-item"]));
        if ($firstError) {
          $response->addCommand(new ScrollToCommand("{$wrapper} {$itemWrapper}"));
          $firstError = false;
        }
      }
      // Clear the messages as we are sending back errors in the ajax response.
      drupal_get_messages();
    }

    return $response;
  }

}
