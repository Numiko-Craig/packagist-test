/**
 * @file
 * Handles AJAX scrolling of webforms.
 */

(function ($, Drupal, drupalSettings) {

  'use strict';

  /**
   * Views scroll to top ajax command.
   *
   * @param {Drupal.Ajax} [ajax]
   *   A {@link Drupal.ajax} object.
   * @param {object} response
   *   Ajax response.
   * @param {string} response.selector
   *   Selector to use.
   */
  Drupal.AjaxCommands.prototype.webformScrollTo = function (ajax, response) {
    var offset = $(response.selector).offset();
    var scrollTarget = response.selector;
    // Add an offset adjust to provide context
    var offsetAdjust = 40;
    // Add the height of any fixed elements
    if ($('.is-fixed').length) {
      offsetAdjust += $('.is-fixed').outerHeight();
    }
    while ($(scrollTarget).scrollTop() === 0 && $(scrollTarget).parent()) {
      scrollTarget = $(scrollTarget).parent();
    }
    // Only scroll upward.
    if (offset.top - offsetAdjust < $(scrollTarget).scrollTop()) {
      $(scrollTarget).animate({scrollTop: (offset.top - offsetAdjust)}, 500);
    }
  };

})(jQuery, Drupal, drupalSettings);
