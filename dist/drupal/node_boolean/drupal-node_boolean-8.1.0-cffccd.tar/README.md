# Node Boolean Condition #

This module is a simple plugin to enable boolean fields on a node to be used as a condition to determine whether a block should be visible.

This module could easily be modified to work with other field types for a similar purpose.