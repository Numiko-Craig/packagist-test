<?php

namespace Drupal\structured_data\Plugin\StructuredDataType;

use Drupal\structured_data\StructuredDataTypeBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Provides a 'site name' structured data type.
 *
 * @StructuredDataType(
 *   id = "site_name",
 *   name = @Translation("Site Name"),
 *   type = "WebSite"
 * )
 */
class SiteName extends StructuredDataTypeBase {
  
  public function getData() {
    return parent::getData() + $this->getSiteData();
  }

  protected function getSiteData() {
    $config = \Drupal::config('structured_data.settings');
    return [
      'url' => $config->get('site_name.url') ? $this->tokenizeString($config->get('site_name.url')) : \Drupal::request()->getSchemeAndHttpHost(),
      'name' => $config->get('site_name.name') ? $this->tokenizeString($config->get('site_name.name')) : \Drupal::config('system.site')->get('name'),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $form, FormStateInterface $form_state, $config) {
    $build['site_name__name'] = [
      '#title' => t('Site name'),
      '#type' => 'textfield',
      '#default_value' => !is_null($config->get('site_name.name')) ? $config->get('site_name.name') : $this->defaultConfiguration()['name'],
      '#description' => t("The string to be used for the site name (this can include tokens)"),
      '#element_validate' => array('token_element_validate'),
      '#after_build' => array('token_element_validate'),
    ];

    $build['site_name__url'] = [
      '#title' => t('Site url'),
      '#type' => 'textfield',
      '#default_value' => !is_null($config->get('site_name.url')) ? $config->get('site_name.url') : $this->defaultConfiguration()['url'],
      '#description' => t("The string to be used for the site url (this can include tokens)"),
      '#element_validate' => array('token_element_validate'),
      '#after_build' => array('token_element_validate'),
    ];

    $build['site_name__token_help'] = array(
      '#theme' => 'token_tree_link',
    );

    return $build;
  }

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration() {
    return [
      'name' => '[site:name]',
      'url' => '[site:url]',
    ];
  }

}
