<?php

namespace Drupal\structured_data\Plugin\StructuredDataType;

use Drupal\structured_data\EntityStructuredDataTypeBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Provides a 'Museum' structured data type.
 *
 * @StructuredDataType(
 *   id = "museum",
 *   name = @Translation("Museum"),
 *   type = "Organization"
 * )
 */
class Museum extends EntityStructuredDataTypeBase {
  
  public function getData() {
    return parent::getData() + $this->getMuseumData();
  }

  protected function getMuseumData() {
    $config = \Drupal::config('structured_data.settings');
    return [
      '@type' => 'Museum',
      'openingHours' => $this->tokenizeString($config->get('museum.opening_hours')),
      'address' => [
        '@type' => 'PostalAddress',
        'streetAddress' => $this->tokenizeString($config->get('museum.street_address')),
        'addressLocality' =>  $this->tokenizeString($config->get('museum.address_locality')),
        'addressCountry' =>  $this->tokenizeString($config->get('museum.country')),
        'postalCode' =>  $this->tokenizeString($config->get('museum.postcode'))
      ],
      'telephone' =>  $this->tokenizeString($config->get('museum.telephone'))
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $form, FormStateInterface $form_state, $config) {
    $build = parent::buildConfigurationForm($form, $form_state, $config);
    
    $token_types = ['node'];
    
    $build['museum__opening_hours'] = [
      '#title' => t('Museum opening hours'),
      '#type' => 'textfield',
      '#default_value' => $config->get('museum.opening_hours'),
      '#description' => t("The opening hours of the museum."),
      '#element_validate' => array('token_element_validate'),
      '#after_build' => array('token_element_validate'),
      '#token_types' => $token_types,
    ];

    $build['museum__street_address'] = [
      '#title' => t('Museum street address'),
      '#type' => 'textfield',
      '#default_value' => $config->get('museum.street_address'),
      '#description' => t("The street address of the museum."),
    ];
    
    $build['museum__address_locality'] = [
      '#title' => t('Museum address locality'),
      '#type' => 'textfield',
      '#default_value' => $config->get('museum.address_locality'),
      '#description' => t("The address locality of the museum."),
    ];
    
    $build['museum__country'] = [
      '#title' => t('Museum country'),
      '#type' => 'textfield',
      '#default_value' => $config->get('museum.country'),
      '#description' => t("The country of the museum."),
    ];
    
    $build['museum__postcode'] = [
      '#title' => t('Museum postcode'),
      '#type' => 'textfield',
      '#default_value' => $config->get('museum.postcode'),
      '#description' => t("The postcode of the museum."),
    ];
    
    $build['museum__telephone'] = [
      '#title' => t('Museum telephone'),
      '#type' => 'textfield',
      '#default_value' => $config->get('museum.telephone'),
      '#description' => t("The telephone number of the museum."),
    ];
    
    $build['article__token_help'] = array(
      '#theme' => 'token_tree_link',
      '#token_types' => $token_types,
    );

    return $build;
  }

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration() {
    return [
      'type' => [],
      'streetAddress' => '',
      'addressLocality' => '',
      'addressCountry' => '',
      'postalCode' => '',
      'openingHours' => '',
      'telephone' => '',
    ];
  }

}
